import Link from "next/link";
export default function Brand({ onClick }: { onClick?: () => void }) {
  return (
    <Link
      onClick={onClick}
      href="/"
      className="brand"
      aria-label="ZILAL TRAVEL — главная"
    >
      <span className="brand-mark" aria-hidden="true">
        △
      </span>
      <span>
        ZILAL<span className="brand-sub">TRAVEL · KYRGYZSTAN</span>
      </span>
    </Link>
  );
}
