import Photo from "@/components/Photo";
import type { PhotoKey } from "@/lib/types";
export default function ChoiceCard({
  type,
  name,
  value,
  title,
  description,
  checked,
  onChange,
  image,
  errorId,
}: {
  type: "radio" | "checkbox";
  name: string;
  value: string;
  title: string;
  description: string;
  checked: boolean;
  onChange: () => void;
  image?: PhotoKey;
  errorId?: string;
}) {
  return (
    <label
      className={`trip-choice${checked ? " is-selected" : ""}${image ? " has-visual" : ""}`}
    >
      <input
        type={type}
        name={name}
        value={value}
        checked={checked}
        onChange={onChange}
        aria-describedby={errorId}
        aria-invalid={Boolean(errorId)}
      />
      {image && (
        <span className="trip-choice-visual" aria-hidden="true">
          <Photo name={image} slot="choice" decorative />
        </span>
      )}
      <span className="trip-choice-content">
        <span className="trip-choice-title">{title}</span>
        <span className="trip-choice-description">{description}</span>
      </span>
      <span className="trip-choice-mark" aria-hidden="true">
        {checked ? "✓" : "+"}
      </span>
    </label>
  );
}
