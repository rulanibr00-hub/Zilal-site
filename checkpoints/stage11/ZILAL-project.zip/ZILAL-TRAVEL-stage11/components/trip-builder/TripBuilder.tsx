"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useInquirySubmission } from "@/components/inquiries/useInquirySubmission";
import {
  SubmissionTerms,
  SubmissionResult,
} from "@/components/inquiries/SubmissionTerms";
import { tripDraftPayload } from "@/lib/admin/inquiry-payload";
import { Button } from "@/components/ui/Button";
import { daysLabel, travelStyles } from "@/lib/tour-catalog";
import {
  accommodationOptions,
  createTripDraft,
  estimatedEndDate,
  firstInvalidStep,
  formatTripDate,
  tripActivities,
  tripSteps,
  validateTripStep,
  type Accommodation,
  type TripActivity,
  type TripDraft,
  type TripErrors,
  type TripField,
  type TripSeed,
} from "@/lib/trip-builder";
import type { Destination, PhotoKey, TravelStyle } from "@/lib/types";
import ChoiceCard from "./ChoiceCard";
import TripSummary from "./TripSummary";
const stepContent = [
  {
    title: "Как звучит ваше путешествие?",
    description:
      "Спокойная элегантность, свобода приключений или немного того и другого? Выберите одно настроение.",
  },
  {
    title: "Куда зовёт ваш Кыргызстан?",
    description:
      "Отметьте одно или несколько мест. Это желания, а не фиксированный порядок остановок.",
  },
  {
    title: "Из чего сложится ваша история?",
    description:
      "Выберите хотя бы одну активность. Можно соединить движение, культуру и время для отдыха.",
  },
  {
    title: "Сколько времени оставим открытиям?",
    description:
      "Наметьте продолжительность и компанию. Даты могут оставаться гибкими.",
  },
  {
    title: "Где хочется замедлиться?",
    description:
      "Выберите предпочтение по проживанию и расскажите о важных деталях. Это не обещание конкретных отелей или услуг.",
  },
  {
    title: "Путешествие обретает ваш характер.",
    description:
      "Проверьте предпочтения и попробуйте заполнить контакты. Данные никуда не отправятся.",
  },
];
const fieldTitles: Partial<Record<TripField, string>> = {
  style: "Стиль",
  destinationIds: "Направления",
  activities: "Активности",
  duration: "Продолжительность",
  startDate: "Дата начала",
  adults: "Взрослые",
  children: "Дети",
  accommodation: "Проживание",
  wishes: "Пожелания",
  name: "Имя",
  email: "Email",
  phone: "Телефон",
};
export default function TripBuilder({
  destinations,
  selectedTour,
  today,
}: {
  destinations: readonly Destination[];
  selectedTour?: TripSeed;
  today: string;
}) {
  const send = useInquirySubmission();
  const off = send.config.mode === "disabled";
  const [draft, setDraft] = useState<TripDraft>(() =>
    createTripDraft(selectedTour),
  );
  const [step, setStep] = useState(0);
  const [furthest, setFurthest] = useState(0);
  const [errors, setErrors] = useState<TripErrors>({});
  const [reviewed, setReviewed] = useState(false);
  const [focusToken, setFocusToken] = useState(0);
  const focusTarget = useRef<"heading" | "errors" | "confirmation" | null>(
    null,
  );
  const heading = useRef<HTMLHeadingElement>(null);
  const errorSummary = useRef<HTMLDivElement>(null);
  const confirmation = useRef<HTMLDivElement>(null);
  const context = { today, destinationIds: destinations.map((d) => d.id) };
  useEffect(() => {
    if (focusTarget.current === "errors") errorSummary.current?.focus();
    else if (focusTarget.current === "confirmation")
      confirmation.current?.focus();
    else if (focusTarget.current === "heading") heading.current?.focus();
  }, [step, focusToken]);
  useEffect(() => {
    const mapped: TripErrors = {};
    let first = 5;
    const groups = [
      ["style"],
      ["destinationIds"],
      ["activities"],
      ["duration", "startDate", "adults", "children"],
      ["accommodation", "wishes"],
      ["name", "email", "phone"],
    ];
    for (const [key, message] of Object.entries(send.fields)) {
      const field = key.replace(/^details\./, "") as TripField;
      if (field in fieldTitles) {
        mapped[field] = message;
        const index = groups.findIndex((g) => g.includes(field));
        if (index >= 0) first = Math.min(first, index);
      }
    }
    if (Object.keys(mapped).length) showErrors(first, mapped);
  }, [send.fields]);
  function update<K extends TripField>(field: K, value: TripDraft[K]) {
    if (send.busy || send.accepted) return;
    send.clearError();
    setDraft((previous) => ({ ...previous, [field]: value }));
    setErrors((previous) => {
      const next = { ...previous };
      delete next[field];
      return next;
    });
    setReviewed(false);
  }
  function toggle(
    field: "destinationIds",
    value: TripDraft["destinationIds"][number],
  ): void;
  function toggle(field: "activities", value: TripActivity): void;
  function toggle(field: "destinationIds" | "activities", value: string) {
    if (field === "destinationIds")
      update(
        field,
        draft.destinationIds.includes(
          value as TripDraft["destinationIds"][number],
        )
          ? draft.destinationIds.filter((id) => id !== value)
          : [
              ...draft.destinationIds,
              value as TripDraft["destinationIds"][number],
            ],
      );
    else
      update(
        field,
        draft.activities.includes(value as TripActivity)
          ? draft.activities.filter((id) => id !== value)
          : [...draft.activities, value as TripActivity],
      );
  }
  function showErrors(targetStep: number, nextErrors: TripErrors) {
    focusTarget.current = "errors";
    setStep(targetStep);
    setErrors(nextErrors);
    setReviewed(false);
    setFocusToken((value) => value + 1);
  }
  function goTo(nextStep: number) {
    if (send.busy || send.accepted) return;
    send.clearError();
    if (nextStep > step) {
      const invalid = firstInvalidStep(draft, context, nextStep - 1);
      if (invalid) {
        showErrors(invalid.step, invalid.errors);
        return;
      }
    }
    focusTarget.current = "heading";
    setErrors({});
    setStep(nextStep);
    setFurthest((value) => Math.max(value, nextStep));
    setFocusToken((value) => value + 1);
    setReviewed(false);
  }
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (send.busy || send.accepted) return;
    const stepErrors = validateTripStep(draft, step, context);
    if (Object.keys(stepErrors).length) {
      showErrors(step, stepErrors);
      return;
    }
    if (step < tripSteps.length - 1) {
      goTo(step + 1);
      return;
    }
    const invalid = firstInvalidStep(draft, context);
    if (invalid) {
      showErrors(invalid.step, invalid.errors);
      return;
    }
    if (!off) {
      await send.submit(tripDraftPayload(draft, selectedTour?.slug));
      return;
    }
    setReviewed(true);
    setErrors({});
    focusTarget.current = "confirmation";
    setFocusToken((value) => value + 1);
  }
  function fieldError(field: TripField) {
    return errors[field] ? (
      <p className="trip-field-error" id={`trip-error-${field}`}>
        {errors[field]}
      </p>
    ) : null;
  }
  function describedBy(field: TripField) {
    return errors[field] ? `trip-error-${field}` : undefined;
  }
  const end = estimatedEndDate(draft.startDate, draft.duration);
  const current = stepContent[step];
  return (
    <section
      className="trip-builder wrap"
      id="brief"
      aria-label="Конструктор путешествия"
    >
      <div className="trip-demo-banner">
        <span aria-hidden="true">◇</span>
        <div>
          <strong>
            {off
              ? "Демонстрационный конструктор"
              : send.config.mode === "test"
                ? "Локальная проверка заявки"
                : "Ваше персональное путешествие"}
          </strong>
          <p>
            {off
              ? "Ничего не отправляется и не бронируется."
              : send.config.mode === "test"
                ? "Параметры записываются в отдельную тестовую БД. Не вводите настоящие данные."
                : "Заявка будет сохранена для обсуждения; это не бронирование."}{" "}
            Ответы сохраняются между шагами; до отправки они сбрасываются после
            обновления страницы.
          </p>
        </div>
      </div>
      {selectedTour && (
        <div className="trip-seed">
          <div>
            <p className="eyebrow">Отправная точка · пример маршрута</p>
            <h2>{selectedTour.title.ru}</h2>
            <p>
              Параметры уже перенесены. Меняйте их под себя — исходный пример
              останется прежним.
            </p>
          </div>
          <Link href={`/tours/${selectedTour.slug}`} className="text-link">
            Исходный маршрут →
          </Link>
        </div>
      )}
      <div className="trip-progress-head">
        <p aria-live="polite">
          Шаг {step + 1} из {tripSteps.length} <span>· {tripSteps[step]}</span>
        </p>
        <span aria-hidden="true">
          {Math.round(((step + 1) / tripSteps.length) * 100)}%
        </span>
      </div>
      <progress
        className="trip-progress"
        value={step + 1}
        max={tripSteps.length}
        aria-label="Прогресс конструктора"
      >
        Шаг {step + 1} из {tripSteps.length}
      </progress>
      <nav aria-label="Шаги конструктора">
        <ol className="trip-stepper">
          {tripSteps.map((title, i) => (
            <li key={title}>
              <button
                type="button"
                disabled={i > furthest || send.busy || Boolean(send.accepted)}
                aria-current={i === step ? "step" : undefined}
                onClick={() => goTo(i)}
              >
                <span className="trip-step-number" aria-hidden="true">
                  {i < step ? "✓" : String(i + 1).padStart(2, "0")}
                </span>
                <span>{title}</span>
              </button>
            </li>
          ))}
        </ol>
      </nav>
      <div className={`trip-builder-grid${step === 5 ? " is-review" : ""}`}>
        <form
          className="trip-builder-form"
          onSubmit={submit}
          method="post"
          action="/api/inquiries"
          aria-busy={send.busy}
          noValidate
          aria-labelledby="trip-step-title"
        >
          <fieldset
            className="submission-fields"
            disabled={send.loading || send.busy || Boolean(send.accepted)}
          >
            <legend className="submission-sr-only">
              Параметры путешествия
            </legend>
            <p className="eyebrow">Создаём вашу историю · 0{step + 1}</p>
            <h2
              id="trip-step-title"
              ref={heading}
              tabIndex={-1}
              className="trip-step-heading"
            >
              {current.title}
            </h2>
            <p className="trip-step-description">
              {step === 5 && !off
                ? "Проверьте предпочтения и укажите контакты. После сохранения появится номер заявки."
                : current.description}
            </p>
            {Object.keys(errors).length > 0 && (
              <div
                className="trip-error-summary"
                ref={errorSummary}
                tabIndex={-1}
                role="alert"
              >
                <h3>Проверьте ответы на этом шаге</h3>
                <ul>
                  {Object.entries(errors).map(([field, message]) => (
                    <li key={field}>
                      <button
                        type="button"
                        onClick={() =>
                          document.getElementById(`trip-${field}`)?.focus()
                        }
                      >
                        {fieldTitles[field as TripField]}: {message}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {step === 0 && (
              <fieldset
                className="trip-fieldset"
                id="trip-style"
                tabIndex={-1}
                aria-invalid={Boolean(errors.style)}
                aria-describedby={describedBy("style")}
              >
                <legend>Стиль путешествия · выберите один</legend>
                <div className="trip-choice-grid styles">
                  {Object.entries(travelStyles).map(([id, style]) => (
                    <ChoiceCard
                      key={id}
                      type="radio"
                      name="trip-style"
                      value={id}
                      title={style.title}
                      description={style.description}
                      image={
                        (
                          {
                            comfort: "lake",
                            adventure: "alakul",
                            combined: "mountain",
                          } as Record<string, PhotoKey>
                        )[id]
                      }
                      checked={draft.style === id}
                      onChange={() => update("style", id as TravelStyle)}
                      errorId={describedBy("style")}
                    />
                  ))}
                </div>
                {fieldError("style")}
              </fieldset>
            )}
            {step === 1 && (
              <fieldset
                className="trip-fieldset"
                id="trip-destinationIds"
                tabIndex={-1}
                aria-invalid={Boolean(errors.destinationIds)}
                aria-describedby={describedBy("destinationIds")}
              >
                <legend>Направления · можно выбрать несколько</legend>
                <div className="trip-choice-grid places">
                  {destinations.map((place) => (
                    <ChoiceCard
                      key={place.id}
                      type="checkbox"
                      name="trip-destinations"
                      value={place.id}
                      title={place.name.ru}
                      description={place.caption.ru}
                      image={place.image}
                      checked={draft.destinationIds.includes(place.id)}
                      onChange={() => toggle("destinationIds", place.id)}
                      errorId={describedBy("destinationIds")}
                    />
                  ))}
                </div>
                {fieldError("destinationIds")}
                <p className="trip-field-hint">
                  Высокогорные места зависят от сезона, погоды и подготовки.
                  Выбор здесь не подтверждает доступность маршрута.
                </p>
              </fieldset>
            )}
            {step === 2 && (
              <fieldset
                className="trip-fieldset"
                id="trip-activities"
                tabIndex={-1}
                aria-invalid={Boolean(errors.activities)}
                aria-describedby={describedBy("activities")}
              >
                <legend>Активности · можно выбрать несколько</legend>
                <div className="trip-choice-grid activities">
                  {tripActivities.map((activity) => (
                    <ChoiceCard
                      key={activity.id}
                      type="checkbox"
                      name="trip-activities"
                      value={activity.id}
                      title={activity.title}
                      description={activity.description}
                      checked={draft.activities.includes(activity.id)}
                      onChange={() => toggle("activities", activity.id)}
                      errorId={describedBy("activities")}
                    />
                  ))}
                </div>
                {fieldError("activities")}
                <p className="trip-field-hint">
                  Это интересы, а не включённые услуги. Нагрузку и формат
                  активностей потребуется согласовать.
                </p>
              </fieldset>
            )}
            {step === 3 && (
              <div className="trip-logistics">
                <div className="trip-input-group">
                  <label htmlFor="trip-duration">
                    Продолжительность, дней *
                  </label>
                  <input
                    id="trip-duration"
                    name="duration"
                    type="number"
                    min={1}
                    max={60}
                    step={1}
                    inputMode="numeric"
                    value={draft.duration}
                    onChange={(e) => update("duration", e.target.value)}
                    aria-invalid={Boolean(errors.duration)}
                    aria-describedby={
                      describedBy("duration") ?? "trip-duration-hint"
                    }
                    required
                  />
                  <p className="trip-field-hint" id="trip-duration-hint">
                    От 1 до 60 дней. Продолжительность можно изменить позже.
                  </p>
                  {fieldError("duration")}
                </div>
                <fieldset className="trip-fieldset dates">
                  <legend>Примерные даты</legend>
                  <label className="trip-check-line">
                    <input
                      type="checkbox"
                      checked={draft.flexibleDates}
                      onChange={(e) => {
                        update("flexibleDates", e.target.checked);
                        setErrors((previous) => {
                          const next = { ...previous };
                          delete next.startDate;
                          return next;
                        });
                      }}
                    />
                    Даты пока не определены
                  </label>
                  <div className="trip-input-group">
                    <label htmlFor="trip-startDate">
                      Примерное начало{!draft.flexibleDates ? " *" : ""}
                    </label>
                    <input
                      id="trip-startDate"
                      name="startDate"
                      type="date"
                      min={today}
                      disabled={draft.flexibleDates}
                      required={!draft.flexibleDates}
                      value={draft.startDate}
                      onChange={(e) => update("startDate", e.target.value)}
                      aria-invalid={Boolean(errors.startDate)}
                      aria-describedby={describedBy("startDate")}
                    />
                    {fieldError("startDate")}
                    {!draft.flexibleDates && end && (
                      <p className="trip-field-hint">
                        Ориентировочное завершение: {formatTripDate(end)}. Даты
                        не подтверждены.
                      </p>
                    )}
                  </div>
                </fieldset>
                <fieldset className="trip-fieldset">
                  <legend>Кто отправится с вами?</legend>
                  <div className="trip-input-row">
                    {(
                      [
                        { field: "adults", title: "Взрослые *", min: 1 },
                        { field: "children", title: "Дети *", min: 0 },
                      ] as const
                    ).map((item) => (
                      <div className="trip-input-group" key={item.field}>
                        <label htmlFor={`trip-${item.field}`}>
                          {item.title}
                        </label>
                        <input
                          id={`trip-${item.field}`}
                          name={item.field}
                          type="number"
                          min={item.min}
                          max={20}
                          step={1}
                          inputMode="numeric"
                          value={draft[item.field]}
                          onChange={(e) => update(item.field, e.target.value)}
                          aria-invalid={Boolean(errors[item.field])}
                          aria-describedby={describedBy(item.field)}
                          required
                        />
                        {fieldError(item.field)}
                      </div>
                    ))}
                  </div>
                  <p className="trip-field-hint">
                    Взрослые — от 1 до 20, дети — от 0 до 20. Если едут дети,
                    возраст можно указать в пожеланиях.
                  </p>
                </fieldset>
              </div>
            )}
            {step === 4 && (
              <>
                <fieldset
                  className="trip-fieldset"
                  id="trip-accommodation"
                  tabIndex={-1}
                  aria-invalid={Boolean(errors.accommodation)}
                  aria-describedby={describedBy("accommodation")}
                >
                  <legend>Проживание · выберите одно предпочтение</legend>
                  <div className="trip-choice-grid stays">
                    {accommodationOptions.map((option) => (
                      <ChoiceCard
                        key={option.id}
                        type="radio"
                        name="trip-accommodation"
                        value={option.id}
                        title={option.title}
                        description={option.description}
                        checked={draft.accommodation === option.id}
                        onChange={() =>
                          update("accommodation", option.id as Accommodation)
                        }
                        errorId={describedBy("accommodation")}
                      />
                    ))}
                  </div>
                  {fieldError("accommodation")}
                </fieldset>
                <div className="trip-input-group wishes">
                  <label htmlFor="trip-wishes">О чём ещё важно знать?</label>
                  <textarea
                    id="trip-wishes"
                    name="wishes"
                    rows={4}
                    maxLength={2000}
                    value={draft.wishes}
                    onChange={(e) => update("wishes", e.target.value)}
                    placeholder="Особые интересы, возраст детей, пожелания к темпу и проживанию…"
                    aria-invalid={Boolean(errors.wishes)}
                    aria-describedby={
                      describedBy("wishes") ?? "trip-wishes-hint"
                    }
                  />
                  <p className="trip-field-hint" id="trip-wishes-hint">
                    {draft.wishes.length} / 2000. Не указывайте паспортные,
                    платёжные и другие конфиденциальные данные.
                  </p>
                  {fieldError("wishes")}
                </div>
              </>
            )}
            {step === 5 && (
              <>
                <div className="trip-review-grid">
                  <TripSummary
                    draft={draft}
                    destinations={destinations}
                    selectedTour={selectedTour}
                    onEdit={goTo}
                  />
                  <section
                    className="trip-contacts"
                    aria-labelledby="trip-contacts-title"
                  >
                    <p className="eyebrow">Последние штрихи</p>
                    <h3 id="trip-contacts-title">Как к вам обращаться?</h3>
                    <p className="trip-field-hint">
                      {off
                        ? "Контакты обязательны только для проверки демо-резюме. Они не отправляются и сбрасываются при обновлении страницы."
                        : send.config.mode === "test"
                          ? "Локальная проверка: используйте только тестовые контакты."
                          : "Укажите контакты, чтобы компания могла ответить на ваше обращение."}
                    </p>
                    <div className="trip-input-group">
                      <label htmlFor="trip-name">Имя *</label>
                      <input
                        id="trip-name"
                        name="name"
                        autoComplete="name"
                        maxLength={100}
                        value={draft.name}
                        onChange={(e) => update("name", e.target.value)}
                        aria-invalid={Boolean(errors.name)}
                        aria-describedby={describedBy("name")}
                        required
                      />
                      {fieldError("name")}
                    </div>
                    <div className="trip-input-group">
                      <label htmlFor="trip-email">Email *</label>
                      <input
                        id="trip-email"
                        name="email"
                        type="email"
                        autoComplete="email"
                        maxLength={254}
                        value={draft.email}
                        onChange={(e) => update("email", e.target.value)}
                        aria-invalid={Boolean(errors.email)}
                        aria-describedby={describedBy("email")}
                        required
                      />
                      {fieldError("email")}
                    </div>
                    <fieldset className="trip-fieldset contact-method">
                      <legend>Предпочтительный способ связи</legend>
                      <div className="trip-contact-methods">
                        {(
                          [
                            { id: "whatsapp", title: "WhatsApp" },
                            { id: "phone", title: "Телефон" },
                          ] as const
                        ).map((method) => (
                          <label key={method.id}>
                            <input
                              type="radio"
                              name="contact-method"
                              value={method.id}
                              checked={draft.contactMethod === method.id}
                              onChange={() =>
                                update("contactMethod", method.id)
                              }
                            />
                            {method.title}
                          </label>
                        ))}
                      </div>
                    </fieldset>
                    <div className="trip-input-group">
                      <label htmlFor="trip-phone">Телефон или WhatsApp *</label>
                      <input
                        id="trip-phone"
                        name="phone"
                        type="tel"
                        autoComplete="tel"
                        maxLength={40}
                        value={draft.phone}
                        onChange={(e) => update("phone", e.target.value)}
                        placeholder="+ код страны и номер"
                        aria-invalid={Boolean(errors.phone)}
                        aria-describedby={
                          describedBy("phone") ?? "trip-phone-hint"
                        }
                        required
                      />
                      <p className="trip-field-hint" id="trip-phone-hint">
                        Номер с + и кодом страны.{" "}
                        {off
                          ? "Звонков и сообщений не будет."
                          : "Укажите подходящий способ связи."}
                      </p>
                      {fieldError("phone")}
                    </div>
                  </section>
                </div>
                <SubmissionTerms submission={send} />
                {reviewed && (
                  <div
                    className="trip-demo-confirmation"
                    ref={confirmation}
                    role="status"
                    tabIndex={-1}
                  >
                    <h3>Резюме проверено. Это только демонстрация.</h3>
                    <p>
                      Заявка не отправлена. Бронирование не создано. Ваши
                      параметры и контакты остались только на этой странице — вы
                      можете продолжить их менять.
                    </p>
                  </div>
                )}
              </>
            )}
            <div className="trip-builder-actions">
              <button
                type="button"
                className="trip-back"
                disabled={step === 0 || send.busy || Boolean(send.accepted)}
                onClick={() => goTo(step - 1)}
              >
                ← Назад
              </button>
              <span className="trip-required-note">
                {step === 5
                  ? off
                    ? "Демо · без отправки данных"
                    : send.config.mode === "test"
                      ? "Локальная запись в тестовую БД"
                      : "Запись в защищённое хранилище"
                  : "Обязательный выбор отмечен в каждом шаге"}
              </span>
              <Button
                type="submit"
                disabled={send.loading || send.busy || Boolean(send.accepted)}
                variant={step === 5 ? "gold" : "green"}
              >
                {send.busy
                  ? "Отправляем…"
                  : step === 5
                    ? off
                      ? "Проверить резюме"
                      : "Отправить заявку"
                    : "Продолжить"}
              </Button>
            </div>
          </fieldset>
          <SubmissionResult submission={send} />
          <noscript>
            <p>
              Для конструктора и отправки нужен JavaScript. Данные не
              отправляются без него.
            </p>
          </noscript>
        </form>
        {step !== 5 && (
          <aside className="trip-companion" aria-label="Ваши предпочтения">
            <p className="eyebrow light">Пространство для вашей истории</p>
            <h3>
              За каждым выбором —<br />
              <em>ваш Кыргызстан.</em>
            </h3>
            <dl>
              <div>
                <dt>Настроение</dt>
                <dd>
                  {draft.style
                    ? travelStyles[draft.style].title
                    : "Начнём с ощущения"}
                </dd>
              </div>
              <div>
                <dt>Места</dt>
                <dd>
                  {draft.destinationIds.length
                    ? destinations
                        .filter((d) => draft.destinationIds.includes(d.id))
                        .map((d) => d.name.ru)
                        .join(" · ")
                    : "Ещё впереди"}
                </dd>
              </div>
              <div>
                <dt>Время</dt>
                <dd>
                  {/^\d+$/.test(draft.duration) &&
                  Number(draft.duration) >= 1 &&
                  Number(draft.duration) <= 60
                    ? daysLabel(Number(draft.duration))
                    : "Без спешки"}
                </dd>
              </div>
            </dl>
            <p>
              Ответы сохраняются при переходах между шагами. Здесь нет расчёта
              цены или подтверждения услуг.
            </p>
          </aside>
        )}
      </div>
    </section>
  );
}
