import Link from "next/link";
import { useIntake } from "@/components/inquiries/IntakeProvider";
import {
  accommodationOptions,
  estimatedEndDate,
  formatTripDate,
  tripActivities,
  type TripDraft,
  type TripSeed,
} from "@/lib/trip-builder";
import { daysLabel, travelStyles } from "@/lib/tour-catalog";
import type { Destination } from "@/lib/types";
export default function TripSummary({
  draft,
  destinations,
  selectedTour,
  onEdit,
}: {
  draft: TripDraft;
  destinations: readonly Destination[];
  selectedTour?: TripSeed;
  onEdit: (step: number) => void;
}) {
  const { config } = useIntake();
  const end = estimatedEndDate(draft.startDate, draft.duration);
  const sections = [
    {
      title: "Стиль путешествия",
      step: 0,
      text: draft.style ? travelStyles[draft.style].title : "Не выбран",
    },
    {
      title: "Места",
      step: 1,
      text:
        destinations
          .filter((d) => draft.destinationIds.includes(d.id))
          .map((d) => d.name.ru)
          .join(" · ") || "Не выбраны",
    },
    {
      title: "Впечатления",
      step: 2,
      text:
        tripActivities
          .filter((a) => draft.activities.includes(a.id))
          .map((a) => a.title)
          .join(" · ") || "Не выбраны",
    },
    {
      title: "Время и компания",
      step: 3,
      text: `${daysLabel(Number(draft.duration))} · Взрослых: ${draft.adults} · Детей: ${draft.children}`,
      detail: draft.flexibleDates
        ? "Даты пока гибкие"
        : `${formatTripDate(draft.startDate)}${end ? ` — ${formatTripDate(end)}` : ""} · ориентировочно`,
    },
    {
      title: "Проживание",
      step: 4,
      text:
        accommodationOptions.find((a) => a.id === draft.accommodation)?.title ??
        "Не выбрано",
      detail: draft.wishes.trim() || "Дополнительных пожеланий пока нет.",
    },
  ];
  return (
    <section className="trip-summary" aria-label="Резюме путешествия">
      <p className="eyebrow light">
        {config.mode === "disabled"
          ? "Персональная история · демоверсия"
          : config.mode === "test"
            ? "Локальный тест · ваши предпочтения"
            : "Предпочтения к вашей заявке"}
      </p>
      <h3>
        Ваш Кыргызстан.
        <br />
        <em>В ваших деталях.</em>
      </h3>
      {selectedTour && (
        <p className="trip-summary-source">
          Основа — пример «{selectedTour.title.ru}».{" "}
          <Link href={`/tours/${selectedTour.slug}`}>
            Посмотреть исходный маршрут →
          </Link>
        </p>
      )}
      <dl>
        {sections.map((section) => (
          <div className="trip-summary-row" key={section.title}>
            <dt>
              {section.title}
              <button
                type="button"
                onClick={() => onEdit(section.step)}
                aria-label={`Изменить: ${section.title}`}
              >
                Изменить
              </button>
            </dt>
            <dd>
              {section.text}
              {section.detail && <span>{section.detail}</span>}
            </dd>
          </div>
        ))}
      </dl>
      <p className="trip-summary-note">
        Это ваши предпочтения, а не утверждённая программа. Доступность мест,
        активностей и проживания потребуется уточнить. Стоимость не
        рассчитывается.
      </p>
    </section>
  );
}
