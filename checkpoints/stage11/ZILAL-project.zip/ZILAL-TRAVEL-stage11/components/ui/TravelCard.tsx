import Link from "next/link";
import Photo from "@/components/Photo";
import type { PhotoKey } from "@/lib/types";
type TravelCardProps = {
  href: string;
  title: string;
  description: string;
  eyebrow: string;
  image: PhotoKey;
  variant: "tour" | "destination";
  index?: number;
};
export default function TravelCard({
  href,
  title,
  description,
  eyebrow,
  image,
  variant,
  index,
}: TravelCardProps) {
  if (variant === "tour")
    return (
      <Link href={href} className="tour-card" data-reveal>
        <Photo name={image} slot="editorial" />
        <div className="card-shade" />
        <div className="tour-copy">
          <p className="eyebrow light">{eyebrow}</p>
          <h3>{title}</h3>
          <p>{description}</p>
          <span className="circle-arrow" aria-hidden="true">
            →
          </span>
        </div>
      </Link>
    );
  return (
    <Link href={href} className="destination" data-reveal>
      <div className="destination-image">
        <Photo name={image} slot="destination" />
        <span className="destination-index">
          {String((index ?? 0) + 1).padStart(2, "0")}
        </span>
        <span className="destination-arrow" aria-hidden="true">
          →
        </span>
      </div>
      <p className="eyebrow">{eyebrow}</p>
      <h3>{title}</h3>
      <p>{description}</p>
    </Link>
  );
}
