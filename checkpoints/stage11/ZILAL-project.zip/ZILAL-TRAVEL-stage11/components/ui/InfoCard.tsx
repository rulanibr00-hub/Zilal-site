import type { ReactNode } from "react";
export default function InfoCard({
  number,
  title,
  children,
  id,
  headingLevel = 2,
}: {
  number: string;
  title: ReactNode;
  children: ReactNode;
  id?: string;
  headingLevel?: 2 | 3;
}) {
  const Heading = headingLevel === 3 ? "h3" : "h2";
  return (
    <article className="info-card" id={id} data-reveal>
      <span className="benefit-number">{number} —</span>
      <Heading>{title}</Heading>
      <div className="info-card-copy">{children}</div>
    </article>
  );
}
