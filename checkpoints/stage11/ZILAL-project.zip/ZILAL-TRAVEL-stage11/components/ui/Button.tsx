import Link from "next/link";
import type { ComponentProps, ReactNode } from "react";
type Variant = "gold" | "green";
type Common = { children: ReactNode; variant?: Variant; className?: string };
function classes(variant: Variant, className: string) {
  return `button ${variant} ${className}`.trim();
}
export function ButtonLink({
  children,
  variant = "green",
  className = "",
  ...props
}: Common & Omit<ComponentProps<typeof Link>, "children" | "className">) {
  return (
    <Link {...props} className={classes(variant, className)}>
      {children}
      <span aria-hidden="true">→</span>
    </Link>
  );
}
export function Button({
  children,
  variant = "gold",
  className = "",
  ...props
}: Common & Omit<ComponentProps<"button">, "children" | "className">) {
  return (
    <button {...props} className={classes(variant, className)}>
      {children}
      <span aria-hidden="true">→</span>
    </button>
  );
}
