import ManagedImage from "@/components/cms/ManagedImage";
import Link from "next/link";
import Photo from "@/components/Photo";
import { daysLabel, difficultyLabels, travelStyles } from "@/lib/tour-catalog";
import type { Tour } from "@/lib/types";
export default function TourCard({ tour }: { tour: Tour }) {
  return (
    <article className="catalog-card" data-reveal>
      <Link
        href={`/tours/${tour.slug}`}
        className="catalog-card-image"
        aria-label={`Подробнее: ${tour.title.ru}`}
      >
        <ManagedImage asset={tour.media?.[0]} fallback={tour.image}/>
        <span className="example-label">
          {tour.status === "example" ? "Пример маршрута" : "Программа"}
        </span>
        <span className="catalog-image-arrow" aria-hidden="true">
          →
        </span>
      </Link>
      <div className="catalog-card-body">
        <p className="eyebrow">{travelStyles[tour.style].title}</p>
        <h3>
          <Link href={`/tours/${tour.slug}`}>{tour.title.ru}</Link>
        </h3>
        <p className="catalog-card-description">{tour.description.ru}</p>
        <div className="catalog-card-meta">
          <span>{daysLabel(tour.durationDays)}</span>
          <span>
            {tour.difficulty
              ? difficultyLabels[tour.difficulty]
              : "Нагрузка уточняется"}
          </span>
        </div>
        <Link className="text-link" href={`/tours/${tour.slug}`}>
          Открыть маршрут <span aria-hidden="true">→</span>
        </Link>
      </div>
    </article>
  );
}
