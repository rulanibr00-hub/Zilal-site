"use client";
import { useEffect, useState } from "react";
import {
  activityLabels,
  defaultFilters,
  durationOptions,
  filterTours,
  travelStyles,
  type TourFilters,
} from "@/lib/tour-catalog";
import type { Activity, Tour, TravelStyle } from "@/lib/types";
import TourCard from "./TourCard";
export default function TourCatalog({ tours }: { tours: readonly Tour[] }) {
  const [filters, setFilters] = useState<TourFilters>(defaultFilters);
  useEffect(() => {
    function applyHash() {
      const style = window.location.hash.slice(1);
      if (style === "comfort" || style === "adventure" || style === "combined")
        setFilters((previous) => ({ ...previous, style }));
    }
    applyHash();
    window.addEventListener("hashchange", applyHash);
    return () => window.removeEventListener("hashchange", applyHash);
  }, []);
  const visibleTours = filterTours(tours, filters);
  function reset() {
    setFilters(defaultFilters);
    if (["#comfort", "#adventure", "#combined"].includes(window.location.hash))
      window.history.replaceState(
        null,
        "",
        window.location.pathname + window.location.search,
      );
  }
  return (
    <section className="section wrap" id="catalog">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Коллекция впечатлений</p>
          <h2>
            Найдите свой <em>ритм.</em>
          </h2>
        </div>
        <p className="section-aside">
          Все текущие маршруты — примеры.
          <br />
          Без цен и подтверждённых отправлений.
        </p>
      </div>
      <div className="catalog-filters">
        <fieldset className="style-filter">
          <legend>Стиль путешествия</legend>
          <div className="style-options">
            {[
              { value: "all", label: "Все форматы" },
              ...Object.entries(travelStyles).map(([value, item]) => ({
                value,
                label: item.title,
              })),
            ].map((option) => (
              <label
                key={option.value}
                className={
                  filters.style === option.value
                    ? "style-option selected"
                    : "style-option"
                }
                id={option.value === "all" ? undefined : option.value}
              >
                <input
                  type="radio"
                  name="travel-style"
                  value={option.value}
                  checked={filters.style === option.value}
                  onChange={() =>
                    setFilters((previous) => ({
                      ...previous,
                      style: option.value as TravelStyle | "all",
                    }))
                  }
                />
                <span>{option.label}</span>
              </label>
            ))}
          </div>
        </fieldset>
        <div className="catalog-selects">
          <label>
            Продолжительность
            <select
              aria-label="Продолжительность"
              value={filters.duration}
              onChange={(event) =>
                setFilters((previous) => ({
                  ...previous,
                  duration: event.target.value as TourFilters["duration"],
                }))
              }
            >
              {durationOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            Активность
            <select
              aria-label="Активность"
              value={filters.activity}
              onChange={(event) =>
                setFilters((previous) => ({
                  ...previous,
                  activity: event.target.value as Activity | "all",
                }))
              }
            >
              <option value="all">Любая активность</option>
              {Object.entries(activityLabels).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </label>
          <button className="filter-reset" type="button" onClick={reset}>
            Сбросить фильтры <span aria-hidden="true">↺</span>
          </button>
        </div>
      </div>
      <p className="catalog-result" role="status" aria-live="polite">
        Найдено маршрутов: {visibleTours.length} из {tours.length}
      </p>
      {visibleTours.length ? (
        <div className="catalog-cards">
          {visibleTours.map((tour) => (
            <TourCard key={tour.id} tour={tour} />
          ))}
        </div>
      ) : (
        <div className="catalog-empty">
          <span className="eyebrow">Другой поворот</span>
          <h3>Пока нет такого сочетания.</h3>
          <p>
            Попробуйте другой формат или измените продолжительность и
            активность.
          </p>
          <button type="button" className="button green" onClick={reset}>
            Показать все маршруты <span aria-hidden="true">→</span>
          </button>
        </div>
      )}
    </section>
  );
}
