import type { Tour } from "@/lib/types";
import Link from "next/link";

import TourGallery from "@/components/tours/TourGallery";
import { ButtonLink } from "@/components/ui/Button";

import { destinations } from "@/lib/data/destinations";
import {
  activityLabels,
  daysLabel,
  difficultyLabels,
  travelStyles,
} from "@/lib/tour-catalog";
export default function TourDetail({tour}:{tour:Tour}) {
  const inquiryUrl = `/create-trip?tour=${encodeURIComponent(tour.slug)}`;
  return (
    <div className="tour-detail wrap">
      <nav className="breadcrumbs" aria-label="Хлебные крошки">
        <Link href="/">Главная</Link>
        <span>/</span>
        <Link href="/tours">Туры</Link>
        <span>/</span>
        <span aria-current="page">{tour.title.ru}</span>
      </nav>
      <div className="tour-detail-heading">
        <div>
          <p className="eyebrow">{travelStyles[tour.style].title}</p>
          <h1>{tour.title.ru}</h1>
        </div>
        <span className="sample-stamp">
          {tour.status === "example" ? "ПРИМЕР МАРШРУТА" : "ПРОГРАММА"}
        </span>
      </div>
      <p className="tour-detail-lead">{tour.description.ru}</p>
      <div className="tour-detail-layout">
        <div>
          <TourGallery images={tour.gallery} media={tour.media} title={tour.title.ru} />
          <section className="tour-detail-section" aria-labelledby="overview">
            <p className="eyebrow">Что может стать частью истории</p>
            <h2 id="overview">
              Впечатления <em>по пути.</em>
            </h2>
            <ul className="tour-highlights">
              {tour.highlights.map((item) => (
                <li key={item.ru}>{item.ru}</li>
              ))}
            </ul>
            <div className="tour-destination-links">
              {tour.destinationIds.map((id) => {
                const d = destinations.find((d) => d.id === id);
                return d ? (
                  <Link href={`/destinations#${d.id}`} key={id}>
                    {d.name.ru} →
                  </Link>
                ) : null;
              })}
            </div>
          </section>
          <section className="tour-detail-section" aria-labelledby="itinerary">
            <p className="eyebrow">Примерный ход путешествия</p>
            <h2 id="itinerary">
              День за <em>днём.</em>
            </h2>
            <p className="tour-section-note">
              Это не утверждённая программа. Последовательность остановок, сроки
              и активности могут меняться после оценки сезона, подготовки и
              погодных условий.
            </p>
            <ol className="tour-itinerary">
              {tour.itinerary.map((item) => (
                <li key={item.day}>
                  <span className="itinerary-day">
                    ДЕНЬ {String(item.day).padStart(2, "0")}
                  </span>
                  <div>
                    <h3>{item.title.ru}</h3>
                    <p>{item.description.ru}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>
          <section className="tour-detail-section" aria-labelledby="difficulty">
            <p className="eyebrow">Подготовка и нагрузка</p>
            <h2 id="difficulty">
              Сложность <em>маршрута.</em>
            </h2>
            <p className="difficulty-label">
              {tour.difficulty
                ? difficultyLabels[tour.difficulty]
                : "Сложность уточняется"}
            </p>
            <p className="tour-section-note">{tour.difficultyNote.ru}</p>
          </section>
          <section className="tour-detail-section" aria-labelledby="services">
            <p className="eyebrow">Состав будущей программы</p>
            <h2 id="services">
              Что может быть <em>включено.</em>
            </h2>
            <p className="tour-section-note">
              Ни одна из перечисленных услуг не гарантирована. Это пример
              структуры предложения, а не подтверждённый пакет. Окончательный
              состав должен быть согласован отдельно.
            </p>
            <div className="service-lists">
              {[
                {
                  title: "Предполагается обсудить",
                  items: tour.services.proposed,
                },
                {
                  title: "В примере не включено",
                  items: tour.services.notIncluded,
                },
                { title: "Требует уточнения", items: tour.services.toConfirm },
              ].map((group) => (
                <div key={group.title}>
                  <h3>{group.title}</h3>
                  <ul>
                    {group.items.map((item) => (
                      <li key={item.ru}>{item.ru}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        </div>
        <aside className="tour-summary" aria-label="Кратко о маршруте">
          <p className="eyebrow">Ваш следующий горизонт</p>
          <dl>
            <div>
              <dt>Формат</dt>
              <dd>{travelStyles[tour.style].title}</dd>
            </div>
            <div>
              <dt>Примерная длительность</dt>
              <dd>{daysLabel(tour.durationDays)}</dd>
            </div>
            <div>
              <dt>Нагрузка</dt>
              <dd>
                {tour.difficulty
                  ? difficultyLabels[tour.difficulty]
                  : "Уточняется"}
              </dd>
            </div>
            <div>
              <dt>Активности</dt>
              <dd>
                {tour.activities.map((a) => activityLabels[a]).join(" · ")}
              </dd>
            </div>
          </dl>
          <p className="summary-disclaimer">
            Демонстрационный маршрут. Даты, цена, наличие мест и услуги не
            подтверждены.
          </p>
          <ButtonLink variant="gold" href={`${inquiryUrl}#brief`}>
            Хочу этот тур
          </ButtonLink>
          <ButtonLink href={inquiryUrl}>Настроить путешествие</ButtonLink>
          <Link className="text-link" href="/tours">
            ← Вернуться в каталог
          </Link>
        </aside>
      </div>
    </div>
  );
}
