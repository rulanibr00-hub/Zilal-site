"use client";
import ManagedImage from "@/components/cms/ManagedImage";
import { useRef, useState } from "react";
import Photo from "@/components/Photo";
import { photos, isDocumentedPhoto } from "@/lib/media";
import type { PhotoKey } from "@/lib/types";
export default function TourGallery({
  images,
  media = [],
  title,
}: {
  images: PhotoKey[];
  media?: import("@/lib/cms/contracts").MediaInfo[];
  title: string;
}) {
  const [active, setActive] = useState(0);
  const dialog = useRef<HTMLDialogElement>(null);
  const count = media.length || images.length;
  const asset = media[active];
  const image = images[active % images.length] ?? images[0];
  if (!image) return null;
  function move(delta: number) {
    setActive((value) => (value + delta + images.length) % count);
  }
  return (
    <section
      className="tour-gallery"
      aria-label={`Галерея: ${title}`}
      onKeyDown={(event) => {
        if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
          event.preventDefault();
          move(event.key === "ArrowRight" ? 1 : -1);
        }
      }}
    >
      <div className="gallery-main">
        <ManagedImage asset={asset} fallback={image} priority/>
        <button
          type="button"
          className="gallery-expand"
          onClick={() => dialog.current?.showModal()}
        >
          Открыть галерею <span aria-hidden="true">→</span>
        </button>
        <span className="gallery-counter" aria-live="polite">
          {active + 1} / {count} ·{" "}
          {asset ? "Изображение" : isDocumentedPhoto(photos[image]) ? "Фотография" : "Иллюстрация"}
        </span>
      </div>
      <div className="gallery-thumbnails" aria-label="Выбрать изображение">
        {(media.length ? media.map(() => images[0]) : images).map((name, i) => (
          <button
            type="button"
            key={`${name}-${i}`}
            onClick={() => setActive(i)}
            aria-pressed={active === i}
            aria-label={`Изображение ${i + 1}: ${media[i]?.title ?? photos[name].label}`}
          >
            <ManagedImage asset={media[i]} fallback={name} thumbnail decorative/>
          </button>
        ))}
      </div>
      <p className="gallery-note">
        {asset && <span>{asset.author} · {asset.source} · {asset.rights}. </span>}
        {media.length ? "Автор и источник выбранного изображения указаны выше; опубликованные материалы перечислены на странице источников." : images.every((name) => isDocumentedPhoto(photos[name]))
          ? "Источники и авторство фотографий указаны на странице источников."
          : "Временные оригинальные иллюстрации, не фотографии конкретных точек маршрута."}{" "}
        <a href="/sources">Источники изображений →</a>
      </p>
      <dialog
        ref={dialog}
        className="gallery-dialog"
        aria-label={`Галерея: ${title}`}
        onClick={(event) => {
          if (event.target === event.currentTarget) dialog.current?.close();
        }}
      >
        <div className="gallery-dialog-content">
          <button
            className="gallery-close"
            type="button"
            onClick={() => dialog.current?.close()}
          >
            Закрыть ×
          </button>
          <div className="gallery-dialog-image">
            <ManagedImage asset={asset} fallback={image}/>
          </div>
          <div className="gallery-dialog-controls">
            <button
              type="button"
              onClick={() => move(-1)}
              aria-label="Предыдущее изображение"
            >
              ←
            </button>
            <p aria-live="polite">
              {asset?.title ?? photos[image].label} · {active + 1} / {count}
            </p>
            <button
              type="button"
              onClick={() => move(1)}
              aria-label="Следующее изображение"
            >
              →
            </button>
          </div>
        </div>
      </dialog>
    </section>
  );
}
