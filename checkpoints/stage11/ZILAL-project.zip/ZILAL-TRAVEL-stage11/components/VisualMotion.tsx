"use client";
import { useEffect } from "react";
import { usePathname } from "next/navigation";
// Progressive enhancement: SSR and JavaScript-disabled pages always remain visible.
export default function VisualMotion() {
  const pathname = usePathname();
  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const nodes = new Set<HTMLElement>();
    let intersection: IntersectionObserver | undefined;
    let mutations: MutationObserver | undefined;
    function clear() {
      intersection?.disconnect();
      mutations?.disconnect();
      nodes.forEach((node) =>
        node.classList.remove("motion-ready", "is-visible"),
      );
      nodes.clear();
    }
    function start() {
      clear();
      if (preference.matches || !("IntersectionObserver" in window)) return;
      intersection = new IntersectionObserver(
        (entries) =>
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              intersection?.unobserve(entry.target);
            }
          }),
        { rootMargin: "0px 0px -24px 0px", threshold: 0.05 },
      );
      function scan(root: Element) {
        const candidates = [
          ...(root.matches("[data-reveal]") ? [root] : []),
          ...root.querySelectorAll("[data-reveal]"),
        ];
        candidates.forEach((element) => {
          if (!(element instanceof HTMLElement) || nodes.has(element)) return;
          nodes.add(element);
          if (element.getBoundingClientRect().top < window.innerHeight - 16)
            return;
          element.classList.add("motion-ready");
          intersection?.observe(element);
        });
      }
      scan(document.body);
      mutations = new MutationObserver((records) =>
        records.forEach((record) =>
          record.addedNodes.forEach((node) => {
            if (node instanceof Element) scan(node);
          }),
        ),
      );
      mutations.observe(document.querySelector("main") ?? document.body, {
        childList: true,
        subtree: true,
      });
    }
    start();
    preference.addEventListener("change", start);
    return () => {
      clear();
      preference.removeEventListener("change", start);
    };
  }, [pathname]);
  return null;
}
