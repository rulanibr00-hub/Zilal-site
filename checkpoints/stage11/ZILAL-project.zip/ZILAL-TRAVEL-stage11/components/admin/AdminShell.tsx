"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useRef, useState } from "react";
import { adminRequest, errorText } from "./api";
const iconPaths: Record<string, string> = {
  "/admin": "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
  "/admin/inquiries": "M5 3h14v18H5z M8 8h8 M8 12h8 M8 16h5",
  "/admin/settings": "M4 6h16 M4 12h16 M4 18h16 M8 3v6 M16 9v6 M10 15v6",
  "/admin/telegram": "M3 10l18-7-7 18-4-8z M10 13l11-10",
};
const items = [
  { href: "/admin/tours", label: "Туры", icon: "◇" },
  { href: "/admin/media", label: "Медиатека", icon: "▧" },
  { href: "/admin/pages", label: "Страницы", icon: "▤" },
  { href: "/admin", label: "Обзор", icon: "◈" },
  { href: "/admin/inquiries", label: "Заявки", icon: "▤" },
  { href: "/admin/settings", label: "Настройки", icon: "⚙" },
  { href: "/admin/telegram", label: "Telegram", icon: "↗" },
];
export default function AdminShell({
  children,
  login,
  csrf,
  intakeMode = "disabled",
}: {
  children: React.ReactNode;
  login: string;
  csrf: string;
  intakeMode?: "disabled" | "test" | "live";
}) {
  const pathname = usePathname();
  const menu = useRef<HTMLDetailsElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  function nav(label: string) {
    return (
      <nav aria-label={label}>
        {items.map((item) => (
          <Link
            prefetch={false}
            key={item.href}
            href={item.href}
            aria-current={
              pathname === item.href ||
              (item.href !== "/admin" && pathname.startsWith(item.href + "/"))
                ? "page"
                : undefined
            }
            onClick={() => {
              if (menu.current) menu.current.open = false;
            }}
          >
            <svg
              aria-hidden="true"
              width="19"
              height="19"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.4"
            >
              <path d={iconPaths[item.href] ?? "M4 3h16v18H4z M8 8h8 M8 12h8 M8 16h5"} />
            </svg>
            {item.label}
          </Link>
        ))}
      </nav>
    );
  }
  async function logout() {
    setBusy(true);
    setError("");
    try {
      await adminRequest("/api/admin/logout", csrf);
      window.location.replace("/admin/login");
    } catch (e) {
      setError(errorText(e));
      setBusy(false);
    }
  }
  return (
    <>
      <a href="#admin-main" className="admin-skip">
        Перейти к содержимому
      </a>
      <aside className="admin-sidebar">
        <Link className="admin-brand" href="/admin" prefetch={false}>
          ZILAL<span>TRAVEL · УПРАВЛЕНИЕ</span>
        </Link>
        <p className="admin-sidebar-caption">Ваше рабочее пространство</p>
        {nav("Разделы админки")}
        <div className="admin-sidebar-bottom">
          <span>Один администратор</span>
          <Link href="/" prefetch={false}>
            Открыть сайт ↗
          </Link>
        </div>
      </aside>
      <div className="admin-workspace">
        <header className="admin-topbar">
          <span>
            Панель управления <span className="admin-topbar-dot">/</span> ZILAL
            TRAVEL
          </span>
          <div className="admin-account">
            <span>{login}</span>
            <button onClick={logout} disabled={busy}>
              {busy ? "Выходим…" : "Выйти"}
            </button>
          </div>
        </header>
        <details
          className="admin-mobile-menu"
          ref={menu}
          onKeyDown={(e) => {
            if (e.key === "Escape" && menu.current) {
              menu.current.open = false;
              menu.current.querySelector("summary")?.focus();
            }
          }}
        >
          <summary>
            Разделы панели <span aria-hidden="true">☰</span>
          </summary>
          {nav("Мобильные разделы админки")}
        </details>
        {error && (
          <p className="admin-alert" role="alert">
            {error}
          </p>
        )}
        <main id="admin-main" className="admin-main" tabIndex={-1}>
          {children}
        </main>
        <footer className="admin-footer">
          ZILAL TRAVEL{" "}
          <span>
            {intakeMode === "live"
              ? "Приём заявок включён"
              : intakeMode === "test"
                ? "Локальный тест приёма"
                : "Публичный приём заявок отключён"}{" "}
            · время Бишкека
          </span>
        </footer>
      </div>
    </>
  );
}
