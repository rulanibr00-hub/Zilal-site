"use client";
import Link from "next/link";
import { useState } from "react";
import {
  statusLabels,
  statuses,
  sourceLabels,
  inquiryNumber,
  adminDate,
} from "@/lib/admin/contracts";
import { adminRequest, errorText } from "./api";
export interface InquiryRow {
  id: string;
  number: number;
  name: string;
  email: string;
  source: keyof typeof sourceLabels;
  status: keyof typeof statusLabels;
  isTest: boolean;
  createdAt: string;
  updatedAt: string;
}
export interface InquiryListData {
  rows: InquiryRow[];
  total: number;
  page: number;
  pageSize: number;
}
export default function InquiryList({
  initial,
  csrf,
}: {
  initial: InquiryListData;
  csrf: string;
}) {
  const [data, setData] = useState(initial);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [filtered, setFiltered] = useState(false);
  async function load(page = 1, reset = false) {
    setBusy(true);
    setError("");
    try {
      const result = await adminRequest("/api/admin/inquiries/search", csrf, {
        query: reset ? "" : query,
        status: reset ? "all" : status,
        page,
      });
      setData(result);
      setFiltered(reset ? false : Boolean(query || status !== "all"));
      if (reset) {
        setQuery("");
        setStatus("all");
      }
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <form
        className="admin-filter"
        onSubmit={(e) => {
          e.preventDefault();
          void load();
        }}
      >
        <div>
          <label htmlFor="inquiry-query">
            Поиск по имени, email или номеру
          </label>
          <input
            id="inquiry-query"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            maxLength={100}
            placeholder="Найти обращение…"
          />
        </div>
        <div>
          <label htmlFor="inquiry-status">Статус</label>
          <select
            id="inquiry-status"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="all">Все статусы</option>
            {statuses.map((s) => (
              <option key={s} value={s}>
                {statusLabels[s]}
              </option>
            ))}
          </select>
        </div>
        <button className="admin-button" disabled={busy}>
          {busy ? "Ищем…" : "Найти"}
        </button>
        <button
          type="button"
          className="admin-button secondary"
          disabled={busy}
          onClick={() => void load(1, true)}
        >
          Сбросить
        </button>
      </form>
      {error && (
        <p role="alert" className="admin-alert">
          {error}
        </p>
      )}
      <p className="admin-result" role="status">
        {busy ? "Загружаем обращения…" : `Найдено: ${data.total}`}
      </p>
      <section className="admin-card admin-list-card" aria-busy={busy}>
        {data.rows.length ? (
          <div className="admin-table-scroll">
            <table className="admin-table">
              <caption className="admin-visually-hidden">
                Заявки туристов
              </caption>
              <thead>
                <tr>
                  <th scope="col">Заявка</th>
                  <th scope="col">Клиент</th>
                  <th scope="col">Источник</th>
                  <th scope="col">Статус</th>
                  <th scope="col">Создана</th>
                </tr>
              </thead>
              <tbody>
                {data.rows.map((row) => (
                  <tr key={row.id}>
                    <td>
                      <Link
                        prefetch={false}
                        className="admin-table-link"
                        href={`/admin/inquiries/${row.id}`}
                      >
                        {inquiryNumber(row.number)}
                      </Link>
                      {row.isTest && (
                        <span className="admin-test-label">Тестовая</span>
                      )}
                    </td>
                    <td>
                      <strong>{row.name}</strong>
                      <small>{row.email}</small>
                    </td>
                    <td>{sourceLabels[row.source]}</td>
                    <td>
                      <span className={`admin-status status-${row.status}`}>
                        {statusLabels[row.status]}
                      </span>
                    </td>
                    <td>{adminDate(row.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="admin-empty">
            <span aria-hidden="true">◇</span>
            <h2>{filtered ? "Совпадений не найдено" : "Заявок пока нет"}</h2>
            <p>
              {filtered
                ? "Измените запрос или сбросьте фильтры."
                : "Здесь будут обращения из базы данных. Публичная отправка сейчас отключена."}
            </p>
          </div>
        )}
      </section>
      {data.total > data.pageSize && (
        <nav aria-label="Страницы заявок" className="admin-pagination">
          <button
            className="admin-button secondary"
            disabled={busy || data.page === 1}
            onClick={() => void load(data.page - 1)}
          >
            ← Назад
          </button>
          <span>
            Страница {data.page} из {Math.ceil(data.total / data.pageSize)}
          </span>
          <button
            className="admin-button secondary"
            disabled={busy || data.page * data.pageSize >= data.total}
            onClick={() => void load(data.page + 1)}
          >
            Далее →
          </button>
        </nav>
      )}
    </>
  );
}
