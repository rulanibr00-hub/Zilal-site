"use client";
import { useState } from "react";
import { statuses, statusLabels, adminDate } from "@/lib/admin/contracts";
import { adminRequest, errorText } from "./api";
export default function InquiryEditor({
  id,
  initialStatus,
  initialNote,
  updatedAt,
  csrf,
}: {
  id: string;
  initialStatus: keyof typeof statusLabels;
  initialNote: string;
  updatedAt: string;
  csrf: string;
}) {
  const [status, setStatus] = useState(initialStatus);
  const [note, setNote] = useState(initialNote);
  const [version, setVersion] = useState(updatedAt);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  return (
    <form
      className="admin-card admin-form"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setMessage("");
        setError("");
        try {
          const result = await adminRequest(
            `/api/admin/inquiries/${id}`,
            csrf,
            { status, internalNote: note, expectedUpdatedAt: version },
            "PATCH",
          );
          setVersion(result.updatedAt);
          setMessage("Изменения сохранены.");
        } catch (err) {
          setError(errorText(err));
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2>Работа с обращением</h2>
      <label htmlFor="edit-status">Статус заявки</label>
      <select
        id="edit-status"
        value={status}
        onChange={(e) => setStatus(e.target.value as typeof status)}
      >
        {statuses.map((s) => (
          <option key={s} value={s}>
            {statusLabels[s]}
          </option>
        ))}
      </select>
      <label htmlFor="internal-note">Внутренняя заметка</label>
      <textarea
        id="internal-note"
        value={note}
        onChange={(e) => setNote(e.target.value)}
        maxLength={2000}
        rows={6}
      />
      <p className="admin-help">
        Только для администратора. До 2000 символов. Не добавляйте пароли,
        документы и лишние чувствительные сведения.
      </p>
      <p className="admin-help">
        Обновлено: <time dateTime={version}>{adminDate(version)}</time>
      </p>
      {error && (
        <p className="admin-alert" role="alert">
          {error}
        </p>
      )}
      <button className="admin-button" disabled={busy}>
        {busy ? "Сохраняем…" : "Сохранить изменения"}
      </button>
      <p className="admin-save-status" role="status">
        {message}
      </p>
    </form>
  );
}
