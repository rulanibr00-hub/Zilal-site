"use client";
import { useState } from "react";
import { errorText } from "./api";
export default function LoginForm({ configured }: { configured: boolean }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  return (
    <form
      method="post"
      action="/api/admin/login"
      className="admin-form"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setError("");
        const form = new FormData(e.currentTarget);
        try {
          const response = await fetch("/api/admin/login", {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              login: form.get("login"),
              password: form.get("password"),
            }),
          });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error ?? "Не удалось войти.");
          window.location.replace("/admin");
        } catch (err) {
          setError(errorText(err));
          setBusy(false);
        }
      }}
    >
      <label htmlFor="admin-login">Логин или email</label>
      <input
        id="admin-login"
        name="login"
        required
        minLength={3}
        maxLength={254}
        autoComplete="username"
        autoCapitalize="none"
        spellCheck={false}
      />
      <label htmlFor="admin-password">Пароль</label>
      <input
        id="admin-password"
        name="password"
        type="password"
        required
        maxLength={1024}
        autoComplete="current-password"
      />
      {error && (
        <p className="admin-alert" role="alert">
          {error}
        </p>
      )}
      <button
        className="admin-button"
        type="submit"
        disabled={busy || !configured}
      >
        {busy ? "Проверяем…" : "Войти в панель"}
        <span aria-hidden="true">→</span>
      </button>
      <noscript>
        <p>Для защищённого входа включите JavaScript.</p>
      </noscript>
      <p className="admin-help">
        Доступ только для владельца. Публичной регистрации нет. Для создания
        аккаунта используется команда инициализации.
      </p>
    </form>
  );
}
