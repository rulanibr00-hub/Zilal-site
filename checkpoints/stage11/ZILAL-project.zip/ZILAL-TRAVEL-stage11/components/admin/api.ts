"use client";
export async function adminRequest(
  url: string,
  csrf: string,
  body?: unknown,
  method = "POST",
) {
  const response = await fetch(url, {
    method,
    credentials: "same-origin",
    cache: "no-store",
    headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error("Сервер не ответил. Введённые данные сохранены в форме.");
  }
  if (!response.ok)
    throw new Error(
      response.status === 401
        ? "Сессия завершена. Войдите снова в отдельной вкладке, затем повторите действие."
        : (data.error ?? "Не удалось выполнить действие."),
    );
  return data;
}
export function errorText(error: unknown) {
  return error instanceof TypeError || error instanceof SyntaxError
    ? "Не удалось связаться с сервером. Повторите попытку."
    : error instanceof Error
      ? error.message
      : "Не удалось связаться с сервером. Повторите попытку.";
}
