"use client";
import Link from "next/link";
import { useState } from "react";
import { defaultSettings } from "@/lib/admin/contracts";
import { adminRequest, errorText } from "./api";
export default function SettingsForms({
  initial,
  csrf,
}: {
  initial: typeof defaultSettings;
  csrf: string;
}) {
  const [values, setValues] = useState(initial);
  const [busy, setBusy] = useState<string | null>(null);
  const [messages, setMessages] = useState<
    Record<string, { error?: string; ok?: string }>
  >({});
  function change(group: "company" | "contacts", key: string, value: string) {
    setValues((prev) => ({
      ...prev,
      [group]: { ...prev[group], [key]: value },
    }));
    setMessages((prev) => ({ ...prev, [group]: {} }));
  }
  async function save(e: React.FormEvent, key: keyof typeof defaultSettings) {
    e.preventDefault();
    setBusy(key);
    setMessages((prev) => ({ ...prev, [key]: {} }));
    try {
      await adminRequest(
        "/api/admin/settings",
        csrf,
        { key, value: values[key] },
        "PATCH",
      );
      setMessages((prev) => ({
        ...prev,
        [key]: { ok: "Черновик сохранён. Публичный сайт не изменён." },
      }));
    } catch (error) {
      setMessages((prev) => ({ ...prev, [key]: { error: errorText(error) } }));
    } finally {
      setBusy(null);
    }
  }
  const groups = [
    {
      key: "company" as const,
      title: "Информация о компании",
      description:
        "Подтверждённые сведения владельца. Сохраняются как внутренний черновик.",
      fields: [
        { key: "displayName", label: "Название бренда", max: 100 },
        { key: "legalName", label: "Официальное наименование", max: 200 },
        {
          key: "description",
          label: "Описание компании",
          max: 2000,
          multiline: true,
        },
      ],
    },
    {
      key: "contacts" as const,
      title: "Контакты",
      description:
        "Пока поля не заполнены, реальных каналов связи нет. Заполнение не включает отправку заявок.",
      fields: [
        { key: "phone", label: "Телефон", max: 40, type: "tel" },
        { key: "whatsapp", label: "WhatsApp", max: 40, type: "tel" },
        { key: "email", label: "Email", max: 254, type: "email" },
        { key: "address", label: "Публичный адрес / формат встреч", max: 500 },
        { key: "hours", label: "Время для связи и часовой пояс", max: 200 },
      ],
    },
  ];
  return (
    <div className="admin-settings-grid">
      {groups.map((group) => (
        <form
          className="admin-card admin-form"
          key={group.key}
          onSubmit={(e) => void save(e, group.key)}
        >
          <h2>{group.title}</h2>
          <p className="admin-help">{group.description}</p>
          {group.fields.map((field) => {
            const id = `setting-${group.key}-${field.key}`;
            const value = (values[group.key] as Record<string, string>)[
              field.key
            ];
            return (
              <div key={id} className="admin-field">
                <label htmlFor={id}>{field.label}</label>
                {"multiline" in field && field.multiline ? (
                  <textarea
                    id={id}
                    rows={4}
                    value={value}
                    maxLength={field.max}
                    onChange={(e) =>
                      change(group.key, field.key, e.target.value)
                    }
                  />
                ) : (
                  <input
                    id={id}
                    type={"type" in field ? field.type : "text"}
                    value={value}
                    maxLength={field.max}
                    onChange={(e) =>
                      change(group.key, field.key, e.target.value)
                    }
                  />
                )}
              </div>
            );
          })}
          {messages[group.key]?.error && (
            <p role="alert" className="admin-alert">
              {messages[group.key].error}
            </p>
          )}
          <button className="admin-button" disabled={busy !== null}>
            {busy === group.key ? "Сохраняем…" : "Сохранить черновик"}
          </button>
          <p role="status" className="admin-save-status">
            {messages[group.key]?.ok}
          </p>
        </form>
      ))}
      <form
        className="admin-card admin-form admin-notification-settings"
        onSubmit={(e) => void save(e, "notifications")}
      >
        <h2>Email: черновик уведомлений</h2>
        <p className="admin-help">
          Структура событий подготовлена. Доставка не подключена; секреты здесь
          не вводятся.
        </p>
        <label className="admin-check">
          <input type="checkbox" checked={false} disabled />
          Email — не настроен
        </label>
        <p className="admin-help">
          <Link href="/admin/telegram">Управление Telegram →</Link>
        </p>
        <fieldset>
          <legend>События для будущего email-подключения</legend>
          {[
            { id: "inquiry.created", label: "Появление новой заявки" },
            { id: "inquiry.status_changed", label: "Изменение статуса" },
          ].map((event) => (
            <label className="admin-check" key={event.id}>
              <input
                type="checkbox"
                checked={values.notifications.events.includes(event.id)}
                onChange={(e) => {
                  setValues((prev) => ({
                    ...prev,
                    notifications: {
                      ...prev.notifications,
                      events: e.target.checked
                        ? [...prev.notifications.events, event.id]
                        : prev.notifications.events.filter(
                            (id) => id !== event.id,
                          ),
                    },
                  }));
                  setMessages((prev) => ({ ...prev, notifications: {} }));
                }}
              />
              {event.label}
            </label>
          ))}
        </fieldset>
        {messages.notifications?.error && (
          <p role="alert" className="admin-alert">
            {messages.notifications.error}
          </p>
        )}
        <button className="admin-button secondary" disabled={busy !== null}>
          {busy === "notifications" ? "Сохраняем…" : "Сохранить предпочтения"}
        </button>
        <p role="status" className="admin-save-status">
          {messages.notifications?.ok}
        </p>
      </form>
    </div>
  );
}
