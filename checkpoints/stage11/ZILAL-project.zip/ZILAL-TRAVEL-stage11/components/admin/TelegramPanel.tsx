"use client";
import { useState } from "react";
import { adminRequest, errorText } from "./api";
import { adminDate } from "@/lib/admin/contracts";
import {
  events,
  eventLabels,
  deliveryLabels,
  errorLabels,
  type TelegramState,
  type TelegramAction,
} from "@/lib/telegram/contracts";
export default function TelegramPanel({
  initial,
  csrf,
  intakeMode = "disabled",
}: {
  initial: TelegramState;
  csrf: string;
  intakeMode?: "disabled" | "test" | "live";
}) {
  const [data, setData] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [botId, setBotId] = useState("");
  const [botName, setBotName] = useState("");
  const [token, setToken] = useState("");
  const [botEnabled, setBotEnabled] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [confirmation, setConfirmation] = useState("");
  const [recipientId, setRecipientId] = useState("");
  const [recipientBot, setRecipientBot] = useState("");
  const [recipientName, setRecipientName] = useState("");
  const [chatId, setChatId] = useState("");
  const [recipientEnabled, setRecipientEnabled] = useState(false);
  const [routing, setRouting] = useState(() =>
    events.map((event) => ({
      event,
      enabled: initial.events.find((e) => e.event === event)?.enabled ?? false,
      recipientIds: initial.routes
        .filter((r) => r.event === event)
        .map((r) => r.recipientId),
    })),
  );
  async function refresh(page = data.page) {
    const response = await fetch(`/api/admin/telegram?page=${page}`, {
      cache: "no-store",
      credentials: "same-origin",
    });
    if (!response.ok)
      throw new Error(
        response.status === 401
          ? "Сессия завершена. Войдите снова."
          : "Не удалось обновить журнал.",
      );
    const updated = await response.json();
    setData(updated);
    return updated as TelegramState;
  }
  async function act(action: TelegramAction, done?: () => void) {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const result = await adminRequest("/api/admin/telegram", csrf, action);
      setMessage(result.message);
      if (action.action === "bot.create" || action.action === "bot.update")
        setToken("");
      done?.();
      const updated = await refresh();
      setRouting(
        events.map((event) => ({
          event,
          enabled:
            updated.events.find((e) => e.event === event)?.enabled ?? false,
          recipientIds: updated.routes
            .filter((r) => r.event === event)
            .map((r) => r.recipientId),
        })),
      );
    } catch (e) {
      setError(errorText(e));
      await refresh().catch(() => {});
    } finally {
      setBusy(false);
    }
  }
  function clearBot() {
    setBotId("");
    setBotName("");
    setToken("");
    setBotEnabled(false);
  }
  function clearRecipient() {
    setRecipientId("");
    setRecipientBot("");
    setRecipientName("");
    setChatId("");
    setRecipientEnabled(false);
  }
  return (
    <>
      <div className="admin-page-heading">
        <div>
          <p className="admin-eyebrow">Уведомления и связь</p>
          <h1>Telegram. Под контролем.</h1>
          <p>
            Боты, получатели и история доставки — в защищённом рабочем
            пространстве.
          </p>
        </div>
        <span className="admin-chip">
          {intakeMode === "live"
            ? "Приём заявок включён"
            : intakeMode === "test"
              ? "Локальный тест приёма"
              : "Публичные заявки отключены"}
        </span>
      </div>
      <div className="telegram-health">
        <span>
          Шифрование:{" "}
          <strong>
            {data.keyReady ? "ключ доступен" : "нужна настройка ключа"}
          </strong>
        </span>
        <span>
          Сеть:{" "}
          <strong>
            {data.networkEnabled ? "разрешена сервером" : "отключена сервером"}
          </strong>
        </span>
        <span>
          Обработчик:{" "}
          <strong>
            {data.lastWorkerRun
              ? `${Date.now() - new Date(data.lastWorkerRun).getTime() > 300000 ? "нет свежей отметки · " : "последний запуск · "}${adminDate(data.lastWorkerRun)}`
              : "ещё не запускался"}
          </strong>
        </span>
      </div>
      <p className="admin-notice">
        Токены после сохранения не показываются. Сообщения содержат только
        номер, тип, тур, время и статус заявки. Полные контакты остаются в
        админке. Доставка выполняется отдельным обработчиком очереди.
      </p>
      {error && (
        <p className="admin-alert" role="alert">
          {error}
        </p>
      )}
      <p className="admin-save-status" role="status" aria-live="polite">
        {message}
      </p>
      <div className="telegram-columns">
        <section className="admin-card">
          <h2>Подключённые боты</h2>
          {!data.bots.length ? (
            <div className="admin-empty">
              <h3>Интеграция пока не настроена</h3>
              <p>
                Добавьте своего бота после настройки серверного ключа. Готовых
                токенов в проекте нет.
              </p>
            </div>
          ) : (
            <ul className="telegram-items">
              {data.bots.map((bot) => (
                <li key={bot.id}>
                  <div>
                    <strong>{bot.name}</strong>
                    <span className="admin-chip">
                      {bot.enabled ? "Включён" : "Выключен"}
                    </span>
                  </div>
                  <p className="admin-help">
                    {bot.checkStatus === "verified"
                      ? `Проверен${bot.username ? ` · @${bot.username}` : ""}`
                      : bot.checkStatus === "error"
                        ? "Проверка не пройдена"
                        : "Не проверен"}
                    {bot.checkedAt ? ` · ${adminDate(bot.checkedAt)}` : ""}
                  </p>
                  {bot.lastError && (
                    <p className="admin-help">
                      {errorLabels[bot.lastError] ?? "Ошибка подключения"}
                    </p>
                  )}
                  <div className="telegram-actions">
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => {
                        setBotId(bot.id);
                        setBotName(bot.name);
                        setToken("");
                        setBotEnabled(bot.enabled);
                      }}
                    >
                      Редактировать
                    </button>
                    <button
                      type="button"
                      disabled={busy || !data.networkEnabled || !data.keyReady}
                      onClick={() =>
                        void act({ action: "bot.check", id: bot.id })
                      }
                    >
                      Проверить
                    </button>
                    <button
                      type="button"
                      disabled={
                        busy || (!bot.enabled && bot.checkStatus !== "verified")
                      }
                      onClick={() =>
                        void act({
                          action: "bot.update",
                          id: bot.id,
                          name: bot.name,
                          enabled: !bot.enabled,
                        })
                      }
                    >
                      {bot.enabled ? "Выключить" : "Включить"}
                    </button>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => {
                        setDeleting(bot.id);
                        setConfirmation("");
                      }}
                    >
                      Удалить
                    </button>
                  </div>
                  {deleting === bot.id && (
                    <form
                      className="telegram-delete"
                      onSubmit={(e) => {
                        e.preventDefault();
                        void act(
                          { action: "bot.delete", id: bot.id, confirmation },
                          () => {
                            setDeleting(null);
                            if (botId === bot.id) clearBot();
                          },
                        );
                      }}
                    >
                      <p>
                        Будут удалены токен, получатели и правила этого бота;
                        ожидающие задания отменятся. История останется. Уже
                        начатую отправку отозвать нельзя.
                      </p>
                      <label htmlFor="delete-bot-confirm">
                        Введите название «{bot.name}»
                      </label>
                      <input
                        id="delete-bot-confirm"
                        value={confirmation}
                        onChange={(e) => setConfirmation(e.target.value)}
                        required
                        maxLength={100}
                      />
                      <div className="telegram-actions">
                        <button
                          type="submit"
                          disabled={busy || confirmation !== bot.name}
                        >
                          Подтвердить удаление
                        </button>
                        <button type="button" onClick={() => setDeleting(null)}>
                          Отмена
                        </button>
                      </div>
                    </form>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
        <form
          className="admin-card admin-form"
          onSubmit={(e) => {
            e.preventDefault();
            void act(
              botId
                ? {
                    action: "bot.update",
                    id: botId,
                    name: botName,
                    enabled: botEnabled,
                    ...(token ? { token } : {}),
                  }
                : { action: "bot.create", name: botName, token },
              clearBot,
            );
          }}
        >
          <h2>{botId ? "Изменить подключение" : "Добавить бота"}</h2>
          <label htmlFor="telegram-bot-name">Название подключения</label>
          <input
            id="telegram-bot-name"
            value={botName}
            onChange={(e) => setBotName(e.target.value)}
            required
            maxLength={100}
          />
          <label htmlFor="telegram-token">
            {botId ? "Новый токен (необязательно)" : "Токен от BotFather"}
          </label>
          <input
            id="telegram-token"
            type="password"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            required={!botId}
            minLength={32}
            maxLength={150}
            autoComplete="new-password"
            spellCheck={false}
            aria-describedby="telegram-token-help"
          />
          <p id="telegram-token-help" className="admin-help">
            Оставьте пустым, чтобы сохранить прежний токен. При замене бот
            выключается и требует новой проверки; ожидающие отправки отменяются.
          </p>
          {botId && (
            <label className="admin-check">
              <input
                type="checkbox"
                checked={botEnabled}
                onChange={(e) => setBotEnabled(e.target.checked)}
              />
              Бот включён
            </label>
          )}
          <button className="admin-button" disabled={busy || !data.keyReady}>
            {busy
              ? "Сохраняем…"
              : botId
                ? "Сохранить подключение"
                : "Сохранить бота"}
          </button>
          {botId && (
            <button
              type="button"
              className="admin-button secondary"
              onClick={clearBot}
            >
              Отменить редактирование
            </button>
          )}
          {!data.keyReady && (
            <p className="admin-help">
              Администратору сервера нужно настроить TELEGRAM_KEY_FILE вне
              проекта. Токен до этого не сохраняется.
            </p>
          )}
        </form>
      </div>
      <div className="telegram-columns">
        <section className="admin-card">
          <h2>Получатели</h2>
          {!data.recipients.length ? (
            <p className="admin-help">
              Получатели ещё не добавлены. Chat ID — идентификатор чата, а не
              номер телефона.
            </p>
          ) : (
            <ul className="telegram-items">
              {data.recipients.map((recipient) => (
                <li key={recipient.id}>
                  <strong>{recipient.name}</strong>
                  <p className="admin-help">
                    {data.bots.find((b) => b.id === recipient.botId)?.name ??
                      "Бот удалён"}{" "}
                    · Chat ID: {recipient.chatId} ·{" "}
                    {recipient.enabled ? "Включён" : "Выключен"}
                  </p>
                  <div className="telegram-actions">
                    <button
                      disabled={busy}
                      onClick={() => {
                        setRecipientId(recipient.id);
                        setRecipientBot(recipient.botId);
                        setRecipientName(recipient.name);
                        setChatId(recipient.chatId);
                        setRecipientEnabled(recipient.enabled);
                      }}
                    >
                      Изменить
                    </button>
                    <button
                      disabled={busy || !data.networkEnabled}
                      onClick={() =>
                        void act({
                          action: "test.send",
                          recipientId: recipient.id,
                          requestId: crypto.randomUUID(),
                        })
                      }
                    >
                      Тестовое сообщение
                    </button>
                    <button
                      disabled={busy}
                      onClick={() =>
                        void act({
                          action: "recipient.save",
                          id: recipient.id,
                          botId: recipient.botId,
                          name: recipient.name,
                          chatId: recipient.chatId,
                          enabled: !recipient.enabled,
                        })
                      }
                    >
                      {recipient.enabled ? "Выключить" : "Включить"}
                    </button>
                    <button
                      disabled={busy}
                      onClick={() => {
                        if (
                          window.confirm(
                            "Удалить получателя и его правила? Ожидающие задания будут отменены.",
                          )
                        )
                          void act({
                            action: "recipient.delete",
                            id: recipient.id,
                          });
                      }}
                    >
                      Удалить
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
        <form
          className="admin-card admin-form"
          onSubmit={(e) => {
            e.preventDefault();
            void act(
              {
                action: "recipient.save",
                ...(recipientId ? { id: recipientId } : {}),
                botId: recipientBot,
                name: recipientName,
                chatId,
                enabled: recipientEnabled,
              },
              clearRecipient,
            );
          }}
        >
          <h2>{recipientId ? "Изменить получателя" : "Добавить получателя"}</h2>
          <label htmlFor="recipient-name">Название получателя</label>
          <input
            id="recipient-name"
            value={recipientName}
            onChange={(e) => setRecipientName(e.target.value)}
            required
            maxLength={100}
          />
          <label htmlFor="recipient-bot">Бот получателя</label>
          <select
            id="recipient-bot"
            value={recipientBot}
            onChange={(e) => setRecipientBot(e.target.value)}
            required
          >
            <option value="">Выберите бота</option>
            {data.bots.map((bot) => (
              <option key={bot.id} value={bot.id}>
                {bot.name}
              </option>
            ))}
          </select>
          <label htmlFor="recipient-chat">Telegram Chat ID</label>
          <input
            id="recipient-chat"
            value={chatId}
            onChange={(e) => setChatId(e.target.value)}
            required
            maxLength={17}
            inputMode="text"
            aria-describedby="chat-help"
          />
          <p id="chat-help" className="admin-help">
            Для личного чата — числовой ID; для группы обычно отрицательный. Без
            «+», пробелов, @username и номера телефона. Пользователь должен
            сначала запустить бота; для группы нужны разрешения на отправку.
          </p>
          <label className="admin-check">
            <input
              type="checkbox"
              checked={recipientEnabled}
              onChange={(e) => setRecipientEnabled(e.target.checked)}
            />
            Получатель включён
          </label>
          <p className="admin-help">
            При смене Chat ID или бота прежние правила удаляются — выберите их
            заново.
          </p>
          <button className="admin-button" disabled={busy || !data.bots.length}>
            Сохранить получателя
          </button>
          {recipientId && (
            <button
              type="button"
              className="admin-button secondary"
              onClick={clearRecipient}
            >
              Отмена
            </button>
          )}
        </form>
      </div>
      <form
        className="admin-card telegram-routing"
        onSubmit={(e) => {
          e.preventDefault();
          void act({ action: "routes.save", routes: routing });
        }}
      >
        <h2>События и маршрутизация</h2>
        <p className="admin-help">
          Выберите получателей под нужными ботами. Включённое событие требует
          проверенных активных подключений. Изменение правил отменяет старые
          ожидающие уведомления событий.
        </p>
        {routing.map((rule, index) => (
          <fieldset key={rule.event}>
            <legend>{eventLabels[rule.event]}</legend>
            <label className="admin-check">
              <input
                type="checkbox"
                checked={rule.enabled}
                onChange={(e) =>
                  setRouting((prev) =>
                    prev.map((r, i) =>
                      i === index ? { ...r, enabled: e.target.checked } : r,
                    ),
                  )
                }
              />
              Событие включено
            </label>
            {data.bots.map((bot) => (
              <div key={bot.id} className="telegram-route-bot">
                <strong>
                  {bot.name} ·{" "}
                  {bot.enabled && bot.checkStatus === "verified"
                    ? "активен"
                    : "нужна проверка/включение"}
                </strong>
                {data.recipients
                  .filter((r) => r.botId === bot.id)
                  .map((recipient) => (
                    <label className="admin-check" key={recipient.id}>
                      <input
                        type="checkbox"
                        checked={rule.recipientIds.includes(recipient.id)}
                        onChange={(e) =>
                          setRouting((prev) =>
                            prev.map((r, i) =>
                              i === index
                                ? {
                                    ...r,
                                    recipientIds: e.target.checked
                                      ? [...r.recipientIds, recipient.id]
                                      : r.recipientIds.filter(
                                          (id) => id !== recipient.id,
                                        ),
                                  }
                                : r,
                            ),
                          )
                        }
                      />
                      {recipient.name}
                      {recipient.enabled ? "" : " · выключен"}
                    </label>
                  ))}
              </div>
            ))}
          </fieldset>
        ))}
        <button className="admin-button" disabled={busy}>
          Сохранить события
        </button>
      </form>
      <section className="admin-card telegram-log">
        <div className="admin-card-heading">
          <div>
            <h2>Журнал уведомлений</h2>
            <p className="admin-help">
              Доставка подтверждается только ответом Telegram. При таймауте
              результат может быть неизвестен; повтор иногда создаёт дубликат.
            </p>
          </div>
          <button
            className="admin-button secondary"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              setError("");
              try {
                await refresh();
              } catch (e) {
                setError(errorText(e));
              } finally {
                setBusy(false);
              }
            }}
          >
            Обновить журнал
          </button>
        </div>
        {!data.log.length ? (
          <div className="admin-empty">
            <h3>Отправок пока нет</h3>
            <p>
              Здесь появятся реальные задания очереди, а не демонстрационная
              статистика.
            </p>
          </div>
        ) : (
          <div className="admin-table-scroll">
            <table className="admin-table">
              <caption className="admin-visually-hidden">
                Журнал Telegram-уведомлений
              </caption>
              <thead>
                <tr>
                  <th>Событие</th>
                  <th>Получатель / бот</th>
                  <th>Создано / обновлено</th>
                  <th>Статус</th>
                  <th>Попытки</th>
                </tr>
              </thead>
              <tbody>
                {data.log.map((job) => (
                  <tr key={job.id}>
                    <td>
                      {eventLabels[job.event as keyof typeof eventLabels] ??
                        job.event}
                    </td>
                    <td>
                      {job.recipientName}
                      <small>{job.botName}</small>
                    </td>
                    <td>
                      {adminDate(job.createdAt)}
                      <small>{adminDate(job.updatedAt)}</small>
                    </td>
                    <td>
                      {deliveryLabels[
                        job.status as keyof typeof deliveryLabels
                      ] ?? job.status}
                      {job.errorCode && (
                        <small>
                          {job.errorCode}:{" "}
                          {errorLabels[job.errorCode] ?? "Ошибка"}
                        </small>
                      )}
                      {job.status === "retry" && (
                        <small>Не раньше {adminDate(job.runAt)}</small>
                      )}
                    </td>
                    <td>{job.attempts} / 3</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {data.total > data.pageSize && (
          <nav className="admin-pagination" aria-label="Страницы журнала">
            <button
              disabled={busy || data.page === 1}
              onClick={() => {
                setBusy(true);
                void refresh(data.page - 1)
                  .catch((e) => setError(errorText(e)))
                  .finally(() => setBusy(false));
              }}
            >
              Назад
            </button>
            <span>
              {data.page} / {Math.ceil(data.total / data.pageSize)}
            </span>
            <button
              disabled={busy || data.page * data.pageSize >= data.total}
              onClick={() => {
                setBusy(true);
                void refresh(data.page + 1)
                  .catch((e) => setError(errorText(e)))
                  .finally(() => setBusy(false));
              }}
            >
              Далее
            </button>
          </nav>
        )}
      </section>
    </>
  );
}
