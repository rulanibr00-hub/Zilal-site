"use client";
import { usePathname } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { IntakeProvider } from "@/components/inquiries/IntakeProvider";
import VisualMotion from "@/components/VisualMotion";
export default function SiteFrame({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  if (pathname === "/admin" || pathname.startsWith("/admin/"))
    return <>{children}</>;
  return (
    <IntakeProvider>
      <a className="skip-link" href="#main">
        Перейти к содержимому
      </a>
      <VisualMotion />
      <Header />
      <main id="main">{children}</main>
      <Footer />
    </IntakeProvider>
  );
}
