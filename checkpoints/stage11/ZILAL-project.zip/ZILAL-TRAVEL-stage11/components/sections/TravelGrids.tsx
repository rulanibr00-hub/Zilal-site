import TravelCard from "@/components/ui/TravelCard";
import { destinationCards } from "@/lib/content";
import { tourConcepts } from "@/lib/data/tours";
export function TourConceptGrid() {
  return (
    <div className="tour-grid">
      {tourConcepts.map((t) => (
        <TravelCard
          key={t.id}
          variant="tour"
          href={`/tours#${t.id}`}
          title={t.title.ru}
          description={t.description.ru}
          eyebrow={t.eyebrow.ru}
          image={t.image}
        />
      ))}
    </div>
  );
}
export function DestinationGrid() {
  return (
    <div className="destination-grid">
      {destinationCards.map((d, index) => (
        <TravelCard
          key={d.id}
          variant="destination"
          href={`/destinations#${d.id}`}
          title={d.name}
          description={d.caption}
          eyebrow={d.tag}
          image={d.image}
          index={index}
        />
      ))}
    </div>
  );
}
