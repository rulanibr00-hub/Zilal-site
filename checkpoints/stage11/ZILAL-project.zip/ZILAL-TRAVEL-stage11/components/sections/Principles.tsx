import { CmsText } from "@/components/cms/ContentProvider";
import { principleDefaults } from "@/lib/cms/extra-defaults";
export default function Principles({page="home"}:{page?:string}) {
 return <section className="benefits wrap" aria-label="Принципы путешествий">{principleDefaults.map(([n,title,description])=><article key={n} data-reveal><span className="benefit-number">{n} —</span><h3><CmsText page={page} slot={`principle-${n}-title`} fallback={title}/></h3><p><CmsText page={page} slot={`principle-${n}-description`} fallback={description}/></p></article>)}</section>;
}
