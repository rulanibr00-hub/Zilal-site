"use client";
import { useIntake } from "@/components/inquiries/IntakeProvider";
import InquiryForm from "@/components/InquiryForm";
export default function ContactSection({
  purpose = "travel",
}: {
  purpose?: "travel" | "inquiry";
}) {
  const { config } = useIntake();
  const inquiry = purpose === "inquiry";
  return (
    <section id="contact" className="contact">
      <div className="wrap contact-grid">
        <div>
          <p className="eyebrow light">
            {inquiry ? "Вопросы и пожелания" : "Первый шаг навстречу горам"}
          </p>
          <h2>
            {inquiry ? (
              <>
                Есть вопрос?
                <br />
                <em>Расскажите.</em>
              </>
            ) : (
              <>
                У каждой истории
                <br />
                есть <em>начало.</em>
              </>
            )}
          </h2>
          <p>
            {inquiry ? (
              config.mode === "disabled" ? (
                "Попробуйте заполнить обращение. Форма проверит поля прямо на странице, но не отправит сообщение."
              ) : (
                "Задайте вопрос или расскажите о пожеланиях. После сохранения вы получите номер обращения."
              )
            ) : (
              <>
                Каким будет ваше?
                <br />
                Начните с нескольких слов о путешествии мечты.
              </>
            )}
          </p>
          <div className="demo-badge">
            {config.mode === "live"
              ? "ЛИЧНЫЙ ПОДХОД К ВАШЕМУ ОБРАЩЕНИЮ"
              : config.mode === "test"
                ? "ЛОКАЛЬНЫЙ ТЕСТ · ЗАПИСЬ В ТЕСТОВУЮ БД"
                : "ДЕМО · СООБЩЕНИЯ НЕ ОТПРАВЛЯЮТСЯ"}
          </div>
        </div>
        <InquiryForm purpose={purpose} />
      </div>
    </section>
  );
}
