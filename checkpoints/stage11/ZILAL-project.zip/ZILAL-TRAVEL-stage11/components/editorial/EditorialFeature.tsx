import type { ReactNode } from "react";
import Photo from "@/components/Photo";
import { isDocumentedPhoto, photos } from "@/lib/media";
import type { PhotoKey } from "@/lib/types";
export default function EditorialFeature({
  id,
  eyebrow,
  title,
  accent,
  image,
  caption,
  children,
  reverse = false,
}: {
  id?: string;
  eyebrow: React.ReactNode;
  title: React.ReactNode;
  accent: React.ReactNode;
  image: PhotoKey;
  caption: React.ReactNode;
  children: ReactNode;
  reverse?: boolean;
}) {
  return (
    <section
      id={id}
      className={`editorial-feature${reverse ? " reverse" : ""}`}
    >
      <div className="wrap editorial-feature-grid">
        <figure className="editorial-visual" data-reveal>
          <Photo name={image} slot="editorial" />
          <figcaption>
            {isDocumentedPhoto(photos[image]) ? photos[image].label : caption}
          </figcaption>
        </figure>
        <div className="editorial-copy" data-reveal>
          <p className="eyebrow">{eyebrow}</p>
          <h2>
            {title}
            <br />
            <em>{accent}</em>
          </h2>
          <div className="editorial-prose">{children}</div>
        </div>
      </div>
    </section>
  );
}
