import Image from "next/image";
import type { CSSProperties } from "react";
import {
  isDocumentedPhoto,
  photos,
  photoSizes,
  type PhotoSlot,
} from "@/lib/media";
import type { PhotoKey } from "@/lib/types";
import LandscapeIllustration from "@/components/media/LandscapeIllustration";
export default function Photo({
  name,
  priority = false,
  slot = "editorial",
  sizes,
  decorative = false,
}: {
  name: PhotoKey;
  priority?: boolean;
  slot?: PhotoSlot;
  sizes?: string;
  decorative?: boolean;
}) {
  const asset = photos[name];
  if (isDocumentedPhoto(asset)) {
    const focal = asset.focalPoint ?? { x: 50, y: 50 };
    const mobile = asset.mobileFocalPoint ?? focal;
    return (
      <Image
        className="scene-photo scene-photo--photo"
        src={asset.src}
        alt={decorative ? "" : asset.alt}
        fill
        sizes={sizes ?? photoSizes[slot]}
        preload={priority}
        loading={priority ? undefined : "lazy"}
        decoding="async"
        style={
          {
            "--photo-focus": `${focal.x}% ${focal.y}%`,
            "--photo-focus-mobile": `${mobile.x}% ${mobile.y}%`,
          } as CSSProperties
        }
      />
    );
  }
  return (
    <div
      className={`scene-photo scene-photo--illustration placeholder-${name}`}
      role={decorative ? undefined : "img"}
      aria-label={decorative ? undefined : asset.alt}
      aria-hidden={decorative || undefined}
    >
      <LandscapeIllustration name={name} />
    </div>
  );
}
