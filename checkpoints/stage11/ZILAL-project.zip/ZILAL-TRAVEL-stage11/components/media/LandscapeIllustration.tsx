import type { PhotoKey } from "@/lib/types";
const palettes = {
  hero: ["#b5c8c5", "#dee0cf", "#96b2ae", "#587f7c", "#345e57", "#183e35"],
  mountain: ["#b9cece", "#f2e9d6", "#9db2ad", "#6a8983", "#41685e", "#234b3d"],
  alakul: ["#a8cbd0", "#e9e7d6", "#849eaa", "#5b7d89", "#2f6372", "#244d50"],
  lake: ["#c7d9d4", "#f7edda", "#9bbab9", "#7caaa8", "#4c8989", "#315f5e"],
  pasture: ["#cdd7c4", "#f0e8cf", "#a6b89a", "#889a70", "#627c51", "#3e5d40"],
  canyon: ["#d7d7c2", "#f1e4cc", "#aab8a4", "#bd946e", "#a66e49", "#734e34"],
  karakol: ["#c7d5cc", "#ede5cf", "#acbbb0", "#7d9c8b", "#4e785e", "#31553e"],
  culture: ["#d8dbc2", "#f4e5c6", "#adba9d", "#8f9e73", "#697c4f", "#495e3b"],
} as const;
export default function LandscapeIllustration({ name }: { name: PhotoKey }) {
  const p = palettes[name];
  const water = name === "lake" || name === "pasture" || name === "alakul";
  return (
    <svg
      className={`landscape-art landscape-art--${name}`}
      viewBox="0 0 1600 1000"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
      focusable="false"
    >
      <path fill={p[0]} d="M0 0h1600v1000H0z" />
      <circle cx="1240" cy="180" r="95" fill={p[1]} opacity=".8" />
      <path
        d="M0 200C210 130 330 240 550 180S900 170 1070 115s380 35 530-20v120c-180 40-280-12-460 20s-330 8-530 30S210 240 0 295Z"
        fill={p[1]}
        opacity=".22"
      />
      <path
        fill={p[2]}
        d="M0 460l90-48 62 21 100-117 44 24 90-128 76 75 54-23 110 97 53-46 83 62 72-50 70 39 89-121 53 24 103-163 63 70 37-10 64 107 72-30 69 92 57-15 64 93v592H0Z"
      />
      <path
        fill={p[1]}
        opacity=".82"
        d="m338 281 48-69 76 75 54-23 63 56-52-12-22 21-44-33-19 16-29-42-20 29-31-7-27 21Zm645-37 23-31 53 24 103-163 63 70 37-10 64 107-46-23-34-50-22 12-40-43-25 65-21-21-28 34-21-7-19 47-30-13-35 19Z"
      />
      <path
        fill={p[3]}
        d="M0 605 90 551l90 10 82-120 74 27 74-38 106 121 52-30 74 65 104-41 86 34 57-52 63 27 105-94 45 12 102-117 69 47 75-34 68 108 84 16 68-30 70 97 67-16v414H0Z"
      />
      <path
        fill={p[1]}
        opacity=".18"
        d="m262 441 74 27 74-38 106 121-93-33-28 21-36-42-41 18-26-34-29 18Z"
      />
      {water && (
        <>
          <path
            fill={name === "alakul" ? "#4b9da4" : "#73a8a4"}
            d="M0 650c290-55 390 22 610-14s510 35 990-23v387H0Z"
          />
          <path
            fill="#d5e1ce"
            opacity=".32"
            d="M0 702c290-43 470 15 650-8s500 20 950-18v11c-430 38-650-3-940 23S210 681 0 716Z"
          />
          <path
            fill="#dbe3cd"
            opacity=".22"
            d="M250 774c250-25 470-12 710-30l370 9-430 8-300 24Z"
          />
        </>
      )}
      {name === "canyon" ? (
        <>
          <path
            fill="#c59b6b"
            d="m0 790 98-35 20-99 37-14 8-80 48-14 35 73 48 5 15 74 56 17 23-174 39-28 10-112 33-16 43 87 39 16 5 91 57 25 45 126 84 35 37-103 39-8 15-118 38-25 11-87 28 2 19 77 45 35 10 99 48 19 45 88 107 24 25-214 37-14 15-77 32 2 24 72 40 21 18 115 81 35 58-67 35 3 39 89 73 30v288H0Z"
          />
          <path
            fill="#9c6b49"
            d="m0 874 150-14 106-90 106 33 95-112 42 31 53 110 114 47 120-30 111-89 71 45 77-71 42 70 123 18 80-97 47 4 85 85 83 16v170H0Z"
          />
          <path
            d="m435 542 12 92-39 120m455-89-12 130m407-183 12 120"
            stroke="#e5c28f"
            strokeWidth="7"
            fill="none"
            opacity=".5"
          />
        </>
      ) : (
        <path
          fill={p[4]}
          d={
            water
              ? "M0 810c150-44 220-23 325 20l150 65 225 40 360-22 275-120 265 29v178H0Z"
              : "M0 792c180-115 330-36 490-63s305 82 430 24 220-80 360-37l320-54v338H0Z"
          }
        />
      )}
      <path
        fill={p[5]}
        d="M0 900c210-85 320-26 525-18s305 66 495-5 345-36 580-91v214H0Z"
        opacity=".94"
      />
      {(name === "mountain" || name === "hero") && (
        <g fill={p[5]}>
          {[70, 165, 245, 1320, 1410, 1520].map((x, i) => (
            <path
              key={x}
              transform={`translate(${x} ${680 + (i % 3) * 28}) scale(${0.8 + (i % 3) * 0.3})`}
              d="M0 0-24 58h15l-30 53h24l-30 65h40v36h10v-36h40l-30-65h24L9 58h15Z"
            />
          ))}
        </g>
      )}
      {(name === "culture" || name === "pasture") && (
        <g
          transform={
            name === "culture"
              ? "translate(1030 650) scale(1.5)"
              : "translate(1060 712) scale(.55)"
          }
        >
          <path
            fill="#e5d8b9"
            d="M-150 70q4-110 150-146Q146-40 150 70v70h-300Z"
          />
          <path fill="#c9b58b" d="M-150 70q145-40 300 0v70h-300Z" />
          <path
            d="M-135 76q135-34 270 0m-132-135v100"
            fill="none"
            stroke="#8e6548"
            strokeWidth="5"
          />
          <path fill="#584c36" d="M-28 57h56v83h-56Z" />
          <path
            fill="none"
            stroke="#9b7351"
            strokeWidth="4"
            d="m-120 105 20-12 20 12 20-12 20 12m80 0 20-12 20 12 20-12 20 12"
          />
        </g>
      )}
      {name === "karakol" && (
        <g transform="translate(690 640)">
          <path fill="#bd9f73" d="M0 60h410v170H0Z" />
          <path fill="#637061" d="m-24 65 128-97 126 97 92-75 110 75Z" />
          <path
            fill="#e6d9b9"
            d="M27 98h60v63H27Zm112 0h60v63h-60Zm119 0h60v63h-60Zm84 0h42v100h-42Z"
          />
          <path
            stroke="#6c715b"
            strokeWidth="6"
            d="M57 99v62m-30-30h60m82-32v62m-30-30h60m89-32v62m-30-30h60"
          />
          <path fill="#385c44" d="m-100 10-36 190h72Zm620-20-40 210h80Z" />
        </g>
      )}
      <path
        d="M0 946c240-22 300 36 490 12s340 13 540-32 350 12 570-35"
        stroke={p[1]}
        opacity=".14"
        strokeWidth="3"
        fill="none"
      />
    </svg>
  );
}
