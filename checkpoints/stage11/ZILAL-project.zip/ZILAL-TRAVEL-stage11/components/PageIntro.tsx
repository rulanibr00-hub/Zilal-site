import { PageMediaCaption } from "@/components/cms/ContentProvider";
import { PageImage } from "@/components/cms/ManagedImage";
import Link from "next/link";
import Photo from "@/components/Photo";
import { isDocumentedPhoto, photos } from "@/lib/media";
import type { PhotoKey } from "@/lib/types";
export default function PageIntro({
  title,
  accent,
  eyebrow,
  description,
  cmsPage,
  image = "mountain",
}: {
  title: React.ReactNode;
  accent: React.ReactNode;
  eyebrow: React.ReactNode;
  description: React.ReactNode;
  cmsPage?: string;
  image?: PhotoKey;
}) {
  return (
    <section className="page-intro">
      <div className="wrap page-intro-grid">
        <div>
          <nav className="breadcrumbs" aria-label="Хлебные крошки">
            <Link href="/">Главная</Link>
            <span aria-hidden="true">/</span>
            <span aria-current="page">{eyebrow}</span>
          </nav>
          <p className="eyebrow">{eyebrow}</p>
          <h1>
            {title}
            <br />
            <em>{accent}</em>
          </h1>
          <p className="page-description">{description}</p>
        </div>
        <div className="page-intro-visual" data-reveal>
          {cmsPage ? <PageImage page={cmsPage} fallback={image} priority/> : <Photo name={image} slot="editorial" priority />}
          <span className="image-caption">
            {cmsPage ? <PageMediaCaption page={cmsPage} fallback="Кыргызстан · оригинальная иллюстрация"/> : isDocumentedPhoto(photos[image])
              ? photos[image].label
              : "Кыргызстан · оригинальная иллюстрация"}
          </span>
        </div>
      </div>
    </section>
  );
}
