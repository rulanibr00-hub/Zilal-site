import { PageImage } from "@/components/cms/ManagedImage";
import { PageMediaCaption, CmsText } from "@/components/cms/ContentProvider";
import Link from "next/link";
import Photo from "@/components/Photo";
import { ButtonLink } from "@/components/ui/Button";
import { isDocumentedPhoto, photos } from "@/lib/media";
export default function Hero() {
  return (
    <section
      id="home"
      className="hero hero-cinematic"
      aria-labelledby="hero-title"
    >
      <PageImage page="home" fallback="hero" priority decorative />
      <div className="hero-shade" />
      <div className="hero-content wrap">
        <p className="eyebrow light">
          <span aria-hidden="true" className="hero-kicker-line" /><CmsText page="home" slot="text-d4c0644b7d4a" fallback="Luxury + Adventure · Кыргызстан" /></p>
        <h1 id="hero-title"><CmsText page="home" slot="text-78875a6d5948" fallback="Кыргызстан," /><br /><CmsText page="home" slot="text-5706db5e07f0" fallback="который ты" /><br />
          <em><CmsText page="home" slot="text-a5953e1aa35a" fallback="почувствуешь." /></em>
        </h1>
        <p className="hero-description"><CmsText page="home" slot="text-127bc7dc7fdc" fallback="Выше привычного. Ближе к настоящему." /><br /><CmsText page="home" slot="text-8923485763d3" fallback="Горы, свобода и встречи, которые остаются с вами." /></p>
        <div className="hero-actions">
          <ButtonLink href="/tours" variant="gold"><CmsText page="home" slot="text-fb6de95d90c5" fallback="Найти своё путешествие" /></ButtonLink>
          <Link href="/create-trip" className="hero-secondary"><CmsText page="home" slot="text-01010aaa0d65" fallback="Создать путешествие" /><span aria-hidden="true">→</span>
          </Link>
        </div>
      </div>
      <div className="hero-bottom wrap">
        <div className="hero-place">
          <span className="hero-location-mark" aria-hidden="true">
            +
          </span>
          <span><CmsText page="home" slot="text-569792c57292" fallback="Тянь-Шань · Центральная Азия" /><small>
              <PageMediaCaption page="home" fallback={isDocumentedPhoto(photos.hero)
                ? "Кыргызстан"
                : "Оригинальная иллюстрация · визуальная концепция"}/>
            </small>
          </span>
        </div>
        <Link href="#about" className="hero-scroll"><CmsText page="home" slot="text-3d62165766e3" fallback="Навстречу открытиям" /><span aria-hidden="true">↓</span>
        </Link>
        <span className="hero-number" aria-hidden="true">
          KG<span> / ZILAL TRAVEL</span>
        </span>
      </div>
      <div className="vertical-note" aria-hidden="true"><CmsText page="home" slot="text-1252285c53be" fallback="ПРОСТРАНСТВО ДЛЯ ВАШЕЙ ИСТОРИИ" /></div>
    </section>
  );
}
