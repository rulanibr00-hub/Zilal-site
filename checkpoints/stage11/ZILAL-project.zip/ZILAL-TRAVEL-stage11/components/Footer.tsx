"use client";
import { CompanyContacts } from "@/components/cms/ContentProvider";
import { useIntake } from "@/components/inquiries/IntakeProvider";
import Link from "next/link";
import Brand from "@/components/Brand";
import { navigation } from "@/lib/navigation";
export default function Footer() {
  const { config } = useIntake();
  return (
    <footer className="footer wrap">
      <div className="footer-top">
        <Brand />
        <p>
          Кыргызстан ближе,
          <br />
          чем кажется.
        </p>
        <div>
          <p className="eyebrow">Контакты</p>
          <CompanyContacts compact/>
          <Link href="/contacts" className="text-link">
            Перейти к контактам →
          </Link>
        </div>
      </div>
      <nav className="footer-navigation" aria-label="Навигация в подвале">
        {navigation.map(({ href, label }) => (
          <Link key={href} href={href}>
            {label}
          </Link>
        ))}
      </nav>
      <div className="footer-bottom">
        <span>
          © {new Date().getFullYear()} ZILAL TRAVEL ·{" "}
          {config.mode === "live"
            ? "Приём обращений"
            : config.mode === "test"
              ? "Локальная проверка приёма"
              : "Демонстрационная версия"}
        </span>
        <Link href="/sources">Источники фотографий</Link>
        <Link href="/privacy">Конфиденциальность</Link>
        <a href="#site-top">Наверх ↑</a>
      </div>
    </footer>
  );
}
