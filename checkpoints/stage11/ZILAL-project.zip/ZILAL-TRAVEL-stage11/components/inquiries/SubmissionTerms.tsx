"use client";
import Link from "next/link";
import { useEffect, useId, useRef } from "react";
import type { InquirySubmission } from "./useInquirySubmission";
export function SubmissionTerms({
  submission,
}: {
  submission: InquirySubmission;
}) {
  const id = useId();
  return (
    <>
      <div className="inquiry-honeypot" aria-hidden="true">
        <label htmlFor={`${id}-website`}>Сайт компании</label>
        <input
          id={`${id}-website`}
          ref={submission.website}
          name="company_website"
          tabIndex={-1}
          autoComplete="off"
          maxLength={200}
        />
      </div>
      {submission.config.mode !== "disabled" && (
        <div className="submission-terms">
          <p>{submission.config.notice}</p>
          <p>
            Не указывайте данные документов, сведения о здоровье и другую
            конфиденциальную информацию.
          </p>
          {submission.config.consentRequired && (
            <label className="submission-consent">
              <input
                type="checkbox"
                checked={submission.consent}
                onChange={(e) => {
                  submission.setConsent(e.target.checked);
                  submission.clearError();
                }}
                required
              />
              <span>{submission.config.consentText}</span>
            </label>
          )}
          <Link href="/privacy" target="_blank" rel="noopener noreferrer">
            Политика обработки данных (новая вкладка) →
          </Link>
        </div>
      )}
    </>
  );
}
export function SubmissionResult({
  submission,
}: {
  submission: InquirySubmission;
}) {
  const error = useRef<HTMLParagraphElement>(null);
  const success = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (submission.error) error.current?.focus();
  }, [submission.error]);
  useEffect(() => {
    if (submission.accepted) success.current?.focus();
  }, [submission.accepted]);
  return (
    <>
      {submission.error && (
        <p className="submission-error" ref={error} role="alert" tabIndex={-1}>
          {submission.error}
        </p>
      )}
      {submission.accepted && (
        <div
          className="submission-success"
          ref={success}
          role="status"
          tabIndex={-1}
        >
          <strong>
            {submission.accepted.isTest
              ? "Тестовая заявка принята в тестовую БД."
              : "Заявка принята."}
          </strong>
          <p>
            Номер: <b>{submission.accepted.number}</b>.
          </p>
          <p>
            Параметры сохранены. Это не подтверждение бронирования или доставки
            Telegram-уведомления.
          </p>
        </div>
      )}
    </>
  );
}
