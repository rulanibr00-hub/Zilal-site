"use client";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import {
  disabledConfig,
  type IntakeConfig,
} from "@/lib/inquiries/client-contracts";
const Context = createContext({
  config: disabledConfig,
  loading: true,
  refresh: async () => {},
});
export function IntakeProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<IntakeConfig>(disabledConfig);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      const response = await fetch("/api/inquiries/config", {
        cache: "no-store",
        credentials: "same-origin",
        signal: AbortSignal.timeout(5000),
      });
      if (!response.ok) throw new Error();
      const data = await response.json();
      if (!["disabled", "test", "live"].includes(data.mode)) throw new Error();
      setConfig(data);
    } catch {
      setConfig(disabledConfig);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void refresh();
    const focus = () => void refresh();
    window.addEventListener("focus", focus);
    return () => window.removeEventListener("focus", focus);
  }, [refresh]);
  return (
    <Context.Provider value={{ config, loading, refresh }}>
      {children}
    </Context.Provider>
  );
}
export const useIntake = () => useContext(Context);
