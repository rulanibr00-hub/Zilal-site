"use client";
import { useEffect, useRef, useState } from "react";
import { useIntake } from "./IntakeProvider";
interface Reply {
  accepted: true;
  number: string;
  isTest: boolean;
  duplicate: boolean;
}
class SubmissionError extends Error {
  constructor(
    message: string,
    public code?: string,
    public fields?: Record<string, string>,
  ) {
    super(message);
  }
}
async function read(response: Response) {
  let data;
  try {
    data = await response.json();
  } catch {
    throw new SubmissionError(
      "Сервер не подтвердил приём. Данные сохранены в форме; повторите отправку.",
    );
  }
  if (!response.ok)
    throw new SubmissionError(
      data.error ?? "Не удалось принять заявку.",
      data.code,
      data.fields,
    );
  return data;
}
export function useInquirySubmission() {
  const { config, loading, refresh } = useIntake();
  const [busy, setBusy] = useState(false);
  const [accepted, setAccepted] = useState<Reply | null>(null);
  const [error, setError] = useState("");
  const [fields, setFields] = useState<Record<string, string>>({});
  const [consent, setConsent] = useState(false);
  const website = useRef<HTMLInputElement>(null);
  const lock = useRef(false);
  const retry = useRef<{ body: string; key: string } | null>(null);
  useEffect(() => setConsent(false), [config.policyRevision]);
  function clearError() {
    setError("");
    setFields({});
  }
  async function submit(inquiry: unknown) {
    if (lock.current || accepted) return false;
    clearError();
    if (loading || config.mode === "disabled") {
      setError("Приём заявок отключён. Данные не отправлены.");
      return false;
    }
    if (config.consentRequired && !consent) {
      setError("Подтвердите согласие с указанными условиями обработки данных.");
      return false;
    }
    const body = JSON.stringify({
      inquiry,
      policyRevision: config.policyRevision,
      consent,
      website: website.current?.value ?? "",
    });
    if (retry.current?.body !== body)
      retry.current = { body, key: crypto.randomUUID() };
    lock.current = true;
    setBusy(true);
    try {
      const session = await read(
        await fetch("/api/inquiries/session", {
          method: "POST",
          credentials: "same-origin",
          cache: "no-store",
          headers: { "Content-Type": "application/json" },
          body: "{}",
          signal: AbortSignal.timeout(10000),
        }),
      );
      if (session.policyRevision !== config.policyRevision)
        throw new SubmissionError(
          "Условия обработки данных изменились. Ознакомьтесь с ними повторно.",
          "POLICY_CHANGED",
        );
      const response = await read(
        await fetch("/api/inquiries", {
          method: "POST",
          credentials: "same-origin",
          cache: "no-store",
          headers: {
            "Content-Type": "application/json",
            "X-CSRF-Token": session.csrf,
            "Idempotency-Key": retry.current!.key,
          },
          body,
          signal: AbortSignal.timeout(20000),
        }),
      );
      if (response.accepted !== true || !/^ZL-\d+$/.test(response.number))
        throw new SubmissionError(
          "Сервер не подтвердил номер заявки. Повторите отправку.",
        );
      setAccepted(response);
      return true;
    } catch (e) {
      if (e instanceof SubmissionError) {
        setError(e.message);
        setFields(e.fields ?? {});
        if (
          e.code === "POLICY_CHANGED" ||
          e.code === "PUBLIC_INTAKE_DISABLED"
        ) {
          setConsent(false);
          await refresh();
        }
      } else
        setError(
          "Не удалось получить подтверждение сервера. Данные сохранены в форме. Повторная отправка тех же данных защищена от дублирования.",
        );
      return false;
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  return {
    config,
    loading,
    busy,
    accepted,
    error,
    fields,
    consent,
    setConsent,
    website,
    submit,
    clearError,
  };
}
export type InquirySubmission = ReturnType<typeof useInquirySubmission>;
