"use client";
import Link from "next/link";
import { useId, useState } from "react";
import { Button } from "@/components/ui/Button";
import { inquiryFormPayload } from "@/lib/admin/inquiry-payload";
import { useInquirySubmission } from "@/components/inquiries/useInquirySubmission";
import {
  SubmissionTerms,
  SubmissionResult,
} from "@/components/inquiries/SubmissionTerms";
export default function InquiryForm({
  tourTitle,
  purpose = "travel",
}: {
  tourTitle?: string;
  purpose?: "travel" | "inquiry";
}) {
  const send = useInquirySubmission();
  const off = send.config.mode === "disabled";
  const [reviewed, setReviewed] = useState(false);
  const [error, setError] = useState<{
    field: "name" | "message";
    message: string;
  } | null>(null);
  const prefix = useId(),
    messageId = `${prefix}-message`,
    demoId = `${prefix}-demo`,
    errorId = `${prefix}-error`;
  const inquiry = purpose === "inquiry";
  function invalid(field: string) {
    return (
      error?.field === field ||
      Boolean(send.fields[field === "message" ? "details.message" : field])
    );
  }
  return (
    <form
      className="inquiry"
      method="post"
      action="/api/inquiries"
      aria-busy={send.busy}
      aria-label={
        off
          ? inquiry
            ? "Демонстрационная форма обращения"
            : "Демонстрационная форма о путешествии"
          : inquiry
            ? "Форма обращения"
            : "Форма о путешествии"
      }
      onSubmit={async (event) => {
        event.preventDefault();
        if (send.busy || send.accepted) return;
        const form = event.currentTarget;
        const name = form.elements.namedItem("name") as HTMLInputElement;
        const email = form.elements.namedItem("email") as HTMLInputElement;
        const message = form.elements.namedItem(
          "message",
        ) as HTMLTextAreaElement;
        if (!name.value.trim()) {
          setError({
            field: "name",
            message: "Укажите имя, а не только пробелы.",
          });
          name.focus();
          return;
        }
        if (inquiry && !message.value.trim()) {
          setError({
            field: "message",
            message: "Напишите вопрос или пожелание, а не только пробелы.",
          });
          message.focus();
          return;
        }
        setError(null);
        if (off) {
          setReviewed(true);
          return;
        }
        await send.submit(
          inquiryFormPayload(inquiry ? "contacts" : "home", {
            name: name.value,
            email: email.value,
            message: message.value,
          }),
        );
      }}
      onChange={() => {
        setReviewed(false);
        setError(null);
        send.clearError();
      }}
    >
      <fieldset
        className="submission-fields"
        disabled={send.loading || send.busy || Boolean(send.accepted)}
      >
        <legend className="submission-sr-only">Параметры обращения</legend>
        {tourTitle && (
          <label>
            Выбранный пример маршрута
            <input name="tour" value={tourTitle} readOnly />
          </label>
        )}
        <div className="form-grid">
          <label>
            Как к вам обращаться
            <input
              name="name"
              autoComplete="name"
              placeholder="Ваше имя"
              required
              maxLength={100}
              aria-invalid={invalid("name")}
              aria-describedby={error?.field === "name" ? errorId : undefined}
            />
          </label>
          <label>
            Электронная почта
            <input
              name="email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              required
              maxLength={254}
              aria-invalid={invalid("email")}
            />
          </label>
        </div>
        <label htmlFor={messageId}>
          {inquiry ? "Ваш вопрос или пожелания" : "Ваше путешествие"}
        </label>
        <textarea
          id={messageId}
          name="message"
          defaultValue={
            tourTitle
              ? `Интересует пример маршрута «${tourTitle}». Хочу обсудить: `
              : undefined
          }
          rows={inquiry ? 4 : 3}
          placeholder={
            inquiry
              ? "О чём вы хотели бы узнать?"
              : "Когда хотите приехать? О чём мечтаете?"
          }
          maxLength={2000}
          required={inquiry}
          aria-invalid={invalid("message")}
          aria-describedby={error?.field === "message" ? errorId : demoId}
        />
        <p className="form-note" id={demoId}>
          {off ? (
            <>
              Демонстрационный режим.{" "}
              {inquiry
                ? "Имя, email и текст обращения обязательны."
                : "Имя и email обязательны."}{" "}
              Данные не отправляются и не записываются в хранилище. Не
              указывайте конфиденциальную информацию.
            </>
          ) : send.config.mode === "test" ? (
            "Локальная проверка: обращение записывается только в изолированную тестовую БД. Настоящие данные не вводите."
          ) : (
            "Обязательны имя и email. Текст пожеланий помогает обсудить ваше путешествие."
          )}
        </p>
        {error && (
          <p className="inquiry-error" id={errorId} role="alert">
            {error.message}
          </p>
        )}
        {Object.entries(send.fields).map(([field, text]) => (
          <p className="inquiry-error" key={field}>
            {text}
          </p>
        ))}
        <SubmissionTerms submission={send} />
        {off && (
          <Link
            className="form-privacy"
            href="/privacy"
            target="_blank"
            rel="noopener noreferrer"
          >
            Политика конфиденциальности (новая вкладка) →
          </Link>
        )}
        <noscript>
          <p className="form-note">
            Для проверки и отправки нужен JavaScript. Данные без него не
            отправляются.
          </p>
        </noscript>
        <Button
          type="submit"
          aria-describedby={demoId}
          disabled={send.loading || send.busy || Boolean(send.accepted)}
        >
          {send.busy
            ? "Отправляем…"
            : off
              ? inquiry
                ? "Проверить обращение"
                : "Проверить заявку"
              : inquiry
                ? "Отправить обращение"
                : "Отправить заявку"}
        </Button>
      </fieldset>
      <SubmissionResult submission={send} />
      <p role="status" className="form-status">
        {reviewed
          ? "Демонстрационная проверка завершена. Сообщение не отправлено. Введённые данные остались только на этой странице."
          : ""}
      </p>
    </form>
  );
}
