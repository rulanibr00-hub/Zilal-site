export const navigation = [
  { label: "Главная", href: "/" },
  { label: "Туры", href: "/tours" },
  { label: "Направления", href: "/destinations" },
  { label: "Создать путешествие", href: "/create-trip" },
  { label: "О Кыргызстане", href: "/kyrgyzstan" },
  { label: "О нас", href: "/about" },
  { label: "Контакты", href: "/contacts" },
] as const;
