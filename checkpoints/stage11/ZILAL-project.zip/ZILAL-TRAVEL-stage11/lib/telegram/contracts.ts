import { z } from "zod";
export const events = [
  "inquiry.created",
  "inquiry.status_changed",
  "delivery.failed",
] as const;
export type TelegramEvent = (typeof events)[number];
export const eventLabels = {
  "inquiry.created": "Новая заявка",
  "inquiry.status_changed": "Изменение статуса заявки",
  "delivery.failed": "Ошибка доставки уведомления",
  test: "Тестовое сообщение",
};
export const deliveryLabels = {
  pending: "В очереди",
  processing: "Отправляется",
  retry: "Повтор запланирован",
  delivered: "Доставлено",
  failed: "Ошибка",
  cancelled: "Отменено",
};
export const tokenSchema = z
  .string()
  .min(32)
  .max(150)
  .regex(/^\d{5,20}:[A-Za-z0-9_-]{25,100}$/);
export const chatSchema = z
  .string()
  .regex(/^-?[1-9]\d{0,15}$/)
  .refine(
    (s) =>
      Number.isSafeInteger(Number(s)) &&
      Math.abs(Number(s)) <= 4503599627370495,
  );
const name = z
  .string()
  .trim()
  .min(1)
  .max(100)
  .refine((s) => !/[\u0000-\u001f\u007f]/.test(s));
export const actionSchema = z.discriminatedUnion("action", [
  z
    .object({ action: z.literal("bot.create"), name, token: tokenSchema })
    .strict(),
  z
    .object({
      action: z.literal("bot.update"),
      id: z.uuid(),
      name,
      enabled: z.boolean(),
      token: tokenSchema.optional(),
    })
    .strict(),
  z
    .object({
      action: z.literal("bot.delete"),
      id: z.uuid(),
      confirmation: name,
    })
    .strict(),
  z.object({ action: z.literal("bot.check"), id: z.uuid() }).strict(),
  z
    .object({
      action: z.literal("recipient.save"),
      id: z.uuid().optional(),
      botId: z.uuid(),
      name,
      chatId: chatSchema,
      enabled: z.boolean(),
    })
    .strict(),
  z.object({ action: z.literal("recipient.delete"), id: z.uuid() }).strict(),
  z
    .object({
      action: z.literal("routes.save"),
      routes: z
        .array(
          z
            .object({
              event: z.enum(events),
              enabled: z.boolean(),
              recipientIds: z
                .array(z.uuid())
                .max(100)
                .refine((a) => new Set(a).size === a.length),
            })
            .strict(),
        )
        .length(3)
        .refine((a) => new Set(a.map((v) => v.event)).size === 3),
    })
    .strict(),
  z
    .object({
      action: z.literal("test.send"),
      recipientId: z.uuid(),
      requestId: z.uuid(),
    })
    .strict(),
]);
export type TelegramAction = z.infer<typeof actionSchema>;
export const errorLabels: Record<string, string> = {
  IN_FLIGHT_CANCELLED:
    "Настройки изменены во время отправки. Сообщение могло быть доставлено.",
  WEBHOOK_ACTIVE:
    "У бота действует webhook или другой получатель обновлений. Не отключайте его автоматически; согласуйте способ получения Chat ID.",
  NETWORK_DISABLED:
    "Сетевые вызовы Telegram отключены в серверной конфигурации.",
  KEY_UNAVAILABLE:
    "Ключ шифрования недоступен. Проверьте серверный файл ключей.",
  UNAUTHORIZED: "Telegram отклонил токен. Замените его через BotFather.",
  FORBIDDEN: "Бот заблокирован или у него нет доступа к чату.",
  BAD_REQUEST:
    "Telegram отклонил запрос. Проверьте Chat ID, запуск бота и права в группе.",
  RATE_LIMIT: "Telegram ограничил частоту. Повтор будет запланирован.",
  TIMEOUT:
    "Telegram не ответил вовремя. Результат отправки может быть неизвестен.",
  NETWORK: "Не удалось связаться с Telegram.",
  REMOTE_ERROR: "Временная ошибка Telegram.",
  INVALID_RESPONSE: "Неожиданный ответ Telegram.",
  CONFIG_CHANGED: "Подключение или получатель изменены; задание отменено.",
  LEASE_EXPIRED: "Лимит попыток исчерпан после остановки обработчика.",
  RETRY_AFTER_TOO_LONG:
    "Telegram запросил слишком долгую паузу. Требуется проверка администратора.",
};
export class TelegramError extends Error {
  constructor(
    public code: string,
    public retryable = false,
    public retryAfter = 0,
  ) {
    super(errorLabels[code] ?? "Операция Telegram не выполнена.");
  }
}
export interface TelegramState {
  bots: {
    id: string;
    name: string;
    enabled: boolean;
    checkStatus: string;
    username: string | null;
    lastError: string | null;
    checkedAt: string | null;
  }[];
  recipients: {
    id: string;
    botId: string;
    name: string;
    chatId: string;
    enabled: boolean;
  }[];
  events: { event: TelegramEvent; enabled: boolean }[];
  routes: { event: string; recipientId: string }[];
  log: {
    id: string;
    event: string;
    botName: string;
    recipientName: string;
    status: string;
    attempts: number;
    errorCode: string | null;
    createdAt: string;
    updatedAt: string;
    runAt: string;
  }[];
  total: number;
  page: number;
  pageSize: number;
  keyReady: boolean;
  networkEnabled: boolean;
  lastWorkerRun: string | null;
}
