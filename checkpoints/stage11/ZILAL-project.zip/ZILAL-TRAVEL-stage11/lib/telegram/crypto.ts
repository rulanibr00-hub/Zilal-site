import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { readFileSync, realpathSync, statSync } from "node:fs";
import { isAbsolute, relative, sep, dirname, basename, join } from "node:path";
import { TelegramError } from "./contracts";
export interface KeyRing {
  activeKeyId: string;
  keys: Record<string, string>;
}
export function externalKeyPath(file: string) {
  if (!isAbsolute(file)) throw new TelegramError("KEY_UNAVAILABLE");
  const rel = relative(realpathSync(process.cwd()), file);
  if (!(rel === ".." || rel.startsWith(".." + sep)))
    throw new TelegramError("KEY_UNAVAILABLE");
  const canonical = join(realpathSync(dirname(file)), basename(file));
  const actual = relative(realpathSync(process.cwd()), canonical);
  if (!(actual === ".." || actual.startsWith(".." + sep)))
    throw new TelegramError("KEY_UNAVAILABLE");
  return file;
}
// Runtime-mounted secret: explicitly exclude dynamic key-file access from build tracing.
export function keyRing(): KeyRing {
  try {
    const file = externalKeyPath(process.env.TELEGRAM_KEY_FILE ?? "");
    externalKeyPath(realpathSync(/* turbopackIgnore: true */ file));
    const stat = statSync(/* turbopackIgnore: true */ file);
    if (
      !stat.isFile() ||
      (process.platform !== "win32" && (stat.mode & 0o077) !== 0)
    )
      throw new Error();
    const ring = JSON.parse(readFileSync(/* turbopackIgnore: true */ file, "utf8"));
    if (
      !/^[a-zA-Z0-9_-]{1,64}$/.test(ring.activeKeyId) ||
      !ring.keys ||
      !ring.keys[ring.activeKeyId]
    )
      throw new Error();
    for (const [id, key] of Object.entries(ring.keys)) {
      if (
        !/^[a-zA-Z0-9_-]{1,64}$/.test(id) ||
        typeof key !== "string" ||
        !/^[A-Za-z0-9+/]{43}=$/.test(key) ||
        Buffer.from(key, "base64").length !== 32
      )
        throw new Error();
    }
    return ring;
  } catch {
    throw new TelegramError("KEY_UNAVAILABLE");
  }
}
export function encryptToken(token: string, botId: string, ring = keyRing()) {
  const iv = randomBytes(12);
  const cipher = createCipheriv(
    "aes-256-gcm",
    Buffer.from(ring.keys[ring.activeKeyId], "base64"),
    iv,
  );
  cipher.setAAD(Buffer.from(`zilal:telegram:${botId}`));
  const ciphertext = Buffer.concat([
    cipher.update(token, "utf8"),
    cipher.final(),
  ]);
  return {
    keyId: ring.activeKeyId,
    iv: iv.toString("base64"),
    tag: cipher.getAuthTag().toString("base64"),
    ciphertext: ciphertext.toString("base64"),
  };
}
export function decryptToken(
  value: { keyId: string; iv: string; tag: string; ciphertext: string },
  botId: string,
  ring = keyRing(),
) {
  try {
    if (!ring.keys[value.keyId]) throw new Error();
    const decipher = createDecipheriv(
      "aes-256-gcm",
      Buffer.from(ring.keys[value.keyId], "base64"),
      Buffer.from(value.iv, "base64"),
    );
    decipher.setAAD(Buffer.from(`zilal:telegram:${botId}`));
    decipher.setAuthTag(Buffer.from(value.tag, "base64"));
    return Buffer.concat([
      decipher.update(Buffer.from(value.ciphertext, "base64")),
      decipher.final(),
    ]).toString("utf8");
  } catch {
    throw new TelegramError("KEY_UNAVAILABLE");
  }
}
