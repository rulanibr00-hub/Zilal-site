import { and, eq, sql } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import {
  telegramBots as bots,
  telegramRecipients as recipients,
  telegramJobs as jobs,
  telegramWorker,
} from "../db/schema";
import {
  telegramLock,
  enqueueEvent,
  type Database,
  type Executor,
} from "./store";
import { TelegramClient } from "./client";
import { decryptToken, keyRing } from "./crypto";
import { TelegramError } from "./contracts";
async function failureAlert(tx: Executor, job: typeof jobs.$inferSelect) {
  if (job.event === "delivery.failed") return;
  await enqueueEvent(
    tx,
    "delivery.failed",
    job.id,
    `ZILAL TRAVEL\nОшибка доставки уведомления.\n${job.message}\nКод: ${job.errorCode ?? "REMOTE_ERROR"}\nКонтакты туристов не передаются.`,
    job.recipientId ?? undefined,
  );
}
export async function processTelegramBatch(
  db: Database,
  client = new TelegramClient(),
  limit = 20,
) {
  client.ready();
  keyRing();
  await db
    .insert(telegramWorker)
    .values({ id: 1, lastRunAt: new Date() })
    .onConflictDoUpdate({
      target: telegramWorker.id,
      set: { lastRunAt: new Date() },
    });
  let processed = 0;
  for (let i = 0; i < Math.min(limit, 20); i++) {
    const claimed = await db.transaction(async (tx) => {
      await telegramLock(tx);
      const now = new Date();
      const [job] = await tx
        .select()
        .from(jobs)
        .where(
          sql`((${jobs.status} in ('pending','retry') AND ${jobs.runAt}<=${now}) OR (${jobs.status}='processing' AND ${jobs.leaseUntil}<${now}))`,
        )
        .orderBy(jobs.runAt, jobs.createdAt)
        .limit(1)
        .for("update", { skipLocked: true });
      if (!job) return null;
      if (job.attempts >= 3) {
        await tx
          .update(jobs)
          .set({
            status: "failed",
            errorCode: "LEASE_EXPIRED",
            leaseId: null,
            leaseUntil: null,
            updatedAt: now,
          })
          .where(eq(jobs.id, job.id));
        await failureAlert(tx, { ...job, errorCode: "LEASE_EXPIRED" });
        return { skipped: true } as const;
      }
      const [bot] = job.botId
        ? await tx.select().from(bots).where(eq(bots.id, job.botId))
        : [];
      const [recipient] = job.recipientId
        ? await tx
            .select()
            .from(recipients)
            .where(eq(recipients.id, job.recipientId))
        : [];
      if (
        !bot ||
        !recipient ||
        !bot.enabled ||
        !recipient.enabled ||
        bot.checkStatus !== "verified" ||
        bot.revision !== job.botRevision ||
        recipient.revision !== job.recipientRevision ||
        recipient.botId !== bot.id
      ) {
        await tx
          .update(jobs)
          .set({
            status: "cancelled",
            errorCode: "CONFIG_CHANGED",
            leaseId: null,
            leaseUntil: null,
            updatedAt: now,
          })
          .where(eq(jobs.id, job.id));
        return { skipped: true } as const;
      }
      const ready = Math.max(
        bot.nextSendAt.getTime(),
        recipient.nextSendAt.getTime(),
      );
      if (ready > now.getTime()) {
        await tx
          .update(jobs)
          .set({
            status: "retry",
            runAt: new Date(ready),
            leaseId: null,
            leaseUntil: null,
            updatedAt: now,
          })
          .where(eq(jobs.id, job.id));
        return { skipped: true } as const;
      }
      const lease = randomUUID();
      await tx
        .update(jobs)
        .set({
          status: "processing",
          attempts: job.attempts + 1,
          leaseId: lease,
          leaseUntil: new Date(Date.now() + 60000),
          updatedAt: now,
        })
        .where(eq(jobs.id, job.id));
      await tx
        .update(bots)
        .set({ nextSendAt: new Date(Date.now() + 100) })
        .where(eq(bots.id, bot.id));
      await tx
        .update(recipients)
        .set({ nextSendAt: new Date(Date.now() + 3100) })
        .where(eq(recipients.id, recipient.id));
      return { skipped: false, job, bot, recipient, lease } as const;
    });
    if (!claimed) break;
    if (claimed.skipped) continue;
    // Check cancellation immediately before calling the external API, without holding a DB transaction across HTTP.
    const [current] = await db
      .select({ status: jobs.status, leaseId: jobs.leaseId })
      .from(jobs)
      .where(eq(jobs.id, claimed.job.id));
    if (current?.status !== "processing" || current.leaseId !== claimed.lease)
      continue;
    let messageId: number | undefined;
    let error: TelegramError | undefined;
    try {
      messageId = await client.send(
        decryptToken(claimed.bot.encryptedToken, claimed.bot.id),
        claimed.recipient.chatId,
        claimed.job.message,
      );
    } catch (e) {
      error =
        e instanceof TelegramError ? e : new TelegramError("NETWORK", true);
    }
    await db.transaction(async (tx) => {
      await telegramLock(tx);
      const [owned] = await tx
        .select()
        .from(jobs)
        .where(
          and(
            eq(jobs.id, claimed.job.id),
            eq(jobs.status, "processing"),
            eq(jobs.leaseId, claimed.lease),
          ),
        );
      if (!owned) return;
      const retry = Boolean(error?.retryable && owned.attempts < 3);
      const runAt = new Date(
        Date.now() +
          Math.max(error?.retryAfter ?? 0, 15 * 2 ** (owned.attempts - 1)) *
            1000,
      );
      await tx
        .update(jobs)
        .set({
          status: error ? (retry ? "retry" : "failed") : "delivered",
          errorCode: error?.code ?? null,
          runAt: retry ? runAt : owned.runAt,
          leaseId: null,
          leaseUntil: null,
          telegramMessageId: messageId === undefined ? null : String(messageId),
          updatedAt: new Date(),
        })
        .where(eq(jobs.id, owned.id));
      if (error?.code === "RATE_LIMIT")
        await tx
          .update(bots)
          .set({ nextSendAt: runAt })
          .where(eq(bots.id, claimed.bot.id));
      if (error?.code === "UNAUTHORIZED")
        await tx
          .update(bots)
          .set({ checkStatus: "error", lastError: "UNAUTHORIZED" })
          .where(
            and(
              eq(bots.id, claimed.bot.id),
              eq(bots.revision, claimed.bot.revision),
            ),
          );
      if (error && !retry)
        await failureAlert(tx, { ...owned, errorCode: error.code });
    });
    processed++;
  }
  return { processed };
}
