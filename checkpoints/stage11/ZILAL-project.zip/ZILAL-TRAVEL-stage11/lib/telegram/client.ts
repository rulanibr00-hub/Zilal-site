import { TelegramError, tokenSchema } from "./contracts";
export type TelegramTransport = (
  url: string,
  options: RequestInit,
) => Promise<Response>;
export class TelegramClient {
  constructor(
    private transport: TelegramTransport = fetch,
    private enabled = () => process.env.TELEGRAM_NETWORK_ENABLED === "true",
  ) {}
  ready() {
    if (!this.enabled()) throw new TelegramError("NETWORK_DISABLED");
  }
  async call(
    token: string,
    method: "getMe" | "sendMessage" | "getUpdates",
    data: Record<string, unknown>,
  ) {
    this.ready();
    if (!tokenSchema.safeParse(token).success)
      throw new TelegramError("UNAUTHORIZED");
    let response: Response;
    let value: any;
    try {
      response = await this.transport(
        `https://api.telegram.org/bot${token}/${method}`,
        {
          method: "POST",
          redirect: "error",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
          signal: AbortSignal.timeout(8000),
          cache: "no-store",
        },
      );
      value = await response.json();
    } catch (e) {
      throw new TelegramError(
        e instanceof Error &&
          (e.name === "TimeoutError" || e.name === "AbortError")
          ? "TIMEOUT"
          : "NETWORK",
        true,
      );
    }
    if (response.ok && value?.ok === true) return value.result;
    const code = Number(value?.error_code) || response.status;
    if (code === 429) {
      const pause = Number(value?.parameters?.retry_after);
      if (!Number.isFinite(pause) || pause < 1 || pause > 86400)
        throw new TelegramError("RETRY_AFTER_TOO_LONG");
      throw new TelegramError("RATE_LIMIT", true, Math.ceil(pause));
    }
    if (code === 401) throw new TelegramError("UNAUTHORIZED");
    if (code === 403) throw new TelegramError("FORBIDDEN");
    if (code === 409) throw new TelegramError("WEBHOOK_ACTIVE");
    if (code === 400) throw new TelegramError("BAD_REQUEST");
    if (code >= 500) throw new TelegramError("REMOTE_ERROR", true);
    throw new TelegramError("INVALID_RESPONSE");
  }
  async check(token: string) {
    const r = await this.call(token, "getMe", {});
    if (
      !r?.is_bot ||
      !/^\d+$/.test(String(r.id)) ||
      typeof r.username !== "string" ||
      !/^[a-zA-Z0-9_]{1,64}$/.test(r.username)
    )
      throw new TelegramError("INVALID_RESPONSE");
    return { telegramId: String(r.id), username: r.username };
  }
  async send(token: string, chatId: string, text: string) {
    const r = await this.call(token, "sendMessage", {
      chat_id: chatId,
      text,
      link_preview_options: { is_disabled: true },
    });
    if (!Number.isSafeInteger(r?.message_id))
      throw new TelegramError("INVALID_RESPONSE", true);
    return r.message_id;
  }
}
