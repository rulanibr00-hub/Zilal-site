import { and, count, desc, eq, inArray, sql } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import type { createDatabase } from "../db/connection";
import {
  telegramBots as bots,
  telegramRecipients as recipients,
  telegramEvents as events,
  telegramRoutes as routes,
  telegramJobs as jobs,
  telegramWorker,
  adminAuditLogs,
  rateLimits,
} from "../db/schema";
import { actionSchema, TelegramError, type TelegramEvent } from "./contracts";
import { encryptToken, decryptToken, keyRing } from "./crypto";
import { TelegramClient } from "./client";
import {
  inquiryNumber,
  statusLabels,
  sourceLabels,
  adminDate,
} from "../admin/contracts";
import { getTourBySlug } from "../data/tours";
export type Database = ReturnType<typeof createDatabase>["db"];
export type Executor = Pick<
  Database,
  "select" | "insert" | "update" | "delete" | "execute"
>;
export class TelegramAdminError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
export async function telegramLock(tx: Executor) {
  await tx.execute(sql`SELECT pg_advisory_xact_lock(92284491)`);
}
const pending = ["pending", "processing", "retry"];
export async function cancelJobs(tx: Executor, where: ReturnType<typeof eq>) {
  await tx
    .update(jobs)
    .set({
      status: "cancelled",
      errorCode: sql`case when ${jobs.status}='processing' then 'IN_FLIGHT_CANCELLED' else 'CONFIG_CHANGED' end`,
      leaseId: null,
      leaseUntil: null,
      updatedAt: new Date(),
    })
    .where(and(where, inArray(jobs.status, pending)));
}
export async function enqueueEvent(
  tx: Executor,
  event: TelegramEvent,
  dedupe: string,
  message: string,
  excludeRecipient?: string,
) {
  await telegramLock(tx);
  const [config] = await tx
    .select()
    .from(events)
    .where(eq(events.event, event));
  if (!config?.enabled) return;
  const targets = await tx
    .select({ bot: bots, recipient: recipients })
    .from(routes)
    .innerJoin(recipients, eq(recipients.id, routes.recipientId))
    .innerJoin(bots, eq(bots.id, recipients.botId))
    .where(
      and(
        eq(routes.event, event),
        eq(recipients.enabled, true),
        eq(bots.enabled, true),
        eq(bots.checkStatus, "verified"),
      ),
    );
  for (const { bot, recipient } of targets) {
    if (recipient.id === excludeRecipient) continue;
    await tx
      .insert(jobs)
      .values({
        dedupeKey: `${event}:${dedupe}:${recipient.id}`,
        event,
        botId: bot.id,
        recipientId: recipient.id,
        botName: bot.name,
        recipientName: recipient.name,
        botRevision: bot.revision,
        recipientRevision: recipient.revision,
        message,
      })
      .onConflictDoNothing({ target: jobs.dedupeKey });
  }
}
export function inquiryMessage(
  row: {
    number: number;
    source: "home" | "contacts" | "builder";
    tourSlug: string | null;
    createdAt: Date;
    status: keyof typeof statusLabels;
    isTest: boolean;
  },
  event: "inquiry.created" | "inquiry.status_changed",
) {
  const tour = row.tourSlug ? getTourBySlug(row.tourSlug) : undefined;
  return [
    `ZILAL TRAVEL${row.isTest ? " · тестовая заявка" : ""}`,
    event === "inquiry.created" ? "Новая заявка" : "Изменение статуса заявки",
    `Номер: ${inquiryNumber(row.number)}`,
    `Тип: ${sourceLabels[row.source]}`,
    `Тур: ${tour?.title.ru ?? row.tourSlug ?? "Индивидуальное путешествие"}`,
    `Создана: ${adminDate(row.createdAt)}`,
    `Статус: ${statusLabels[row.status]}`,
  ].join("\n");
}
export class TelegramStore {
  constructor(
    public db: Database,
    public client = new TelegramClient(),
  ) {}
  async state(page = 1) {
    const botRows = await this.db
      .select({
        id: bots.id,
        name: bots.name,
        enabled: bots.enabled,
        checkStatus: bots.checkStatus,
        username: bots.username,
        lastError: bots.lastError,
        checkedAt: bots.checkedAt,
      })
      .from(bots)
      .orderBy(bots.createdAt);
    const recipientRows = await this.db
      .select()
      .from(recipients)
      .orderBy(recipients.name);
    const eventRows = await this.db.select().from(events);
    const routeRows = await this.db.select().from(routes);
    const [total] = await this.db.select({ value: count() }).from(jobs);
    const log = await this.db
      .select({
        id: jobs.id,
        event: jobs.event,
        botName: jobs.botName,
        recipientName: jobs.recipientName,
        status: jobs.status,
        attempts: jobs.attempts,
        errorCode: jobs.errorCode,
        createdAt: jobs.createdAt,
        updatedAt: jobs.updatedAt,
        runAt: jobs.runAt,
      })
      .from(jobs)
      .orderBy(desc(jobs.createdAt), desc(jobs.id))
      .limit(30)
      .offset((page - 1) * 30);
    const [worker] = await this.db.select().from(telegramWorker);
    let keyReady = true;
    try {
      keyRing();
    } catch {
      keyReady = false;
    }
    return {
      bots: botRows,
      recipients: recipientRows.map(
        ({ revision, nextSendAt, ...safe }) => safe,
      ),
      events: eventRows,
      routes: routeRows.map(({ event, recipientId }) => ({
        event,
        recipientId,
      })),
      log,
      total: total.value,
      page,
      pageSize: 30,
      keyReady,
      networkEnabled: process.env.TELEGRAM_NETWORK_ENABLED === "true",
      lastWorkerRun: worker?.lastRunAt ?? null,
    };
  }
  async action(input: unknown, adminId: string) {
    const result = actionSchema.safeParse(input);
    if (!result.success)
      throw new TelegramAdminError(
        400,
        "Проверьте поля: название, формат токена, Chat ID и выбранных получателей.",
      );
    const data = result.data;
    if (data.action === "bot.check") return this.check(data.id, adminId);
    return this.db.transaction(async (tx) => {
      await telegramLock(tx);
      let entityId: string | undefined;
      if (data.action === "bot.create") {
        const [total] = await tx.select({ n: count() }).from(bots);
        if (total.n >= 10)
          throw new TelegramAdminError(
            400,
            "Допускается не более 10 подключений.",
          );
        const id = randomUUID();
        await tx.insert(bots).values({
          id,
          name: data.name,
          encryptedToken: encryptToken(data.token, id),
        });
        entityId = id;
      } else if (data.action === "bot.update") {
        const [bot] = await tx.select().from(bots).where(eq(bots.id, data.id));
        if (!bot) throw new TelegramAdminError(404, "Подключение не найдено.");
        if (data.enabled && !data.token && bot.checkStatus !== "verified")
          throw new TelegramAdminError(400, "Сначала проверьте подключение.");
        const replacing = Boolean(data.token);
        await tx
          .update(bots)
          .set({
            name: data.name,
            enabled: replacing ? false : data.enabled,
            updatedAt: new Date(),
            ...(replacing
              ? {
                  encryptedToken: encryptToken(data.token!, bot.id),
                  checkStatus: "unchecked",
                  username: null,
                  telegramId: null,
                  lastError: null,
                  checkedAt: null,
                  revision: bot.revision + 1,
                }
              : {}),
          })
          .where(eq(bots.id, bot.id));
        if (replacing || !data.enabled)
          await cancelJobs(tx, eq(jobs.botId, bot.id));
        entityId = bot.id;
      } else if (data.action === "bot.delete") {
        const [bot] = await tx.select().from(bots).where(eq(bots.id, data.id));
        if (!bot) throw new TelegramAdminError(404, "Подключение не найдено.");
        if (data.confirmation !== bot.name)
          throw new TelegramAdminError(
            400,
            "Для удаления введите текущее название подключения.",
          );
        await cancelJobs(tx, eq(jobs.botId, bot.id));
        await tx.delete(bots).where(eq(bots.id, bot.id));
        entityId = bot.id;
      } else if (data.action === "recipient.save") {
        const [bot] = await tx
          .select()
          .from(bots)
          .where(eq(bots.id, data.botId));
        if (!bot)
          throw new TelegramAdminError(400, "Выберите существующего бота.");
        const [duplicate] = await tx
          .select()
          .from(recipients)
          .where(
            and(
              eq(recipients.botId, data.botId),
              eq(recipients.chatId, data.chatId),
            ),
          );
        if (duplicate && duplicate.id !== data.id)
          throw new TelegramAdminError(
            409,
            "Этот Chat ID уже добавлен для выбранного бота.",
          );
        if (data.id) {
          const [old] = await tx
            .select()
            .from(recipients)
            .where(eq(recipients.id, data.id));
          if (!old) throw new TelegramAdminError(404, "Получатель не найден.");
          const changed =
            old.botId !== data.botId || old.chatId !== data.chatId;
          await tx
            .update(recipients)
            .set({
              botId: data.botId,
              name: data.name,
              chatId: data.chatId,
              enabled: data.enabled,
              revision: old.revision + 1,
            })
            .where(eq(recipients.id, data.id));
          await cancelJobs(tx, eq(jobs.recipientId, data.id));
          if (changed)
            await tx.delete(routes).where(eq(routes.recipientId, data.id));
          entityId = data.id;
        } else {
          const [total] = await tx.select({ n: count() }).from(recipients);
          if (total.n >= 100)
            throw new TelegramAdminError(
              400,
              "Допускается не более 100 получателей.",
            );
          const [created] = await tx
            .insert(recipients)
            .values({
              botId: data.botId,
              name: data.name,
              chatId: data.chatId,
              enabled: data.enabled,
            })
            .returning({ id: recipients.id });
          entityId = created.id;
        }
      } else if (data.action === "recipient.delete") {
        await cancelJobs(tx, eq(jobs.recipientId, data.id));
        await tx.delete(recipients).where(eq(recipients.id, data.id));
        entityId = data.id;
      } else if (data.action === "routes.save") {
        const ids = [...new Set(data.routes.flatMap((r) => r.recipientIds))];
        const found = ids.length
          ? await tx
              .select({
                id: recipients.id,
                enabled: recipients.enabled,
                botEnabled: bots.enabled,
                verified: bots.checkStatus,
              })
              .from(recipients)
              .innerJoin(bots, eq(bots.id, recipients.botId))
              .where(inArray(recipients.id, ids))
          : [];
        if (found.length !== ids.length)
          throw new TelegramAdminError(
            400,
            "Один из получателей больше не существует.",
          );
        for (const config of data.routes) {
          if (config.enabled && config.recipientIds.length === 0)
            throw new TelegramAdminError(
              400,
              "Для включённого события выберите получателей.",
            );
          if (
            config.enabled &&
            config.recipientIds.some(
              (id) =>
                !found.some(
                  (r) =>
                    r.id === id &&
                    r.enabled &&
                    r.botEnabled &&
                    r.verified === "verified",
                ),
            )
          )
            throw new TelegramAdminError(
              400,
              "Для включённого события нужны активные получатели и проверенные включённые боты.",
            );
          await tx
            .update(events)
            .set({ enabled: config.enabled })
            .where(eq(events.event, config.event));
          await tx.delete(routes).where(eq(routes.event, config.event));
          for (const id of config.recipientIds)
            await tx
              .insert(routes)
              .values({ event: config.event, recipientId: id });
        }
        // Old queued event notifications must not escape a newly restricted routing policy.
        await tx
          .update(jobs)
          .set({
            status: "cancelled",
            errorCode: sql`case when ${jobs.status}='processing' then 'IN_FLIGHT_CANCELLED' else 'CONFIG_CHANGED' end`,
            leaseId: null,
            leaseUntil: null,
            updatedAt: new Date(),
          })
          .where(
            and(
              inArray(jobs.status, pending),
              inArray(jobs.event, [
                "inquiry.created",
                "inquiry.status_changed",
                "delivery.failed",
              ]),
            ),
          );
      } else if (data.action === "test.send") {
        const [target] = await tx
          .select({ bot: bots, recipient: recipients })
          .from(recipients)
          .innerJoin(bots, eq(bots.id, recipients.botId))
          .where(eq(recipients.id, data.recipientId));
        if (
          !target ||
          !target.bot.enabled ||
          target.bot.checkStatus !== "verified" ||
          !target.recipient.enabled
        )
          throw new TelegramAdminError(
            400,
            "Включите проверенного бота и получателя.",
          );
        this.client.ready();
        keyRing();
        const [existing] = await tx
          .select({ recipientId: jobs.recipientId })
          .from(jobs)
          .where(eq(jobs.dedupeKey, `test:${data.requestId}`));
        if (existing) {
          if (existing.recipientId !== data.recipientId)
            throw new TelegramAdminError(
              409,
              "Ключ теста уже использован для другого получателя.",
            );
          return {
            saved: true,
            message:
              "Тестовое задание уже существует. Проверьте результат в журнале.",
          };
        }
        const bucket = Math.floor(Date.now() / 60000);
        const [limit] = await tx
          .insert(rateLimits)
          .values({
            key: `telegram-test:${data.recipientId}:${bucket}`,
            count: 1,
            expiresAt: new Date((bucket + 1) * 60000),
          })
          .onConflictDoUpdate({
            target: rateLimits.key,
            set: { count: sql`${rateLimits.count}+1` },
          })
          .returning({ count: rateLimits.count });
        if (limit.count > 10)
          throw new TelegramAdminError(
            429,
            "Не более 10 тестов одному получателю в минуту.",
          );
        await tx
          .insert(jobs)
          .values({
            dedupeKey: `test:${data.requestId}`,
            event: "test",
            botId: target.bot.id,
            recipientId: target.recipient.id,
            botName: target.bot.name,
            recipientName: target.recipient.name,
            botRevision: target.bot.revision,
            recipientRevision: target.recipient.revision,
            message:
              "Тестовое уведомление ZILAL TRAVEL. Контакты туристов не передаются.",
          })
          .onConflictDoNothing({ target: jobs.dedupeKey });
        entityId = target.recipient.id;
      }
      if (
        ["bot.delete", "recipient.delete", "recipient.save"].includes(
          data.action,
        )
      )
        await tx.execute(
          sql`UPDATE telegram_events SET enabled=false WHERE NOT EXISTS (SELECT 1 FROM telegram_routes WHERE telegram_routes.event=telegram_events.event)`,
        );
      await tx
        .insert(adminAuditLogs)
        .values({ adminId, action: `telegram.${data.action}`, entityId });
      return {
        saved: true,
        message:
          data.action === "test.send"
            ? "Тест поставлен в очередь. Результат доставки появится в журнале после запуска обработчика."
            : "Изменения сохранены.",
      };
    });
  }
  async check(id: string, adminId: string) {
    this.client.ready();
    const bot = await this.db.transaction(async (tx) => {
      await telegramLock(tx);
      const [row] = await tx.select().from(bots).where(eq(bots.id, id));
      if (!row) throw new TelegramAdminError(404, "Подключение не найдено.");
      if (row.checkedAt && Date.now() - row.checkedAt.getTime() < 5000)
        throw new TelegramAdminError(
          429,
          "Повторите проверку через несколько секунд.",
        );
      await tx
        .update(bots)
        .set({ checkedAt: new Date() })
        .where(eq(bots.id, id));
      return row;
    });
    let value: { telegramId: string; username: string } | undefined;
    let failure: TelegramError | undefined;
    try {
      value = await this.client.check(decryptToken(bot.encryptedToken, bot.id));
    } catch (e) {
      failure =
        e instanceof TelegramError ? e : new TelegramError("NETWORK", true);
    }
    await this.db.transaction(async (tx) => {
      await telegramLock(tx);
      const [current] = await tx.select().from(bots).where(eq(bots.id, id));
      if (!current || current.revision !== bot.revision)
        throw new TelegramAdminError(
          409,
          "Подключение изменилось во время проверки. Повторите её.",
        );
      if (value) {
        const duplicates = await tx
          .select({ id: bots.id })
          .from(bots)
          .where(eq(bots.telegramId, value.telegramId));
        if (duplicates.some((v) => v.id !== id))
          throw new TelegramAdminError(409, "Этот Telegram-бот уже подключён.");
      }
      await tx
        .update(bots)
        .set({
          checkStatus: failure ? "error" : "verified",
          lastError: failure?.code ?? null,
          checkedAt: new Date(),
          ...(value ?? {}),
        })
        .where(eq(bots.id, id));
      await tx.insert(adminAuditLogs).values({
        adminId,
        action: "telegram.bot.checked",
        entityId: id,
        metadata: { result: failure?.code ?? "verified" },
      });
    });
    if (failure) throw failure;
    return {
      saved: true,
      message:
        "Telegram подтвердил подключение. Токен не возвращается в интерфейс.",
    };
  }
}
