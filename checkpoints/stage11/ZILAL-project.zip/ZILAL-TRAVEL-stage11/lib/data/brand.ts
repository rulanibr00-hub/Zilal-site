// Identity supplied by the owner in the task. No inferred history or credentials.
export const companyIdentity = {
  name: "ZILAL TRAVEL",
  description:
    "Семейная туристическая компания, ориентированная на приём иностранных гостей в Кыргызстане.",
};
export const ownerContent = [
  {
    id: "story",
    title: "История семьи и компании",
    request:
      "Место для рассказа владельца: как появилась идея ZILAL TRAVEL, что связывает семью с путешествиями и какие факты можно опубликовать. Даты и стаж пока не указаны.",
  },
  {
    id: "people",
    title: "Люди за путешествиями",
    request:
      "Место для подтверждённых имён, ролей и коротких представлений членов команды. Портреты добавляются только с разрешением на публикацию.",
  },
  {
    id: "details",
    title: "Сведения о компании",
    request:
      "Место для полного официального наименования, регистрационных данных и публичных реквизитов. Сведения о разрешениях — только при наличии, применимости и подтверждении.",
  },
  {
    id: "images",
    title: "Семейный визуальный дневник",
    request:
      "Место для авторских фотографий семьи, Кыргызстана и путешествий. Нужны подписи, авторство и подтверждённые права на использование.",
  },
] as const;
export interface CompanyContact {
  id: "phone" | "whatsapp" | "email" | "address";
  title: string;
  value: string | null;
  placeholder: string;
  description: string;
}
export const companyContacts: readonly CompanyContact[] = [
  {
    id: "phone",
    title: "Телефон",
    value: null,
    placeholder: "Номер добавит владелец",
    description:
      "Нужен подтверждённый номер с кодом страны и удобное время для звонков.",
  },
  {
    id: "whatsapp",
    title: "WhatsApp",
    value: null,
    placeholder: "WhatsApp пока не подключён",
    description:
      "Владелец подтвердит номер для сообщений. Ссылка появится после проверки контакта.",
  },
  {
    id: "email",
    title: "Email",
    value: null,
    placeholder: "Адрес добавит владелец",
    description:
      "Здесь будет подтверждённая электронная почта для вопросов о путешествиях.",
  },
  {
    id: "address",
    title: "Адрес",
    value: null,
    placeholder: "Адрес предстоит уточнить",
    description:
      "Нужен публичный адрес для обращений. Если есть место для личных встреч, владелец отдельно укажет условия и часы приёма.",
  },
];
