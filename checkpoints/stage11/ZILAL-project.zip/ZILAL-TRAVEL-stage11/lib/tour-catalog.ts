import type { Activity, Difficulty, Tour, TravelStyle } from "./types";
export const travelStyles: Record<
  TravelStyle,
  { title: string; description: string }
> = {
  comfort: {
    title: "Signature Comfort",
    description: "Выразительные места, спокойный ритм и время для себя.",
  },
  adventure: {
    title: "Wild Adventures",
    description: "Больше горных троп, простора и личных открытий.",
  },
  combined: {
    title: "Comfort + Adventure",
    description: "Панорамная дорога и активные дни в одном путешествии.",
  },
};
export const activityLabels: Record<Activity, string> = {
  panoramas: "Панорамные поездки",
  culture: "Культура",
  walks: "Прогулки",
  trekking: "Треккинг",
};
export const difficultyLabels: Record<Difficulty, string> = {
  easy: "Невысокая нагрузка",
  moderate: "Умеренная нагрузка",
  challenging: "Высокая нагрузка",
};
export const durationOptions = [
  { value: "all", label: "Любая продолжительность" },
  { value: "short", label: "До 5 дней" },
  { value: "week", label: "6–8 дней" },
  { value: "long", label: "От 9 дней" },
] as const;
export type DurationFilter = (typeof durationOptions)[number]["value"];
export interface TourFilters {
  style: TravelStyle | "all";
  duration: DurationFilter;
  activity: Activity | "all";
}
export const defaultFilters: TourFilters = {
  style: "all",
  duration: "all",
  activity: "all",
};
export function filterTours(
  tours: readonly Tour[],
  filters: TourFilters,
): Tour[] {
  return tours.filter((tour) => {
    if (tour.status === "draft") return false;
    if (filters.style !== "all" && tour.style !== filters.style) return false;
    if (
      filters.activity !== "all" &&
      !tour.activities.includes(filters.activity)
    )
      return false;
    if (filters.duration === "all") return true;
    if (tour.durationDays === null) return false;
    if (filters.duration === "short") return tour.durationDays <= 5;
    if (filters.duration === "week")
      return tour.durationDays >= 6 && tour.durationDays <= 8;
    return tour.durationDays >= 9;
  });
}
export function daysLabel(days: number | null): string {
  if (days === null) return "Сроки уточняются";
  const form = new Intl.PluralRules("ru").select(days);
  return `${days} ${form === "one" ? "день" : form === "few" ? "дня" : "дней"}`;
}
