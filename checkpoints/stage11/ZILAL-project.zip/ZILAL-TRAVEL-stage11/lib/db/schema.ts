import { sql } from "drizzle-orm";
import {
  pgTable,
  customType,
  primaryKey,
  uuid,
  text,
  integer,
  timestamp,
  jsonb,
  boolean,
  uniqueIndex,
  check,
  index,
} from "drizzle-orm/pg-core";
const time = (name: string) =>
  timestamp(name, { withTimezone: true, precision: 3, mode: "date" });
export const adminUsers = pgTable(
  "admin_users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    singleton: integer("singleton").notNull().default(1),
    login: text("login").notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    createdAt: time("created_at").notNull().defaultNow(),
    lastLoginAt: time("last_login_at"),
  },
  (t) => [
    uniqueIndex("one_admin").on(t.singleton),
    check("admin_singleton", sql`${t.singleton} = 1`),
  ],
);
export const adminSessions = pgTable(
  "admin_sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    adminId: uuid("admin_id")
      .notNull()
      .references(() => adminUsers.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull().unique(),
    expiresAt: time("expires_at").notNull(),
    createdAt: time("created_at").notNull().defaultNow(),
    revokedAt: time("revoked_at"),
  },
  (t) => [index("session_expiry").on(t.expiresAt)],
);
export const inquiryStatuses = [
  "new",
  "in_progress",
  "waiting",
  "completed",
  "cancelled",
] as const;
export type InquiryStatus = (typeof inquiryStatuses)[number];
export const inquiryPolicies = pgTable("inquiry_policies", {
  digest: text("digest").primaryKey(),
  document: jsonb("document").notNull().$type<Record<string, unknown>>(),
  createdAt: time("created_at").notNull().defaultNow(),
});
export const inquiries = pgTable(
  "inquiries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    number: integer("number").notNull().generatedAlwaysAsIdentity().unique(),
    source: text("source").notNull().$type<"home" | "contacts" | "builder">(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    tourSlug: text("tour_slug"),
    details: jsonb("details").notNull().$type<Record<string, unknown>>(),
    status: text("status").notNull().default("new").$type<InquiryStatus>(),
    internalNote: text("internal_note").notNull().default(""),
    isTest: boolean("is_test").notNull().default(true),
    idempotencyKey: uuid("idempotency_key").notNull().unique(),
    payloadHash: text("payload_hash").notNull(),
    submissionHash: text("submission_hash"),
    policyDigest: text("policy_digest").references(
      () => inquiryPolicies.digest,
    ),
    consentGiven: boolean("consent_given"),
    consentRecordedAt: time("consent_recorded_at"),
    createdAt: time("created_at").notNull().defaultNow(),
    updatedAt: time("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("inquiry_status_created").on(t.status, t.createdAt),
    check(
      "inquiry_status",
      sql`${t.status} IN ('new','in_progress','waiting','completed','cancelled')`,
    ),
    check("inquiry_source", sql`${t.source} IN ('home','contacts','builder')`),
  ],
);
export const adminAuditLogs = pgTable("admin_audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  action: text("action").notNull(),
  adminId: uuid("admin_id").references(() => adminUsers.id, {
    onDelete: "set null",
  }),
  entityId: text("entity_id"),
  metadata: jsonb("metadata")
    .notNull()
    .default({})
    .$type<Record<string, string>>(),
  createdAt: time("created_at").notNull().defaultNow(),
});
export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull().$type<Record<string, unknown>>(),
  updatedAt: time("updated_at").notNull().defaultNow(),
});
export const rateLimits = pgTable("rate_limits", {
  key: text("key").primaryKey(),
  count: integer("count").notNull(),
  expiresAt: time("expires_at").notNull(),
});

export const telegramBots = pgTable("telegram_bots", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  encryptedToken: jsonb("encrypted_token")
    .notNull()
    .$type<{ keyId: string; iv: string; tag: string; ciphertext: string }>(),
  enabled: boolean("enabled").notNull().default(false),
  checkStatus: text("check_status").notNull().default("unchecked"),
  username: text("username"),
  telegramId: text("telegram_id"),
  lastError: text("last_error"),
  checkedAt: time("checked_at"),
  revision: integer("revision").notNull().default(1),
  nextSendAt: time("next_send_at").notNull().defaultNow(),
  createdAt: time("created_at").notNull().defaultNow(),
  updatedAt: time("updated_at").notNull().defaultNow(),
});
export const telegramRecipients = pgTable(
  "telegram_recipients",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    botId: uuid("bot_id")
      .notNull()
      .references(() => telegramBots.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    chatId: text("chat_id").notNull(),
    enabled: boolean("enabled").notNull().default(false),
    revision: integer("revision").notNull().default(1),
    nextSendAt: time("next_send_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("telegram_bot_chat").on(t.botId, t.chatId)],
);
export const telegramEvents = pgTable("telegram_events", {
  event: text("event")
    .primaryKey()
    .$type<"inquiry.created" | "inquiry.status_changed" | "delivery.failed">(),
  enabled: boolean("enabled").notNull().default(false),
});
export const telegramRoutes = pgTable(
  "telegram_routes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    event: text("event")
      .notNull()
      .references(() => telegramEvents.event, { onDelete: "cascade" }),
    recipientId: uuid("recipient_id")
      .notNull()
      .references(() => telegramRecipients.id, { onDelete: "cascade" }),
  },
  (t) => [uniqueIndex("telegram_event_recipient").on(t.event, t.recipientId)],
);
export const telegramJobs = pgTable(
  "telegram_jobs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    dedupeKey: text("dedupe_key").notNull().unique(),
    event: text("event").notNull(),
    botId: uuid("bot_id").references(() => telegramBots.id, {
      onDelete: "set null",
    }),
    recipientId: uuid("recipient_id").references(() => telegramRecipients.id, {
      onDelete: "set null",
    }),
    botName: text("bot_name").notNull(),
    recipientName: text("recipient_name").notNull(),
    botRevision: integer("bot_revision").notNull(),
    recipientRevision: integer("recipient_revision").notNull(),
    message: text("message").notNull(),
    status: text("status").notNull().default("pending"),
    attempts: integer("attempts").notNull().default(0),
    runAt: time("run_at").notNull().defaultNow(),
    leaseId: uuid("lease_id"),
    leaseUntil: time("lease_until"),
    errorCode: text("error_code"),
    telegramMessageId: text("telegram_message_id"),
    createdAt: time("created_at").notNull().defaultNow(),
    updatedAt: time("updated_at").notNull().defaultNow(),
  },
  (t) => [index("telegram_due").on(t.status, t.runAt)],
);
export const telegramWorker = pgTable("telegram_worker", {
  id: integer("id").primaryKey().default(1),
  lastRunAt: time("last_run_at").notNull(),
});

export const cmsDocuments = pgTable("cms_documents", {
  key: text("key").primaryKey(), kind: text("kind").notNull(),
  draftVersion: integer("draft_version").notNull().default(0),
  publishedVersion: integer("published_version"), updatedAt: time("updated_at").notNull().defaultNow(),
});
export const cmsVersions = pgTable("cms_versions", {
  documentKey: text("document_key").notNull().references(() => cmsDocuments.key),
  version: integer("version").notNull(), payload: jsonb("payload").notNull().$type<Record<string, unknown>>(),
  adminId: uuid("admin_id").references(() => adminUsers.id, { onDelete: "set null" }),
  createdAt: time("created_at").notNull().defaultNow(),
},t=>[primaryKey({columns:[t.documentKey,t.version]})]);

// Binary assets are durable PostgreSQL rows, never ephemeral /tmp paths.
const binary = customType<{ data: Buffer }>({ dataType() { return "bytea"; } });
export const cmsMedia = pgTable("cms_media", {
 id: uuid("id").primaryKey().defaultRandom(), title:text("title").notNull(),alt:text("alt").notNull(),author:text("author").notNull(),source:text("source").notNull(),rights:text("rights").notNull(),commercialUse:boolean("commercial_use").notNull(),bytes:binary("bytes").notNull(),thumbnail:binary("thumbnail").notNull(),width:integer("width").notNull(),height:integer("height").notNull(),size:integer("size").notNull(),createdAt:time("created_at").notNull().defaultNow(),
});
export const cmsMediaRefs=pgTable("cms_media_refs",{documentKey:text("document_key").notNull(),version:integer("version").notNull(),mediaId:uuid("media_id").notNull().references(()=>cmsMedia.id,{onDelete:"restrict"})},t=>[primaryKey({columns:[t.documentKey,t.version,t.mediaId]})]);
