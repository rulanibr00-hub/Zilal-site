import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import * as schema from "./schema";
export function createDatabase() {
  const url = process.env.DATABASE_URL;
  if (!url || !/^postgres(?:ql)?:\/\//.test(url))
    throw new Error("DATABASE_NOT_CONFIGURED");
  // TLS parameters belong in DATABASE_URL. Never disable certificate validation here.
  const pool = new Pool({
    connectionString: url,
    max: 5,
    connectionTimeoutMillis: 5000,
    idleTimeoutMillis: 30000,
    statement_timeout: 10000,
  });
  pool.on("error", () => console.error("DATABASE_CONNECTION_ERROR"));
  return { pool, db: drizzle(pool, { schema }) };
}
