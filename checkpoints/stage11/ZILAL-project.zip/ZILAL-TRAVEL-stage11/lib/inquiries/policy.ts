import { readFileSync, statSync } from "node:fs";
import { isAbsolute } from "node:path";
import { hashToken, originConfig } from "../admin/security";
import {
  approvalFileSchema,
  disabledConfig,
  type IntakeConfig,
} from "./contracts";
export function inspectInquiryPolicy() {
  try {
    const file = process.env.INQUIRY_POLICY_FILE ?? "";
    if (!isAbsolute(file))
      return { valid: false as const, reason: "POLICY_MISSING" };
    const stat = statSync(/* turbopackIgnore: true */ file);
    if (!stat.isFile() || stat.size > 65536)
      return { valid: false as const, reason: "POLICY_INVALID" };
    const parsed = approvalFileSchema.safeParse(
      JSON.parse(readFileSync(/* turbopackIgnore: true */ file, "utf8")),
    );
    if (
      !parsed.success ||
      new Date(parsed.data.approval.confirmedAt).getTime() > Date.now() + 60000
    )
      return { valid: false as const, reason: "POLICY_INVALID" };
    const approvalHash = hashToken(JSON.stringify(parsed.data));
    const policyDigest = hashToken(JSON.stringify(parsed.data.policy));
    return {
      valid: true as const,
      policy: parsed.data.policy,
      policyDigest,
      approvalHash,
      approved: process.env.PUBLIC_INQUIRIES_APPROVAL_SHA256 === approvalHash,
    };
  } catch {
    return { valid: false as const, reason: "POLICY_INVALID" };
  }
}
export function inquiryConfiguration(): {
  public: IntakeConfig;
  policy: ReturnType<typeof inspectInquiryPolicy>;
} {
  const policy = inspectInquiryPolicy();
  let mode: IntakeConfig["mode"] = "disabled";
  try {
    const origin = originConfig();
    const url = new URL(process.env.DATABASE_URL ?? "");
    const live = process.env.PUBLIC_INQUIRIES_ENABLED === "true",
      test = process.env.PUBLIC_INQUIRIES_TEST_MODE === "true";
    if (
      policy.valid &&
      policy.approved &&
      /^(postgres|postgresql):$/.test(url.protocol) &&
      !(live && test)
    ) {
      if (
        test &&
        origin.local &&
        ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname) &&
        /^[\w-]+_test$/.test(url.pathname.slice(1)) &&
        process.env.ADMIN_TEST_INQUIRIES === "true" &&
        process.env.TELEGRAM_NETWORK_ENABLED !== "true"
      )
        mode = "test";
      if (
        live &&
        origin.secure &&
        !test &&
        !/\.(invalid|example|test|localhost)$/i.test(
          policy.policy.contactEmail.split("@")[1],
        )
      )
        mode = "live";
    }
  } catch {
    /* Configuration always fails closed. */
  }
  return {
    public:
      mode !== "disabled" && policy.valid
        ? {
            mode,
            policyRevision: policy.policyDigest,
            consentRequired: policy.policy.consentRequired,
            consentText: policy.policy.consentText,
            notice: policy.policy.notice,
            contactEmail: policy.policy.contactEmail,
          }
        : disabledConfig,
    policy,
  };
}
