export type IntakeMode = "disabled" | "test" | "live";
export interface IntakeConfig {
  mode: IntakeMode;
  policyRevision: string | null;
  consentRequired: boolean;
  consentText: string;
  notice: string;
  contactEmail: string | null;
}
export const disabledConfig: IntakeConfig = {
  mode: "disabled",
  policyRevision: null,
  consentRequired: false,
  consentText: "",
  notice:
    "Приём заявок отключён. Доступна только проверка заполнения без отправки.",
  contactEmail: null,
};
