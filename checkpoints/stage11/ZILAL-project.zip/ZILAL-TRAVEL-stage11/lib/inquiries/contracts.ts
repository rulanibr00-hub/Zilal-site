import { z } from "zod";
export const policySchema = z
  .object({
    version: z.string().trim().min(1).max(80),
    operatorName: z.string().trim().min(3).max(300),
    operatorAddress: z.string().trim().min(5).max(500),
    contactEmail: z.string().trim().email().max(254),
    purposes: z.array(z.string().trim().min(5).max(1000)).min(1).max(10),
    legalBasis: z.string().trim().min(10).max(2000),
    retentionDays: z.number().int().min(1).max(3650),
    retentionExplanation: z.string().trim().min(10).max(2000),
    recipients: z
      .array(
        z
          .object({
            name: z.string().trim().min(2).max(200),
            purpose: z.string().trim().min(5).max(1000),
            location: z.string().trim().min(2).max(200),
          })
          .strict(),
      )
      .min(1)
      .max(20),
    rights: z.string().trim().min(10).max(3000),
    notice: z.string().trim().min(10).max(1000),
    consentRequired: z.boolean(),
    consentText: z.string().trim().max(2000),
    updatedOn: z.iso.date(),
  })
  .strict()
  .refine((p) => !p.consentRequired || p.consentText.length >= 10, {
    path: ["consentText"],
    message: "Нужен согласованный текст согласия",
  });
export const approvalFileSchema = z
  .object({
    policy: policySchema,
    approval: z
      .object({
        confirmedBy: z.string().trim().min(3).max(200),
        confirmedAt: z.iso.datetime({ offset: true }),
        reference: z.string().trim().min(5).max(500),
      })
      .strict(),
  })
  .strict();
export type InquiryPolicy = z.infer<typeof policySchema>;
export { disabledConfig } from "./client-contracts";
export type { IntakeMode, IntakeConfig } from "./client-contracts";
export const submissionSchema = z
  .object({
    inquiry: z.unknown(),
    policyRevision: z.string().regex(/^[a-f0-9]{64}$/),
    consent: z.boolean(),
    website: z.string().max(200),
  })
  .strict();
