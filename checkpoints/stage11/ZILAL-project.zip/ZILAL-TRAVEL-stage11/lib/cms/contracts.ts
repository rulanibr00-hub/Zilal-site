import { z } from "zod";
export const plain = (max: number) => z.string().trim().max(max).refine(s => !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(s));
export const destinationKeys = ["issyk-kul","son-kul","skazka","karakol","ala-kul"] as const;
export const imageKeys = ["hero","mountain","lake","pasture","canyon","alakul","karakol","culture"] as const;
export const mediaIds = z.array(z.uuid()).max(12).refine(a=>new Set(a).size===a.length);
export const tourSchema = z.object({
 slug: z.string().min(3).max(90).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
 title: plain(160).min(1), description: plain(3000).min(1),
 durationDays: z.number().int().min(1).max(60),
 destinationIds: z.array(z.enum(destinationKeys)).min(1).max(5).refine(a=>new Set(a).size===a.length),
 style: z.enum(["comfort","adventure","combined"]),
 activities: z.array(z.enum(["panoramas","culture","walks","trekking"])).min(1).max(4),
 difficulty: z.enum(["easy","moderate","challenging"]), difficultyNote: plain(2000),
 highlights: z.array(plain(500).min(1)).max(12),
 itinerary: z.array(z.object({title:plain(160).min(1),description:plain(2000).min(1)}).strict()).max(60),
 proposed: z.array(plain(500).min(1)).max(30), notIncluded: z.array(plain(500).min(1)).max(30), toConfirm: z.array(plain(500).min(1)).max(30),
 image: z.enum(imageKeys), mediaIds,
 // Publication is editorial only; unapproved programs always retain their example label.
 example: z.literal(true),
}).strict().refine(v=>v.itinerary.length<=v.durationDays,{message:"Число дней программы превышает длительность",path:["itinerary"]});
export const pageKeys = ["home","kyrgyzstan","about","contacts"] as const;
export const pageSchema = z.object({blocks:z.record(z.string().regex(/^[a-z0-9-]{1,50}$/),plain(5000)).refine(v=>Object.keys(v).length<=160),mediaIds}).strict();
const optionalEmail=z.union([z.literal(""),z.email().max(254)]);
const optionalPhone=z.union([z.literal(""),z.string().max(40).regex(/^\+[1-9][\d () .-]{6,30}$/).refine(v=>{const n=v.replace(/\D/g,"").length;return n>=7&&n<=15;})]);
export const safeUrl=z.url().max(1000).refine(s=>{try{const u=new URL(s);return u.protocol==="https:"&&!u.username&&!u.password;}catch{return false;}});
export const companySchema=z.object({name:plain(160).min(1),phone:optionalPhone,whatsapp:optionalPhone,email:optionalEmail,address:plain(500),hours:plain(200),description:plain(2000),socials:z.array(z.object({label:plain(60).min(1),url:safeUrl}).strict()).max(8)}).strict();
export const mediaMetadata=z.object({title:plain(160).min(1),alt:plain(500).min(1),author:plain(200).min(1),source:plain(1000).min(1),rights:plain(2000).min(10),commercialUse:z.literal(true)}).strict();
export type TourContent=z.infer<typeof tourSchema>;
export type PageContent=z.infer<typeof pageSchema>;
export type CompanyContent=z.infer<typeof companySchema>;
export type MediaInfo={id:string;title:string;alt:string;author:string;source:string;rights:string;width:number;height:number;size:number};
export function parseContent(kind:string,value:unknown){return kind==="tour"?tourSchema.parse(value):kind==="page"?pageSchema.parse(value):companySchema.parse(value);}
export const commandSchema=z.object({action:z.enum(["save","publish","unpublish","restore"]),key:z.string().max(110).regex(/^(tour:[a-z0-9-]{3,90}|page:(home|kyrgyzstan|about|contacts)|company:main)$/),expectedVersion:z.number().int().min(0),payload:z.unknown().optional(),version:z.number().int().min(1).optional(),confirmed:z.boolean().optional()}).strict();
