import { destinations } from "@/lib/data/destinations";
export { photos } from "@/lib/media";
export type { PhotoKey } from "@/lib/types";
// Add an English dictionary here without changing data identifiers or URLs.
export const content = {
  ru: { title: "Кыргызстан, который ты почувствуешь" },
} as const;
// A small view model shared by all destination grids.
export const destinationCards = destinations.map((d) => ({
  id: d.id,
  name: d.name.ru,
  caption: d.caption.ru,
  tag: d.category.ru,
  image: d.image,
}));
