import type { TripDraft } from "@/lib/trip-builder";
// Adapters for the existing forms. They do not perform any network request.
// The server still validates every field; client data is never trusted.
export function inquiryFormPayload(
  source: "home" | "contacts",
  fields: { name: string; email: string; message: string },
) {
  return {
    source,
    name: fields.name,
    email: fields.email,
    details: { message: fields.message },
  };
}
export function tripDraftPayload(draft: TripDraft, tourSlug?: string) {
  return {
    source: "builder" as const,
    name: draft.name,
    email: draft.email,
    phone: draft.phone,
    ...(tourSlug ? { tourSlug } : {}),
    details: {
      style: draft.style,
      destinationIds: [...draft.destinationIds],
      activities: [...draft.activities],
      duration: Number(draft.duration),
      flexibleDates: draft.flexibleDates,
      startDate: draft.flexibleDates ? "" : draft.startDate,
      adults: Number(draft.adults),
      children: Number(draft.children),
      accommodation: draft.accommodation,
      wishes: draft.wishes,
      contactMethod: draft.contactMethod,
    },
  };
}
