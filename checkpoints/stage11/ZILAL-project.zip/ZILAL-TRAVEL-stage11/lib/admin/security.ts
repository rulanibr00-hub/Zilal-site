import {
  createHash,
  createHmac,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";
import argon2 from "argon2";
export const sessionSeconds = 8 * 60 * 60;
export const hashToken = (value: string) =>
  createHash("sha256").update(value).digest("hex");
export const randomToken = () => randomBytes(32).toString("hex");
export const csrfFor = (token: string) =>
  createHmac("sha256", token).update("zilal-admin-csrf-v1").digest("hex");
export function equalToken(a: string, b: string) {
  return (
    /^[a-f0-9]{64}$/.test(a) &&
    /^[a-f0-9]{64}$/.test(b) &&
    timingSafeEqual(Buffer.from(a, "hex"), Buffer.from(b, "hex"))
  );
}
export const hashPassword = (password: string) =>
  argon2.hash(password, {
    type: argon2.argon2id,
    memoryCost: 65536,
    timeCost: 3,
    parallelism: 1,
    hashLength: 32,
  });
export async function verifyPassword(hash: string, password: string) {
  try {
    return await argon2.verify(hash, password);
  } catch {
    return false;
  }
}
export function validateNewPassword(password: string) {
  return (
    password.length >= 16 && password.length <= 128 && !/^\s+$/.test(password)
  );
}
export function originConfig() {
  const value = process.env.ADMIN_ORIGIN;
  if (!value) throw new Error("ADMIN_ORIGIN_NOT_CONFIGURED");
  const url = new URL(value);
  const local = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (
    url.username ||
    url.password ||
    url.pathname !== "/" ||
    url.search ||
    url.hash ||
    (!local && url.protocol !== "https:") ||
    !["https:", "http:"].includes(url.protocol)
  )
    throw new Error("INVALID_ADMIN_ORIGIN");
  return {
    origin: url.origin,
    local,
    secure: url.protocol === "https:",
    cookieName:
      url.protocol === "https:" ? "__Host-zilal-admin" : "zilal-admin-local",
  };
}
