import { z } from "zod";
export const statuses = [
  "new",
  "in_progress",
  "waiting",
  "completed",
  "cancelled",
] as const;
export const statusLabels = {
  new: "Новая",
  in_progress: "В работе",
  waiting: "Ожидает ответа",
  completed: "Завершена",
  cancelled: "Отменена",
};
export const sourceLabels = {
  home: "Главная",
  contacts: "Контакты",
  builder: "Конструктор",
};
export const loginSchema = z
  .object({
    login: z
      .string()
      .trim()
      .min(3)
      .max(254)
      .regex(/^[\p{L}\p{N}@._+\-]+$/u)
      .transform((s) => s.toLowerCase()),
    password: z.string().min(1).max(1024),
  })
  .strict();
const text = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .refine((s) => !/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/.test(s));
const email = z.string().trim().max(254).email();
const phone = z
  .string()
  .trim()
  .max(40)
  .regex(/^\+[1-9][\d\s().-]*$/)
  .refine((s) => {
    const n = s.replace(/\D/g, "").length;
    return n >= 7 && n <= 15;
  });
export const tripDetailsSchema = z
  .object({
    style: z.enum(["comfort", "adventure", "combined"]),
    destinationIds: z
      .array(z.enum(["issyk-kul", "son-kul", "skazka", "karakol", "ala-kul"]))
      .min(1)
      .max(5)
      .refine((a) => new Set(a).size === a.length),
    activities: z
      .array(
        z.enum([
          "horse-riding",
          "trekking",
          "jeep",
          "culture",
          "gastronomy",
          "relaxation",
        ]),
      )
      .min(1)
      .max(6)
      .refine((a) => new Set(a).size === a.length),
    duration: z.number().int().min(1).max(60),
    flexibleDates: z.boolean(),
    startDate: z.string().max(10),
    adults: z.number().int().min(1).max(20),
    children: z.number().int().min(0).max(20),
    accommodation: z.enum(["comfort", "premium", "nature", "mixed", "advice"]),
    wishes: text(2000),
    contactMethod: z.enum(["phone", "whatsapp"]),
  })
  .strict();
const baseFields = {
  name: text(100).refine((s) => s.length > 0),
  email,
  phone: phone.optional(),
  tourSlug: z.string().min(1).max(100).optional(),
};
export const inquirySchema = z.discriminatedUnion("source", [
  z
    .object({
      ...baseFields,
      source: z.literal("home"),
      details: z.object({ message: text(2000) }).strict(),
    })
    .strict(),
  z
    .object({
      ...baseFields,
      source: z.literal("contacts"),
      details: z
        .object({ message: text(2000).refine((s) => s.length > 0) })
        .strict(),
    })
    .strict(),
  z
    .object({
      ...baseFields,
      phone,
      source: z.literal("builder"),
      details: tripDetailsSchema,
    })
    .strict(),
]);
export type InquiryInput = z.infer<typeof inquirySchema>;
export const searchSchema = z
  .object({
    query: text(100).default(""),
    status: z.enum(["all", ...statuses]).default("all"),
    page: z.number().int().min(1).max(10000).default(1),
  })
  .strict();
export const updateInquirySchema = z
  .object({
    status: z.enum(statuses),
    internalNote: text(2000),
    expectedUpdatedAt: z.iso.datetime(),
  })
  .strict();
const maybe = <T extends z.ZodType>(type: T) => z.union([z.literal(""), type]);
export const settingSchema = z.discriminatedUnion("key", [
  z
    .object({
      key: z.literal("company"),
      value: z
        .object({
          displayName: text(100),
          legalName: text(200),
          description: text(2000),
        })
        .strict(),
    })
    .strict(),
  z
    .object({
      key: z.literal("contacts"),
      value: z
        .object({
          phone: maybe(phone),
          whatsapp: maybe(phone),
          email: maybe(email),
          address: text(500),
          hours: text(200),
        })
        .strict(),
    })
    .strict(),
  z
    .object({
      key: z.literal("notifications"),
      value: z
        .object({
          emailEnabled: z.literal(false),
          telegramEnabled: z.literal(false),
          events: z
            .array(z.enum(["inquiry.created", "inquiry.status_changed"]))
            .max(2)
            .refine((a) => new Set(a).size === a.length),
        })
        .strict(),
    })
    .strict(),
]);
export const defaultSettings = {
  company: { displayName: "ZILAL TRAVEL", legalName: "", description: "" },
  contacts: { phone: "", whatsapp: "", email: "", address: "", hours: "" },
  notifications: {
    emailEnabled: false,
    telegramEnabled: false,
    events: [] as string[],
  },
};
export type SettingInput = z.infer<typeof settingSchema>;
export function inquiryNumber(n: number) {
  return `ZL-${String(n).padStart(6, "0")}`;
}
export function adminDate(value: string | Date) {
  return new Intl.DateTimeFormat("ru-RU", {
    timeZone: "Asia/Bishkek",
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}
