import "server-only";
import sharp from "sharp";
import { sql } from "drizzle-orm";
import { z } from "zod";
import { mediaMetadata } from "../cms/contracts";
import { database } from "./db";
import { HttpError } from "./http";
export const mediaLimit=8*1024*1024;
export async function boundedBody(request:Request,max:number){
 const declared=request.headers.get('content-length');if(declared&&(!/^\d+$/.test(declared)||Number(declared)>max))throw new HttpError(413,'Файл слишком большой. Максимум 8 МиБ.');
 const reader=request.body?.getReader();if(!reader)throw new HttpError(400,'Нет файла.');const chunks:Uint8Array[]=[];let size=0;
 try{while(true){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>max){await reader.cancel();throw new HttpError(413,'Файл слишком большой.');}chunks.push(r.value);}}finally{reader.releaseLock();}return Buffer.concat(chunks);
}
export async function normalizeImage(bytes:Buffer){
 // Signature checked before any decoder. Animated/multipage and vector inputs are rejected.
 const jpeg=bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
 const png=bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
 const webp=bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP';
 if(!jpeg&&!png&&!webp)throw new HttpError(400,'Разрешены только настоящие JPEG, PNG и WebP. SVG не принимается.');
 try{const image=sharp(bytes,{limitInputPixels:40000000,failOn:'warning'});const meta=await image.metadata();if(!['jpeg','png','webp'].includes(meta.format??'')||(meta.pages??1)>1)throw Error();const {data,info}=await image.rotate().resize({width:2000,height:2000,fit:'inside',withoutEnlargement:true}).webp({quality:82}).toBuffer({resolveWithObject:true});const thumb=await sharp(data).resize({width:360,height:240,fit:'inside',withoutEnlargement:true}).webp({quality:70}).toBuffer();return {data,thumb,width:info.width,height:info.height};}catch{throw new HttpError(400,'Изображение повреждено, анимировано или превышает 40 мегапикселей.');}
}
export async function mediaList(){return (await database().db.execute(sql`SELECT id,title,alt,author,source,rights,width,height,size,created_at FROM cms_media ORDER BY created_at DESC`)).rows;}
export async function uploadMedia(request:Request,adminId:string){
 if(!request.headers.get('content-type')?.startsWith('multipart/form-data;'))throw new HttpError(415,'Ожидается файл изображения.');
 const bytes=await boundedBody(request,mediaLimit+16384);let form:FormData;try{form=await new Response(bytes,{headers:{'Content-Type':request.headers.get('content-type')!}}).formData();}catch{throw new HttpError(400,'Не удалось прочитать файл.');}
 if([...form.keys()].some(k=>!['file','metadata'].includes(k))||form.getAll('file').length!==1||form.getAll('metadata').length!==1)throw new HttpError(400,'Некорректная загрузка.');
 const file=form.get('file');if(!(file instanceof File)||file.size>mediaLimit||!['image/jpeg','image/png','image/webp'].includes(file.type))throw new HttpError(400,'Выберите JPEG, PNG или WebP до 8 МиБ.');
 let meta;try{meta=mediaMetadata.parse(JSON.parse(String(form.get('metadata'))));}catch{throw new HttpError(400,'Заполните название, alt, автора, источник и подтверждение коммерческих прав.');}
 const normalized=await normalizeImage(Buffer.from(await file.arrayBuffer()));
 return database().db.transaction(async tx=>{
 await tx.execute(sql`SELECT pg_advisory_xact_lock(81390428)`);
 const total=await tx.execute(sql`SELECT COALESCE(sum(size),0) AS bytes,count(*) AS count FROM cms_media`);if(Number(total.rows[0].bytes)+normalized.data.length>250*1024*1024||Number(total.rows[0].count)>=500)throw new HttpError(413,'Лимит медиатеки достигнут (250 МиБ / 500 файлов).');
 const r=await tx.execute(sql`INSERT INTO cms_media(title,alt,author,source,rights,commercial_use,bytes,thumbnail,width,height,size) VALUES(${meta.title},${meta.alt},${meta.author},${meta.source},${meta.rights},true,${normalized.data},${normalized.thumb},${normalized.width},${normalized.height},${normalized.data.length}) RETURNING id`);
 await tx.execute(sql`INSERT INTO admin_audit_logs(action,admin_id,entity_id) VALUES('media_uploaded',${adminId},${r.rows[0].id as string})`);return {id:r.rows[0].id};});
}
export async function deleteMedia(input:unknown,adminId:string){const v=z.object({id:z.uuid(),confirmed:z.literal(true)}).strict().safeParse(input);if(!v.success)throw new HttpError(400,'Подтвердите удаление.');
 return database().db.transaction(async tx=>{const r=await tx.execute(sql`SELECT id FROM cms_media WHERE id=${v.data.id} FOR UPDATE`);if(!r.rows.length)throw new HttpError(404,'Файл не найден.');const refs=await tx.execute(sql`SELECT 1 FROM cms_media_refs WHERE media_id=${v.data.id} LIMIT 1`);if(refs.rows.length)throw new HttpError(409,'Файл используется в текущей или сохранённой версии. Удаление запрещено.');await tx.execute(sql`DELETE FROM cms_media WHERE id=${v.data.id}`);await tx.execute(sql`INSERT INTO admin_audit_logs(action,admin_id,entity_id) VALUES('media_deleted',${adminId},${v.data.id})`);return {deleted:true};});
}
