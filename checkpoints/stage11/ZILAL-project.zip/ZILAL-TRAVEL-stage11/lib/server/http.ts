import "server-only";
import { NextResponse } from "next/server";
import { originConfig } from "@/lib/admin/security";
export class HttpError extends Error {
  constructor(
    public status: number,
    public message: string,
    public code = "REQUEST_REJECTED",
    public fields?: Record<string, string>,
  ) {
    super(message);
  }
}
export const privateHeaders = {
  "Cache-Control": "no-store, max-age=0",
  "X-Robots-Tag": "noindex, nofollow",
  "Referrer-Policy": "no-referrer",
};
export function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: privateHeaders });
}
export function assertOrigin(request: Request) {
  let expected: string;
  try {
    expected = originConfig().origin;
  } catch {
    throw new HttpError(503, "Административный раздел ещё не настроен.");
  }
  if (request.headers.get("origin") !== expected)
    throw new HttpError(
      403,
      "Запрос отклонён. Обновите страницу.",
      "ORIGIN_REJECTED",
    );
  if (request.headers.get("sec-fetch-site") === "cross-site")
    throw new HttpError(403, "Запрос отклонён.");
}
export async function readJson(request: Request): Promise<unknown> {
  if (
    request.headers.get("content-type")?.split(";")[0].trim() !==
    "application/json"
  )
    throw new HttpError(415, "Ожидается JSON.");
  const declared = request.headers.get("content-length");
  if (declared && (!/^\d+$/.test(declared) || Number(declared) > 32768))
    throw new HttpError(413, "Запрос слишком большой.");
  const reader = request.body?.getReader();
  if (!reader) throw new HttpError(400, "Пустой запрос.");
  let size = 0;
  const chunks: Uint8Array[] = [];
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > 32768) {
        await reader.cancel();
        throw new HttpError(413, "Запрос слишком большой.");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new HttpError(400, "Некорректный JSON.");
  }
}
export async function api(operation: () => Promise<Response>) {
  try {
    return await operation();
  } catch (error) {
    if (error instanceof HttpError) {
      const response = json(
        {
          error: error.message,
          code: error.code,
          ...(error.fields ? { fields: error.fields } : {}),
        },
        error.status,
      );
      if (error.status === 429)
        response.headers.set(
          "Retry-After",
          error.code === "RATE_LIMITED" ? "900" : "60",
        );
      return response;
    }
    console.error("ADMIN_OPERATION_FAILED");
    return json(
      {
        error: "Хранилище временно недоступно. Попробуйте позже.",
        code: "UNAVAILABLE",
      },
      503,
    );
  }
}
