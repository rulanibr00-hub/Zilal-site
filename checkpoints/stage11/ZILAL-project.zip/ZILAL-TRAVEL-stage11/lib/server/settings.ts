import "server-only";
import { siteSettings, adminAuditLogs } from "@/lib/db/schema";
import { settingSchema, defaultSettings } from "@/lib/admin/contracts";
import { database } from "./db";
import { HttpError } from "./http";
export async function readSettings() {
  const rows = await database().db.select().from(siteSettings);
  const values = structuredClone(defaultSettings);
  for (const row of rows) {
    const parsed = settingSchema.safeParse({ key: row.key, value: row.value });
    if (parsed.success)
      Object.assign(values, { [parsed.data.key]: parsed.data.value });
  }
  return values;
}
export async function saveSetting(input: unknown, adminId: string) {
  const parsed = settingSchema.safeParse(input);
  if (!parsed.success)
    throw new HttpError(
      400,
      "Проверьте поля настройки. Секреты и неизвестные ключи не принимаются.",
    );
  const { key, value } = parsed.data;
  await database().db.transaction(async (tx) => {
    await tx
      .insert(siteSettings)
      .values({ key, value })
      .onConflictDoUpdate({
        target: siteSettings.key,
        set: { value, updatedAt: new Date() },
      });
    await tx
      .insert(adminAuditLogs)
      .values({
        adminId,
        action: "setting_updated",
        entityId: key,
        metadata: { settingKey: key },
      });
  });
  return { saved: true };
}
