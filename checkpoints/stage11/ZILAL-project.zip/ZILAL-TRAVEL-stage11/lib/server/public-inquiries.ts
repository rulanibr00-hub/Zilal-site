import "server-only";
import { cookies } from "next/headers";
import { isIP } from "node:net";
import { z } from "zod";
import { sql } from "drizzle-orm";
import { rateLimits } from "@/lib/db/schema";
import {
  randomToken,
  hashToken,
  csrfFor,
  equalToken,
  originConfig,
} from "@/lib/admin/security";
import { inquiryConfiguration } from "@/lib/inquiries/policy";
import { submissionSchema } from "@/lib/inquiries/contracts";
import { database } from "./db";
import { HttpError, assertOrigin } from "./http";
import { saveValidatedInquiry, validateInquiry } from "./inquiries";
import type { Executor } from "@/lib/telegram/store";
export const publicCookie = () =>
  originConfig().secure ? "__Host-zilal-inquiry" : "zilal-inquiry-local";
export async function publicLimit(
  tx: Executor,
  subject: string,
  maximum: number,
  windowMs: number,
) {
  const bucket = Math.floor(Date.now() / windowMs);
  const [row] = await tx
    .insert(rateLimits)
    .values({
      key: `public:${subject}:${bucket}`,
      count: 1,
      expiresAt: new Date((bucket + 1) * windowMs),
    })
    .onConflictDoUpdate({
      target: rateLimits.key,
      set: { count: sql`${rateLimits.count}+1` },
    })
    .returning({ count: rateLimits.count });
  if (row.count > maximum)
    throw new HttpError(
      429,
      "Слишком много обращений. Повторите позже; введённые данные сохранены в форме.",
      "PUBLIC_RATE_LIMITED",
    );
}
function active() {
  const config = inquiryConfiguration();
  if (config.public.mode === "disabled" || !config.policy.valid)
    throw new HttpError(
      503,
      "Приём заявок сейчас отключён. Данные не сохранены.",
      "PUBLIC_INTAKE_DISABLED",
    );
  return config as typeof config & {
    policy: Extract<typeof config.policy, { valid: true }>;
  };
}
function trustedIp(request: Request) {
  const header = process.env.INQUIRY_TRUSTED_IP_HEADER;
  if (
    !["x-real-ip", "cf-connecting-ip"].includes(header ?? "") ||
    process.env.INQUIRY_PROXY_APPROVED !== "true"
  )
    return undefined;
  const value = request.headers.get(header!) ?? "";
  if (!isIP(value))
    throw new HttpError(503, "Приём временно недоступен. Повторите позже.");
  return hashToken(value);
}
async function requestLimits(
  request: Request,
  session: string,
  kind: "session" | "submit",
) {
  const ip = trustedIp(request);
  await database().db.transaction(async (tx) => {
    await tx.execute(
      sql`DELETE FROM rate_limits WHERE key LIKE 'public:%' AND expires_at < now()`,
    );
    await publicLimit(
      tx,
      kind + ":global",
      kind === "session" ? 60 : 120,
      60000,
    );
    if (ip)
      await publicLimit(
        tx,
        kind + ":ip:" + ip,
        kind === "session" ? 10 : 20,
        60000,
      );
    if (kind === "submit")
      await publicLimit(tx, "attempt:" + hashToken(session), 20, 900000);
  });
}
export async function createPublicSession(request: Request) {
  const cfg = active();
  assertOrigin(request);
  const jar = await cookies();
  const existing = jar.get(publicCookie())?.value;
  const nonce =
    existing && /^[a-f0-9]{64}$/.test(existing) ? existing : randomToken();
  await requestLimits(request, nonce, "session");
  return {
    nonce,
    csrf: csrfFor(nonce),
    policyRevision: cfg.public.policyRevision,
    cookieOptions: {
      httpOnly: true,
      secure: originConfig().secure,
      sameSite: "strict" as const,
      path: "/",
      maxAge: 3600,
    },
  };
}
export async function acceptPublicInquiry(
  request: Request,
  body: () => Promise<unknown>,
) {
  const cfg = active();
  assertOrigin(request);
  const nonce = (await cookies()).get(publicCookie())?.value;
  if (
    !nonce ||
    !/^[a-f0-9]{64}$/.test(nonce) ||
    !equalToken(request.headers.get("x-csrf-token") ?? "", csrfFor(nonce))
  )
    throw new HttpError(
      403,
      "Проверка безопасности не пройдена. Повторите отправку.",
      "CSRF_REJECTED",
    );
  await requestLimits(request, nonce, "submit");
  const parsed = submissionSchema.safeParse(await body());
  if (!parsed.success)
    throw new HttpError(
      400,
      "Проверьте поля и подтверждение условий обработки данных.",
      "VALIDATION",
    );
  const { inquiry, consent, policyRevision, website } = parsed.data;
  if (website)
    throw new HttpError(
      400,
      "Проверка формы не пройдена. Обновите страницу.",
      "FORM_REJECTED",
    );
  if (policyRevision !== cfg.public.policyRevision)
    throw new HttpError(
      409,
      "Условия обработки данных обновились. Ознакомьтесь с ними и повторите отправку.",
      "POLICY_CHANGED",
    );
  if (cfg.public.consentRequired && !consent)
    throw new HttpError(
      400,
      "Для отправки необходимо ваше согласие с указанными условиями.",
      "CONSENT_REQUIRED",
    );
  const key = request.headers.get("idempotency-key");
  if (!z.uuid().safeParse(key).success)
    throw new HttpError(400, "Некорректный ключ отправки. Обновите страницу.");
  const data = validateInquiry(inquiry);
  const saved = await saveValidatedInquiry(data, key!, {
    isTest: cfg.public.mode === "test",
    submissionHash: hashToken(nonce),
    policy: {
      digest: cfg.policy.policyDigest,
      document: cfg.policy.policy,
      consent,
    },
    limits: async (tx) => {
      const fresh = active();
      if (
        fresh.public.mode !== cfg.public.mode ||
        fresh.public.policyRevision !== policyRevision
      )
        throw new HttpError(
          409,
          "Условия приёма изменились. Повторно ознакомьтесь с политикой.",
          "POLICY_CHANGED",
        );
      await publicLimit(tx, "accepted:global-minute", 20, 60000);
      await publicLimit(tx, "accepted:global-hour", 120, 3600000);
      await publicLimit(tx, "accepted:session:" + hashToken(nonce), 5, 900000);
      await publicLimit(
        tx,
        "accepted:contact:" + hashToken(data.email.toLowerCase()),
        5,
        86400000,
      );
    },
  });
  return {
    accepted: true as const,
    number: saved.displayNumber,
    isTest: cfg.public.mode === "test",
    duplicate: saved.duplicate,
  };
}
