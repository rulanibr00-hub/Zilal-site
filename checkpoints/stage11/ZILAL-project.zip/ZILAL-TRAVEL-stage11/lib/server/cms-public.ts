import "server-only";
import { cache } from "react";
import { sql } from "drizzle-orm";
import { database } from "./db";
import { contentSeeds,toTour } from "../cms/seeds";
import { parseContent, type TourContent, type MediaInfo } from "../cms/contracts";
export type PublicContent={documents:Record<string,Record<string,unknown>>;media:Record<string,MediaInfo>};
export const publicContent=cache(async():Promise<PublicContent>=>{
 const documents=structuredClone(contentSeeds),media:Record<string,MediaInfo>={};
 if(!process.env.DATABASE_URL)return {documents,media};
 try{
  const {db}=database();const rows=await db.execute(sql`SELECT d.key,d.kind,v.payload FROM cms_documents d LEFT JOIN cms_versions v ON v.document_key=d.key AND v.version=d.published_version`);
  for(const r of rows.rows){delete documents[r.key as string];if(r.payload)documents[r.key as string]=parseContent(r.kind as string,r.payload) as Record<string,unknown>;}
  try { const assets=await db.execute(sql`SELECT m.id,m.title,m.alt,m.author,m.source,m.rights,m.width,m.height,m.size FROM cms_media m WHERE EXISTS(SELECT 1 FROM cms_media_refs r JOIN cms_documents d ON d.key=r.document_key AND d.published_version=r.version WHERE r.media_id=m.id)`);
  for(const r of assets.rows)media[r.id as string]=r as unknown as MediaInfo;
  } catch {console.error("PUBLIC_MEDIA_UNAVAILABLE");}
 }catch{for(const key of Object.keys(documents))if(key.startsWith('tour:'))delete documents[key];console.error('PUBLIC_CONTENT_UNAVAILABLE');/* Controlled original materials keep the site usable during DB outages. */}
 return {documents,media};
});
export async function publicTours(){const {documents,media}=await publicContent();return Object.entries(documents).filter(([k])=>k.startsWith('tour:')).map(([,p])=>toTour(p as unknown as TourContent,((p.mediaIds??[]) as string[]).map(id=>media[id]).filter(Boolean)));}
export async function publicTour(slug:string){return (await publicTours()).find(t=>t.slug===slug);}
