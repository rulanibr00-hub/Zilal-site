import "server-only";
import { database } from "./db";
import { TelegramStore, TelegramAdminError } from "@/lib/telegram/store";
import { TelegramError } from "@/lib/telegram/contracts";
import { HttpError } from "./http";
export const telegramStore = () => new TelegramStore(database().db);
export async function telegramAction(input: unknown, adminId: string) {
  try {
    return await telegramStore().action(input, adminId);
  } catch (e) {
    if (e instanceof TelegramAdminError)
      throw new HttpError(e.status, e.message);
    if (e instanceof TelegramError)
      throw new HttpError(
        e.code === "NETWORK_DISABLED" || e.code === "KEY_UNAVAILABLE"
          ? 503
          : 400,
        e.message,
        e.code,
      );
    throw e;
  }
}
