import "server-only";
import { createDatabase } from "@/lib/db/connection";
const state = globalThis as unknown as {
  zilalDatabase?: ReturnType<typeof createDatabase>;
};
export function database() {
  return (state.zilalDatabase ??= createDatabase());
}
