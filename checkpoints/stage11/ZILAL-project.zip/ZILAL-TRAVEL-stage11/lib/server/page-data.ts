import "server-only";
import { notFound } from "next/navigation";
import { HttpError } from "./http";
export async function pageData<T>(operation: Promise<T>): Promise<T> {
  try {
    return await operation;
  } catch (error) {
    if (error instanceof HttpError && error.status === 404) notFound();
    throw new Error("ADMIN_STORAGE_UNAVAILABLE");
  }
}
