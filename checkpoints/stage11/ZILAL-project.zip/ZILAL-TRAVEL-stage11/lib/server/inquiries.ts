import { enqueueEvent, inquiryMessage } from "@/lib/telegram/store";
import "server-only";
import { and, count, desc, eq, ilike, or, sql } from "drizzle-orm";
import { z } from "zod";
import {
  inquiries,
  inquiryPolicies,
  adminAuditLogs,
  rateLimits,
} from "@/lib/db/schema";
import {
  inquirySchema,
  searchSchema,
  updateInquirySchema,
  inquiryNumber,
} from "@/lib/admin/contracts";
import { hashToken, originConfig } from "@/lib/admin/security";
import { publicTour } from "./cms-public";
import { getBishkekToday, isCalendarDate } from "@/lib/trip-builder";
import { database } from "./db";
import { HttpError } from "./http";
export function validateInquiry(input: unknown) {
  const result = inquirySchema.safeParse(input);
  if (!result.success) {
    const fields: Record<string, string> = {};
    for (const issue of result.error.issues) {
      const path = issue.path
        .slice(0, issue.path[0] === "details" ? 2 : 1)
        .join(".");
      if (
        ["name", "email", "phone"].includes(path) ||
        path.startsWith("details.")
      )
        fields[path] =
          path === "email"
            ? "Укажите корректный email."
            : path === "phone"
              ? "Укажите номер с + и кодом страны."
              : "Проверьте значение и допустимую длину поля.";
    }
    throw new HttpError(
      400,
      "Проверьте обязательные поля и допустимые значения.",
      "VALIDATION",
      fields,
    );
  }
  const data = result.data;

  if (
    data.source === "builder" &&
    !data.details.flexibleDates &&
    (!isCalendarDate(data.details.startDate) ||
      data.details.startDate < getBishkekToday())
  )
    throw new HttpError(400, "Укажите допустимую дату поездки.", "VALIDATION", {
      "details.startDate":
        "Укажите дату не в прошлом или выберите гибкие даты.",
    });
  if (data.source === "builder" && data.details.flexibleDates)
    data.details.startDate = "";
  return data;
}
export async function createTestInquiry(
  input: unknown,
  key: string | null,
  adminId: string,
) {
  if (process.env.ADMIN_TEST_INQUIRIES !== "true" || !originConfig().local)
    throw new HttpError(
      403,
      "Тестовый приём разрешён только в явно настроенной локальной среде.",
      "TEST_DISABLED",
    );
  if (!z.uuid().safeParse(key).success)
    throw new HttpError(
      400,
      "Нужен уникальный Idempotency-Key в формате UUID.",
    );
  return saveValidatedInquiry(validateInquiry(input), key!, {
    isTest: true,
    adminId,
  });
}
export interface InquiryWriteOptions {
  isTest: boolean;
  adminId?: string;
  submissionHash?: string;
  policy?: {
    digest: string;
    document: Record<string, unknown>;
    consent: boolean;
  };
  limits?: (tx: import("@/lib/telegram/store").Executor) => Promise<void>;
}
export async function saveValidatedInquiry(
  data: import("@/lib/admin/contracts").InquiryInput,
  key: string,
  options: InquiryWriteOptions,
) {
  if (data.tourSlug && !(await publicTour(data.tourSlug))) throw new HttpError(400, "Выбранный маршрут не найден.", "INVALID_TOUR");
  const payloadHash = hashToken(
    JSON.stringify(
      options.policy
        ? {
            data,
            policy: options.policy.digest,
            consent: options.policy.consent,
          }
        : data,
    ),
  );
  const { db } = database();
  return db.transaction(async (tx) => {
    if (options.policy)
      await tx
        .insert(inquiryPolicies)
        .values({
          digest: options.policy.digest,
          document: options.policy.document,
        })
        .onConflictDoNothing({ target: inquiryPolicies.digest });
    const [created] = await tx
      .insert(inquiries)
      .values({
        source: data.source,
        name: data.name,
        email: data.email,
        phone: data.phone,
        tourSlug: data.tourSlug,
        details: data.details,
        isTest: options.isTest,
        submissionHash: options.submissionHash ?? null,
        policyDigest: options.policy?.digest ?? null,
        consentGiven: options.policy?.consent ?? null,
        consentRecordedAt: options.policy?.consent ? new Date() : null,
        idempotencyKey: key,
        payloadHash,
      })
      .onConflictDoNothing({ target: inquiries.idempotencyKey })
      .returning({ id: inquiries.id, number: inquiries.number });
    if (created) {
      const [savedInquiry] = await tx
        .select()
        .from(inquiries)
        .where(eq(inquiries.id, created.id));
      await enqueueEvent(
        tx,
        "inquiry.created",
        created.id,
        inquiryMessage(savedInquiry, "inquiry.created"),
      );
      if (options.limits) await options.limits(tx);
      if (options.adminId) {
        const bucket = Math.floor(Date.now() / 60000);
        const [limit] = await tx
          .insert(rateLimits)
          .values({
            key: `test-intake:${hashToken(options.adminId)}:${bucket}`,
            count: 1,
            expiresAt: new Date((bucket + 1) * 60000),
          })
          .onConflictDoUpdate({
            target: rateLimits.key,
            set: { count: sql`${rateLimits.count}+1` },
          })
          .returning({ count: rateLimits.count });
        if (limit.count > 20)
          throw new HttpError(
            429,
            "Слишком много новых тестовых заявок. Повторите через минуту.",
            "INTAKE_LIMITED",
          );
      }
      await tx.insert(adminAuditLogs).values({
        adminId: options.adminId ?? null,
        action: options.adminId
          ? "test_inquiry_created"
          : "public_inquiry_created",
        entityId: created.id,
      });
      return {
        ...created,
        displayNumber: inquiryNumber(created.number),
        duplicate: false,
      };
    }
    const [existing] = await tx
      .select({
        id: inquiries.id,
        number: inquiries.number,
        payloadHash: inquiries.payloadHash,
        submissionHash: inquiries.submissionHash,
        isTest: inquiries.isTest,
      })
      .from(inquiries)
      .where(eq(inquiries.idempotencyKey, key!));
    if (
      !existing ||
      existing.payloadHash !== payloadHash ||
      existing.submissionHash !== (options.submissionHash ?? null) ||
      existing.isTest !== options.isTest
    )
      throw new HttpError(
        409,
        "Ключ повтора уже использован для другого содержимого.",
      );
    return {
      id: existing.id,
      number: existing.number,
      displayNumber: inquiryNumber(existing.number),
      duplicate: true,
    };
  });
}
export async function listInquiries(input: unknown = {}) {
  const parsed = searchSchema.safeParse(input);
  if (!parsed.success)
    throw new HttpError(400, "Некорректные параметры поиска.");
  const { query, status, page } = parsed.data;
  const { db } = database();
  const pattern = `%${query.replace(/[\\%_]/g, "\\$&")}%`;
  const where = and(
    status === "all" ? undefined : eq(inquiries.status, status),
    query
      ? or(
          ilike(inquiries.name, pattern),
          ilike(inquiries.email, pattern),
          ilike(inquiries.phone, pattern),
          sql`('ZL-' || lpad(${inquiries.number}::text,greatest(6,length(${inquiries.number}::text)),'0')) ILIKE ${pattern}`,
        )
      : undefined,
  );
  const [totals] = await db
    .select({ count: count() })
    .from(inquiries)
    .where(where);
  const rows = await db
    .select({
      id: inquiries.id,
      number: inquiries.number,
      name: inquiries.name,
      email: inquiries.email,
      source: inquiries.source,
      status: inquiries.status,
      isTest: inquiries.isTest,
      createdAt: inquiries.createdAt,
      updatedAt: inquiries.updatedAt,
    })
    .from(inquiries)
    .where(where)
    .orderBy(desc(inquiries.createdAt), desc(inquiries.number))
    .limit(20)
    .offset((page - 1) * 20);
  return { rows, total: totals.count, page, pageSize: 20 };
}
export async function inquiryDetails(id: string) {
  if (!z.uuid().safeParse(id).success)
    throw new HttpError(404, "Заявка не найдена.");
  const [row] = await database()
    .db.select()
    .from(inquiries)
    .where(eq(inquiries.id, id));
  if (!row) throw new HttpError(404, "Заявка не найдена.");
  const { payloadHash, idempotencyKey, submissionHash, ...safe } = row;
  void submissionHash;
  void payloadHash;
  void idempotencyKey;
  return safe;
}
export async function updateInquiry(
  id: string,
  input: unknown,
  adminId: string,
) {
  if (!z.uuid().safeParse(id).success)
    throw new HttpError(404, "Заявка не найдена.");
  const parsed = updateInquirySchema.safeParse(input);
  if (!parsed.success)
    throw new HttpError(400, "Проверьте статус и длину заметки.");
  const { status, internalNote, expectedUpdatedAt } = parsed.data;
  const { db } = database();
  return db.transaction(async (tx) => {
    const [before] = await tx
      .select({ status: inquiries.status })
      .from(inquiries)
      .where(eq(inquiries.id, id))
      .for("update");
    const [row] = await tx
      .update(inquiries)
      .set({
        status,
        internalNote,
        updatedAt: sql`greatest(date_trunc('milliseconds',clock_timestamp()), ${inquiries.updatedAt} + interval '1 millisecond')`,
      })
      .where(
        and(
          eq(inquiries.id, id),
          eq(inquiries.updatedAt, new Date(expectedUpdatedAt)),
        ),
      )
      .returning();
    if (!row)
      throw new HttpError(
        409,
        "Заявка изменена в другом окне или не найдена. Обновите страницу; текст заметки сохранён в форме.",
      );
    await tx.insert(adminAuditLogs).values({
      adminId,
      action: "inquiry_updated",
      entityId: id,
      metadata: { status },
    });
    if (before?.status !== row.status)
      await enqueueEvent(
        tx,
        "inquiry.status_changed",
        `${row.id}:${row.updatedAt.toISOString()}`,
        inquiryMessage(row, "inquiry.status_changed"),
      );
    return { id: row.id, status: row.status, updatedAt: row.updatedAt };
  });
}
export async function dashboard() {
  const { db } = database();
  const [counts] = await db
    .select({
      total: count(),
      new: sql<number>`count(*) filter (where ${inquiries.status}='new')`.mapWith(
        Number,
      ),
      inProgress:
        sql<number>`count(*) filter (where ${inquiries.status}='in_progress')`.mapWith(
          Number,
        ),
      test: sql<number>`count(*) filter (where ${inquiries.isTest})`.mapWith(
        Number,
      ),
    })
    .from(inquiries);
  const recent = await db
    .select({
      id: inquiries.id,
      number: inquiries.number,
      name: inquiries.name,
      status: inquiries.status,
      isTest: inquiries.isTest,
      createdAt: inquiries.createdAt,
    })
    .from(inquiries)
    .orderBy(desc(inquiries.createdAt))
    .limit(5);
  return { counts, recent };
}
