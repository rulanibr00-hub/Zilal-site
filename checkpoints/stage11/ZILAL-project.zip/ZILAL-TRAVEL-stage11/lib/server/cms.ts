import "server-only";
import { and, eq, desc } from "drizzle-orm";
import { cmsDocuments as docs,cmsVersions as versions,adminAuditLogs } from "../db/schema";
import { database } from "./db";
import { HttpError } from "./http";
import { commandSchema,parseContent,pageSchema } from "../cms/contracts";
import { contentSeeds } from "../cms/seeds";
import { pageDefaults } from "../cms/page-defaults";
export async function contentState(key?:string){
 const {db}=database();const rows=await db.select().from(docs).where(key?eq(docs.key,key):undefined).orderBy(docs.key);
 if(key){const row=rows[0];const history=row?await db.select({version:versions.version,payload:versions.payload,createdAt:versions.createdAt}).from(versions).where(eq(versions.documentKey,key)).orderBy(desc(versions.version)):[];return {document:row??null,history,seed:contentSeeds[key]??null};}
 const present=new Set(rows.map(r=>r.key));return {documents:[...rows,...Object.keys(contentSeeds).filter(k=>!present.has(k)).map(key=>({key,kind:key.split(':')[0],draftVersion:0,publishedVersion:0,updatedAt:null}))]};
}
export async function contentCommand(input:unknown,adminId:string){
 const cmd=commandSchema.safeParse(input);if(!cmd.success)throw new HttpError(400,"Проверьте команду редактора.");const c=cmd.data;const kind=c.key.split(':')[0];
 if(c.action!=='save'&&!c.confirmed)throw new HttpError(400,"Подтвердите действие явно.");
 let data:Record<string,unknown>|undefined;
 if(c.action==='save'){
  try{data=parseContent(kind,c.payload) as Record<string,unknown>;}catch{throw new HttpError(400,"Проверьте обязательные поля, длину текста и программу тура.");}
  if(kind==='tour'&&data.slug!==c.key.slice(5))throw new HttpError(400,"Адрес тура нельзя менять после создания.");
  if(kind==='page'){const p=pageSchema.parse(data);const allowed=pageDefaults[c.key.slice(5) as keyof typeof pageDefaults];if(Object.keys(p.blocks).some(k=>!(k in allowed)))throw new HttpError(400,"Неизвестный текстовый блок.");}
 }
 return database().db.transaction(async tx=>{
  await tx.insert(docs).values({key:c.key,kind}).onConflictDoNothing();
  let [row]=await tx.select().from(docs).where(eq(docs.key,c.key)).for('update');
  if(row.draftVersion!==c.expectedVersion)throw new HttpError(409,"Документ изменён. Обновите список перед сохранением.");
  // Existing built-in materials become version 1 without disappearing when their draft is edited.
  if(row.draftVersion===0&&contentSeeds[c.key]){await tx.insert(versions).values({documentKey:c.key,version:1,payload:contentSeeds[c.key],adminId});row={...row,draftVersion:1,publishedVersion:1};await tx.update(docs).set({draftVersion:1,publishedVersion:1}).where(eq(docs.key,c.key));}
  if(c.action==='restore'){
   const [old]=await tx.select().from(versions).where(and(eq(versions.documentKey,c.key),eq(versions.version,c.version??-1)));if(!old)throw new HttpError(404,"Версия не найдена.");data=old.payload;
  }
  if(c.action==='save'||c.action==='restore'){
   const ids=(data?.mediaIds??[]) as string[];
   const version=row.draftVersion+1;
   await tx.insert(versions).values({documentKey:c.key,version,payload:data!,adminId});
   for(const id of ids){const result=await tx.execute((await import('drizzle-orm')).sql`SELECT id FROM cms_media WHERE id=${id} FOR KEY SHARE`);if(!result.rows.length)throw new HttpError(400,"Изображение не найдено в медиатеке.");await tx.execute((await import('drizzle-orm')).sql`INSERT INTO cms_media_refs(document_key,version,media_id) VALUES(${c.key},${version},${id})`);}
   await tx.update(docs).set({draftVersion:version,updatedAt:new Date()}).where(eq(docs.key,c.key));
  }else if(c.action==='publish'){
   if(!row.draftVersion)throw new HttpError(400,"Сначала сохраните черновик.");
   await tx.update(docs).set({publishedVersion:row.draftVersion,updatedAt:new Date()}).where(eq(docs.key,c.key));
  }else await tx.update(docs).set({publishedVersion:null,updatedAt:new Date()}).where(eq(docs.key,c.key));
  await tx.insert(adminAuditLogs).values({adminId,action:'content_'+c.action,entityId:c.key,metadata:{version:String(c.action==='save'||c.action==='restore'?row.draftVersion+1:row.draftVersion)}});
  return {saved:true};
 });
}
export async function draftContent(key:string){const s=await contentState(key) as {document:{draftVersion:number}|null;history:{version:number;payload:Record<string,unknown>}[];seed:Record<string,unknown>|null};return s.history.find(v=>v.version===s.document?.draftVersion)?.payload??s.seed;}
