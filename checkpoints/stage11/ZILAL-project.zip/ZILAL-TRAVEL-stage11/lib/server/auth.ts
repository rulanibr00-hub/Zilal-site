import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq, gt, isNull, sql, lt } from "drizzle-orm";
import {
  adminUsers,
  adminSessions,
  adminAuditLogs,
  rateLimits,
} from "@/lib/db/schema";
import {
  csrfFor,
  equalToken,
  hashPassword,
  hashToken,
  originConfig,
  randomToken,
  sessionSeconds,
  verifyPassword,
} from "@/lib/admin/security";
import { loginSchema } from "@/lib/admin/contracts";
import { database } from "./db";
import { HttpError, assertOrigin } from "./http";
export async function currentAdmin() {
  const jar = await cookies();
  let name: string;
  try {
    name = originConfig().cookieName;
  } catch {
    return null;
  }
  const token = jar.get(name)?.value;
  if (!token || !/^([a-f0-9]{64})$/.test(token)) return null;
  try {
    const [record] = await database()
      .db.select({
        sessionId: adminSessions.id,
        adminId: adminUsers.id,
        login: adminUsers.login,
        expiresAt: adminSessions.expiresAt,
      })
      .from(adminSessions)
      .innerJoin(adminUsers, eq(adminSessions.adminId, adminUsers.id))
      .where(
        and(
          eq(adminSessions.tokenHash, hashToken(token)),
          isNull(adminSessions.revokedAt),
          gt(adminSessions.expiresAt, new Date()),
        ),
      )
      .limit(1);
    return record ? { ...record, csrf: csrfFor(token) } : null;
  } catch {
    throw new HttpError(503, "Хранилище временно недоступно.");
  }
}
export async function requireAdminPage() {
  const auth = await currentAdmin();
  if (!auth) redirect("/admin/login");
  return auth;
}
export async function requireAdminApi(request?: Request) {
  const auth = await currentAdmin();
  if (!auth) throw new HttpError(401, "Необходимо войти.", "UNAUTHENTICATED");
  if (request) {
    assertOrigin(request);
    if (!equalToken(request.headers.get("x-csrf-token") ?? "", auth.csrf))
      throw new HttpError(
        403,
        "Проверка безопасности не пройдена. Обновите страницу.",
        "CSRF_REJECTED",
      );
  }
  return auth;
}
async function attemptLimit(login: string) {
  const { db } = database();
  const window = 15 * 60 * 1000;
  const bucket = Math.floor(Date.now() / window);
  const expires = new Date((bucket + 1) * window);
  const denied = await db.transaction(async (tx) => {
    await tx.delete(rateLimits).where(lt(rateLimits.expiresAt, new Date()));
    let over = false;
    for (const [subject, limit] of [
      ["all", 30],
      [hashToken(login), 5],
    ] as const) {
      const key = `login:${subject}:${bucket}`;
      const [row] = await tx
        .insert(rateLimits)
        .values({ key, count: 1, expiresAt: expires })
        .onConflictDoUpdate({
          target: rateLimits.key,
          set: { count: sql`${rateLimits.count}+1` },
        })
        .returning({ count: rateLimits.count });
      if (row.count > limit) over = true;
    }
    return over;
  });
  if (denied)
    throw new HttpError(
      429,
      "Слишком много попыток. Повторите через 15 минут.",
      "RATE_LIMITED",
    );
}
let dummy: Promise<string> | undefined;
let activeVerifications = 0;
export async function loginAdmin(input: unknown) {
  const parsed = loginSchema.safeParse(input);
  if (!parsed.success) throw new HttpError(400, "Проверьте логин и пароль.");
  const { login, password } = parsed.data;
  await attemptLimit(login);
  const { db } = database();
  const [user] = await db
    .select()
    .from(adminUsers)
    .where(eq(adminUsers.login, login))
    .limit(1);
  if (activeVerifications >= 2)
    throw new HttpError(
      429,
      "Сервер занят проверкой входа. Повторите через несколько секунд.",
    );
  activeVerifications++;
  let valid = false;
  try {
    const hash =
      user?.passwordHash ?? (await (dummy ??= hashPassword(randomToken())));
    valid = await verifyPassword(hash, password);
  } finally {
    activeVerifications--;
  }
  if (!user || !valid) {
    await db.insert(adminAuditLogs).values({ action: "login_failed" });
    throw new HttpError(
      401,
      "Неверный логин или пароль.",
      "INVALID_CREDENTIALS",
    );
  }
  const token = randomToken();
  const expiresAt = new Date(Date.now() + sessionSeconds * 1000);
  const now = new Date();
  await db.transaction(async (tx) => {
    const [fresh] = await tx
      .select({ passwordHash: adminUsers.passwordHash })
      .from(adminUsers)
      .where(eq(adminUsers.id, user.id))
      .for("update");
    if (!fresh || fresh.passwordHash !== user.passwordHash)
      throw new HttpError(401, "Учётные данные изменены. Повторите вход.");
    await tx.delete(adminSessions).where(eq(adminSessions.adminId, user.id));
    await tx
      .insert(adminSessions)
      .values({ adminId: user.id, tokenHash: hashToken(token), expiresAt });
    await tx
      .update(adminUsers)
      .set({ lastLoginAt: now })
      .where(eq(adminUsers.id, user.id));
    await tx
      .insert(adminAuditLogs)
      .values({ action: "login_succeeded", adminId: user.id });
  });
  return { token, expiresAt, csrf: csrfFor(token) };
}
export function cookieOptions() {
  const config = originConfig();
  return {
    httpOnly: true,
    secure: config.secure,
    sameSite: "strict" as const,
    path: "/",
    maxAge: sessionSeconds,
    priority: "high" as const,
  };
}
export async function logoutAdmin(
  auth: Awaited<ReturnType<typeof requireAdminApi>>,
) {
  const { db } = database();
  await db.transaction(async (tx) => {
    await tx
      .update(adminSessions)
      .set({ revokedAt: new Date() })
      .where(
        and(
          eq(adminSessions.id, auth.sessionId),
          eq(adminSessions.adminId, auth.adminId),
        ),
      );
    await tx
      .insert(adminAuditLogs)
      .values({ action: "logout", adminId: auth.adminId });
  });
}
