import type { Activity, DestinationId, Tour, TravelStyle } from "./types";

export const tripSteps = [
  "Настроение",
  "Места",
  "Впечатления",
  "Даты и гости",
  "Проживание",
  "Ваше путешествие",
] as const;
export const tripActivities = [
  {
    id: "horse-riding",
    title: "Верховая езда",
    description: "Посмотреть на джайлоо с другого ракурса.",
  },
  {
    id: "trekking",
    title: "Треккинг",
    description: "Выбрать свою тропу среди гор.",
  },
  {
    id: "jeep",
    title: "Джип-туры",
    description: "Панорамные дороги и новые горизонты.",
  },
  {
    id: "culture",
    title: "Культура",
    description: "Истории, ремёсла и встречи с людьми.",
  },
  {
    id: "gastronomy",
    title: "Гастрономия",
    description: "Узнавать страну через её вкусы.",
  },
  {
    id: "relaxation",
    title: "Отдых",
    description: "Оставить время для озера и тишины.",
  },
] as const;
export type TripActivity = (typeof tripActivities)[number]["id"];
export const accommodationOptions = [
  {
    id: "comfort",
    title: "Камерный комфорт",
    description: "Небольшие отели и гостевые дома с уютной атмосферой.",
  },
  {
    id: "premium",
    title: "Премиальные отели",
    description:
      "Предпочтение повышенному уровню комфорта там, где он доступен.",
  },
  {
    id: "nature",
    title: "Ближе к природе",
    description: "Юрты и простые гостевые дома как часть впечатления.",
  },
  {
    id: "mixed",
    title: "Смешанный формат",
    description: "Больше комфорта в городе, больше природы в горах.",
  },
  {
    id: "advice",
    title: "Помогите выбрать",
    description: "Определимся с проживанием после обсуждения маршрута.",
  },
] as const;
export type Accommodation = (typeof accommodationOptions)[number]["id"];
export type TripSeed = Pick<
  Tour,
  "slug" | "title" | "style" | "destinationIds" | "activities" | "durationDays"
>;
export interface TripDraft {
  style: TravelStyle | "";
  destinationIds: DestinationId[];
  activities: TripActivity[];
  duration: string;
  flexibleDates: boolean;
  startDate: string;
  adults: string;
  children: string;
  accommodation: Accommodation | "";
  wishes: string;
  name: string;
  email: string;
  phone: string;
  contactMethod: "phone" | "whatsapp";
}
export type TripField = keyof TripDraft;
export type TripErrors = Partial<Record<TripField, string>>;
export interface ValidationContext {
  today: string;
  destinationIds: readonly string[];
}

export function createTripDraft(seed?: TripSeed): TripDraft {
  // Only transfer exact activity matches. Scenic drives are not automatically jeep tours.
  const matches: Partial<Record<Activity, TripActivity>> = {
    culture: "culture",
    trekking: "trekking",
  };
  return {
    style: seed?.style ?? "",
    destinationIds: seed ? [...seed.destinationIds] : [],
    activities: seed
      ? [
          ...new Set(
            seed.activities.flatMap((a) => (matches[a] ? [matches[a]!] : [])),
          ),
        ]
      : [],
    duration: seed?.durationDays ? String(seed.durationDays) : "",
    flexibleDates: true,
    startDate: "",
    adults: "2",
    children: "0",
    accommodation: "",
    wishes: "",
    name: "",
    email: "",
    phone: "",
    contactMethod: "whatsapp",
  };
}
function integerInRange(value: string, min: number, max: number): boolean {
  return /^\d+$/.test(value) && Number(value) >= min && Number(value) <= max;
}
export function isCalendarDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return (
    Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value
  );
}
export function validateTripStep(
  draft: TripDraft,
  step: number,
  context: ValidationContext,
): TripErrors {
  const errors: TripErrors = {};
  if (step === 0 && !["comfort", "adventure", "combined"].includes(draft.style))
    errors.style = "Выберите стиль путешествия.";
  if (
    step === 1 &&
    (!draft.destinationIds.length ||
      draft.destinationIds.some((id) => !context.destinationIds.includes(id)))
  )
    errors.destinationIds = "Выберите хотя бы одно направление из списка.";
  if (
    step === 2 &&
    (!draft.activities.length ||
      draft.activities.some((id) => !tripActivities.some((a) => a.id === id)))
  )
    errors.activities = "Выберите хотя бы одну активность.";
  if (step === 3) {
    if (!integerInRange(draft.duration, 1, 60))
      errors.duration = "Укажите продолжительность от 1 до 60 полных дней.";
    if (!integerInRange(draft.adults, 1, 20))
      errors.adults = "Укажите от 1 до 20 взрослых.";
    if (!integerInRange(draft.children, 0, 20))
      errors.children = "Укажите от 0 до 20 детей.";
    if (!draft.flexibleDates && !isCalendarDate(draft.startDate))
      errors.startDate =
        "Выберите примерную дату начала или отметьте гибкие даты.";
    else if (!draft.flexibleDates && draft.startDate < context.today)
      errors.startDate = "Дата начала не может быть в прошлом.";
  }
  if (step === 4) {
    if (!accommodationOptions.some((item) => item.id === draft.accommodation))
      errors.accommodation =
        "Выберите предпочтение по проживанию — можно выбрать «Помогите выбрать».";
    if (draft.wishes.length > 2000)
      errors.wishes = "Сократите пожелания до 2000 символов.";
  }
  if (step === 5) {
    if (!draft.name.trim() || draft.name.trim().length > 100)
      errors.name = "Укажите имя (до 100 символов).";
    if (
      draft.email.length > 254 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(draft.email.trim())
    )
      errors.email = "Укажите корректный email, например name@example.com.";
    const digits = draft.phone.replace(/\D/g, "");
    if (
      !/^\+[1-9][\d\s().-]*$/.test(draft.phone.trim()) ||
      digits.length < 7 ||
      digits.length > 15
    )
      errors.phone = "Укажите номер с + и кодом страны, от 7 до 15 цифр.";
  }
  return errors;
}
export function firstInvalidStep(
  draft: TripDraft,
  context: ValidationContext,
  through = 5,
): { step: number; errors: TripErrors } | undefined {
  for (let step = 0; step <= through; step++) {
    const errors = validateTripStep(draft, step, context);
    if (Object.keys(errors).length) return { step, errors };
  }
}
export function getBishkekToday(now = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Bishkek",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  return ["year", "month", "day"]
    .map((type) => parts.find((p) => p.type === type)!.value)
    .join("-");
}
export function estimatedEndDate(
  start: string,
  duration: string,
): string | undefined {
  if (!isCalendarDate(start) || !integerInRange(duration, 1, 60)) return;
  const date = new Date(`${start}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + Number(duration) - 1);
  return date.toISOString().slice(0, 10);
}
export function formatTripDate(date: string): string {
  if (!isCalendarDate(date)) return "Не определена";
  return new Intl.DateTimeFormat("ru-RU", {
    timeZone: "UTC",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${date}T00:00:00Z`));
}
