import type { MediaAsset, PhotoKey } from "./types";
export const photos: Record<PhotoKey, MediaAsset> = {
  hero: {
    kind: "illustration",
    label: "Панорама Тянь-Шаня",
    alt: "Оригинальная иллюстрация: многослойная горная панорама, снежные вершины и свет в долине",
  },
  mountain: {
    kind: "illustration",
    label: "Горы Кыргызстана",
    alt: "Оригинальная иллюстрация: снежные пики над хвойным лесом и горной долиной",
  },
  lake: {
    kind: "illustration",
    label: "Иссык-Куль",
    alt: "Оригинальная иллюстрация: спокойное голубое озеро, горный горизонт и песчаный берег",
  },
  pasture: {
    kind: "illustration",
    label: "Сон-Куль и джайлоо",
    alt: "Оригинальная иллюстрация: высокогорное озеро, мягкие линии пастбищ и маленькие юрты",
  },
  canyon: {
    kind: "illustration",
    label: "Каньон Сказка",
    alt: "Оригинальная иллюстрация: терракотовые скальные формы и светлые тропы каньона",
  },
  alakul: {
    kind: "illustration",
    label: "Ала-Куль",
    alt: "Оригинальная иллюстрация: бирюзовое озеро в каменистой высокогорной котловине",
  },
  karakol: {
    kind: "illustration",
    label: "Каракол",
    alt: "Оригинальная иллюстрация: деревянные дома среди деревьев на фоне гор; не изображение конкретного здания",
  },
  culture: {
    kind: "illustration",
    label: "Культура гостеприимства",
    alt: "Оригинальная иллюстрация: юрта с орнаментом на открытом пастбище и горы вдали",
  },
};
export const photoSizes = {
  hero: "100vw",
  editorial:
    "(max-width: 760px) calc(100vw - 40px), (max-width: 1360px) 50vw, 640px",
  card: "(max-width: 760px) calc(100vw - 40px), (max-width: 1100px) 46vw, (max-width: 1360px) 30vw, 410px",
  destination: "(max-width: 760px) 44vw, (max-width: 1100px) 28vw, 230px",
  gallery:
    "(max-width: 760px) calc(100vw - 40px), (max-width: 1360px) 65vw, 880px",
  thumbnail: "(max-width: 760px) 22vw, 180px",
  choice: "(max-width: 760px) 45vw, (max-width: 1100px) 30vw, 270px",
} as const;
export type PhotoSlot = keyof typeof photoSizes;
// Completeness check only. Rights and source must be verified by a human before adding a photograph.
export function isDocumentedPhoto(
  asset: MediaAsset,
): asset is Extract<MediaAsset, { kind: "photo" }> {
  if (asset.kind !== "photo") return false;
  if (
    [
      asset.src,
      asset.alt,
      asset.label,
      asset.author,
      asset.license,
      asset.sourceUrl,
      asset.licenseUrl,
      asset.verifiedOn,
    ].some((value) => typeof value !== "string" || !value.trim())
  )
    return false;
  const sourceReference = (value: string) =>
    /^https:\/\/[^\s]+$/.test(value) ||
    (/^\/images\/credits\/[a-zA-Z0-9._/-]+$/.test(value) &&
      !value.includes(".."));
  const focusValid = (point: { x: number; y: number } | undefined) =>
    !point ||
    (Number.isFinite(point.x) &&
      Number.isFinite(point.y) &&
      point.x >= 0 &&
      point.x <= 100 &&
      point.y >= 0 &&
      point.y <= 100);
  const date = new Date(`${asset.verifiedOn}T00:00:00Z`);
  return (
    /^\/images\/[a-zA-Z0-9/_-]+\.(?:jpe?g|png|webp|avif)$/i.test(asset.src) &&
    asset.alt.trim().length > 0 &&
    asset.label.trim().length > 0 &&
    Number.isInteger(asset.width) &&
    asset.width > 0 &&
    Number.isInteger(asset.height) &&
    asset.height > 0 &&
    asset.author.trim().length > 0 &&
    asset.license.trim().length > 0 &&
    sourceReference(asset.sourceUrl) &&
    sourceReference(asset.licenseUrl) &&
    /^\d{4}-\d{2}-\d{2}$/.test(asset.verifiedOn) &&
    Number.isFinite(date.getTime()) &&
    date.toISOString().slice(0, 10) === asset.verifiedOn &&
    focusValid(asset.focalPoint) &&
    focusValid(asset.mobileFocalPoint)
  );
}
