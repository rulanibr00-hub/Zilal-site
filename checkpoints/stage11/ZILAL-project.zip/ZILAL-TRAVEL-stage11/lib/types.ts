export type Locale = "ru"; // Extend together with dictionaries when English is introduced.
export type LocalizedText = Record<Locale, string>;
export type PhotoKey =
  | "hero"
  | "mountain"
  | "lake"
  | "pasture"
  | "canyon"
  | "alakul"
  | "karakol"
  | "culture";
export type DestinationId =
  "issyk-kul" | "son-kul" | "skazka" | "karakol" | "ala-kul";

export interface Destination {
  id: DestinationId;
  name: LocalizedText;
  caption: LocalizedText;
  category: LocalizedText;
  description: LocalizedText;
  planningNote: LocalizedText;
  image: PhotoKey;
}

// Editorial concepts are separate from purchasable tours.
export interface TourConcept {
  id: "comfort" | "adventure";
  title: LocalizedText;
  eyebrow: LocalizedText;
  description: LocalizedText;
  image: PhotoKey;
}

export type TravelStyle = "comfort" | "adventure" | "combined";
export type Activity = "panoramas" | "culture" | "walks" | "trekking";
export type Difficulty = "easy" | "moderate" | "challenging";

export interface Tour {
  media?: import("./cms/contracts").MediaInfo[];
  id: string;
  slug: string;
  status: "example" | "draft" | "published";
  title: LocalizedText;
  description: LocalizedText;
  destinationIds: DestinationId[];
  image: PhotoKey;
  gallery: PhotoKey[];
  style: TravelStyle;
  activities: Activity[];
  durationDays: number | null;
  difficulty: Difficulty | null;
  difficultyNote: LocalizedText;
  highlights: LocalizedText[];
  itinerary: {
    day: number;
    title: LocalizedText;
    description: LocalizedText;
  }[];
  services: {
    proposed: LocalizedText[];
    notIncluded: LocalizedText[];
    toConfirm: LocalizedText[];
  };
}

export type MediaAsset =
  | { kind: "illustration"; label: string; alt: string }
  | {
      kind: "photo";
      label: string;
      src: `/images/${string}`;
      alt: string;
      width: number;
      height: number;
      focalPoint?: { x: number; y: number };
      mobileFocalPoint?: { x: number; y: number };
      verifiedOn: string;
      author: string;
      sourceUrl: string;
      license: string;
      licenseUrl: string;
    };
