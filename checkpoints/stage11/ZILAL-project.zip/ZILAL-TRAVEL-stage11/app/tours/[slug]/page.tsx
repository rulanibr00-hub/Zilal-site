import TourDetail from "@/components/tours/TourDetail";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import TourGallery from "@/components/tours/TourGallery";
import { ButtonLink } from "@/components/ui/Button";
import { publicTour } from "@/lib/server/cms-public";
import { destinations } from "@/lib/data/destinations";
import {
  activityLabels,
  daysLabel,
  difficultyLabels,
  travelStyles,
} from "@/lib/tour-catalog";
export const dynamicParams = true;


export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const tour = await publicTour((await params).slug);
  if (!tour) return { title: "Маршрут не найден — ZILAL TRAVEL" };
  return {
    title: `${tour.title.ru} — ${tour.status === "example" ? "пример маршрута · " : ""}ZILAL TRAVEL`,
    description: tour.description.ru,
  };
}
export default async function TourPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const tour = await publicTour((await params).slug);
  if (!tour) notFound();
  return <TourDetail tour={tour}/>;
}
