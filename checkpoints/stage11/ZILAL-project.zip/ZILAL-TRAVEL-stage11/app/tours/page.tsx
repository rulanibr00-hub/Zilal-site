import type { Metadata } from "next";
import PageIntro from "@/components/PageIntro";
import TourCatalog from "@/components/tours/TourCatalog";
import { ButtonLink } from "@/components/ui/Button";
import { publicTours } from "@/lib/server/cms-public";
import { travelStyles } from "@/lib/tour-catalog";
export const metadata: Metadata = {
  title: "Каталог путешествий — ZILAL TRAVEL",
  description:
    "Signature Comfort, Wild Adventures и комбинированный формат: примеры путешествий по Кыргызстану с фильтрами по длительности и активности.",
};
export default async function ToursPage() {
  const catalogTours = await publicTours();
  return (
    <>
      <PageIntro
        eyebrow="Туры"
        title="Коллекция путешествий."
        accent="Ваш характер свободы."
        description="Тишина озера, простор джайлоо или тропа к перевалу. Выберите свой ритм Кыргызстана — от Signature Comfort до Wild Adventures."
        image="alakul"
      />
      <section className="travel-formats wrap" aria-label="Форматы путешествий">
        {Object.entries(travelStyles).map(([style, format], index) => (
          <a className="travel-format" href={`#${style}`} key={style}>
            <span className="benefit-number">0{index + 1} —</span>
            <h2>{format.title}</h2>
            <p>{format.description}</p>
            <span className="text-link">Посмотреть примеры →</span>
          </a>
        ))}
      </section>
      <TourCatalog tours={catalogTours} />
      <section className="catalog-tailor">
        <div className="wrap">
          <p className="eyebrow">
            Ни один маршрут не обязан быть окончательным
          </p>
          <h2>
            Добавьте больше <em>своего.</em>
          </h2>
          <p>
            Соедините спокойные дни и активные выходы. Любой пример — только
            начало разговора о будущем путешествии.
          </p>
          <ButtonLink href="/create-trip">Настроить путешествие</ButtonLink>
        </div>
      </section>
    </>
  );
}
