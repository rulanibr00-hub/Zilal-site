import type { Metadata } from "next";
import PageIntro from "@/components/PageIntro";
import TripBuilder from "@/components/trip-builder/TripBuilder";
import { publicTour } from "@/lib/server/cms-public";
import { destinations } from "@/lib/data/destinations";
import { getBishkekToday, type TripSeed } from "@/lib/trip-builder";
export const metadata: Metadata = {
  title: "Создать путешествие — ZILAL TRAVEL",
  description:
    "Соберите персональную идею путешествия по Кыргызстану: стиль, места, активности, даты и проживание. Пошаговый конструктор с указанием текущего режима приёма обращений.",
};
export default async function CreateTripPage({
  searchParams,
}: {
  searchParams: Promise<{ tour?: string | string[] }>;
}) {
  const requestedTour = (await searchParams).tour;
  const tour =
    typeof requestedTour === "string"
      ? await publicTour(requestedTour)
      : undefined;
  const selectedTour: TripSeed | undefined = tour
    ? {
        slug: tour.slug,
        title: tour.title,
        style: tour.style,
        destinationIds: tour.destinationIds,
        activities: tour.activities,
        durationDays: tour.durationDays,
      }
    : undefined;
  return (
    <>
      <PageIntro
        eyebrow="Создать путешествие"
        title="Не просто маршрут."
        accent="Ваша история."
        description="От первого ощущения до личных деталей. Несколько шагов, чтобы собрать Кыргызстан, который хочется почувствовать именно вам."
        image="pasture"
      />
      {requestedTour && !tour && (
        <p className="wrap unknown-tour" role="status">
          Этот маршрут не найден. Начните своё путешествие с чистого листа в
          конструкторе ниже.
        </p>
      )}
      <TripBuilder
        key={selectedTour?.slug ?? "custom-trip"}
        destinations={destinations}
        selectedTour={selectedTour}
        today={getBishkekToday()}
      />
    </>
  );
}
