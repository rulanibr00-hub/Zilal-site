import { OwnerPlaceholder, CmsText } from "@/components/cms/ContentProvider";
import type { Metadata } from "next";
import PageIntro from "@/components/PageIntro";
import Principles from "@/components/sections/Principles";
import InfoCard from "@/components/ui/InfoCard";
import EditorialFeature from "@/components/editorial/EditorialFeature";
import { ButtonLink } from "@/components/ui/Button";
import { companyIdentity, ownerContent } from "@/lib/data/brand";
const title = "О нас — семейная компания ZILAL TRAVEL";
const description =
  "ZILAL TRAVEL — семейная туристическая компания для иностранных гостей Кыргызстана. Философия Luxury + Adventure: внимание к деталям, свобода открытий и уважение к месту.";
export const metadata: Metadata = {
  title,
  description,
  openGraph: { title, description, locale: "ru_RU", type: "website" },
};
export default function AboutPage() {
  return (
    <div className="brand-editorial">
      <PageIntro
        eyebrow={<CmsText page="about" slot="text-d869ed9d8e3a" fallback="О нас" />}
        title={<CmsText page="about" slot="text-88e118f69986" fallback="Семейный подход." />}
        accent={<CmsText page="about" slot="text-2f8f0c78b324" fallback="Личный характер путешествий." />}
        description={<CmsText page="about" slot="company-intro" fallback={`${companyIdentity.name} — ${companyIdentity.description.charAt(0).toLowerCase()}${companyIdentity.description.slice(1)} Пространство для знакомства со страной, её природой и людьми.`}/>}
        cmsPage="about"
        image="pasture"
      />
      <section className="intro wrap">
        <div>
          <p className="eyebrow"><CmsText page="about" slot="text-706b6b97cbc0" fallback="Гости, а не просто путешественники" /></p>
          <h2><CmsText page="about" slot="text-906357d1552b" fallback="Знакомство со страной" /><br />
            <em><CmsText page="about" slot="text-6b9b4565764c" fallback="начинается с отношения." /></em>
          </h2>
        </div>
        <div className="intro-copy">
          <p><CmsText page="about" slot="text-cb18cb604aa9" fallback="В основе ZILAL TRAVEL — семейный взгляд на гостеприимство. Нам близка идея путешествия, в котором есть место вниманию, тёплому диалогу и собственному ритму гостя." /></p>
          <p><CmsText page="about" slot="text-7d087f5fcabe" fallback="Мы ориентируемся на иностранных путешественников, которые хотят познакомиться с Кыргызстаном через природу, культуру и повседневную жизнь." /></p>
          <p className="muted"><CmsText page="about" slot="text-dbe1351636db" fallback="Ниже — философия бренда. Конкретные программы и условия поездок требуют отдельного согласования." /></p>
        </div>
      </section>
      <EditorialFeature
        eyebrow={<CmsText page="about" slot="text-8a2c37ac76e5" fallback="Luxury + Adventure" />}
        title={<CmsText page="about" slot="text-fc3c806cf142" fallback="Свобода впечатлений." />}
        accent={<CmsText page="about" slot="text-4d8bbc165ca6" fallback="Внимание к деталям." />}
        image="mountain"
        caption={<CmsText page="about" slot="text-d009891e36d5" fallback="Оригинальная иллюстрация · простор Тянь-Шаня" />}
      >
        <p><CmsText page="about" slot="text-54a7e09fac17" fallback="Для нас Luxury — это ощущение продуманности: время без спешки, внимание к личным интересам и возможность замечать детали." /></p>
        <p><CmsText page="about" slot="text-5fe258c39151" fallback="Adventure — любопытство и готовность к открытиям. Иногда это горная тропа, иногда — новый вкус, разговор или поворот панорамной дороги." /></p>
        <p><CmsText page="about" slot="text-5e2bb275bfba" fallback="Эти два настроения можно сочетать. Баланс комфорта и активности выбирается под человека, сезон и особенности маршрута." /></p>
        <ButtonLink href="/create-trip"><CmsText page="about" slot="text-ed2cace4dc30" fallback="Создать своё путешествие" /></ButtonLink>
      </EditorialFeature>
      <div className="brand-principles-heading wrap">
        <p className="eyebrow"><CmsText page="about" slot="text-36a691e9a4cc" fallback="Наши ориентиры" /></p>
        <h2><CmsText page="about" slot="text-0cdb34833b5c" fallback="Ближе к месту." /><br />
          <em><CmsText page="about" slot="text-71fffd2c3ce4" fallback="Внимательнее к человеку." /></em>
        </h2>
      </div>
      <Principles page="about"/>
      <section className="section owner-section" id="owner-details">
        <div className="wrap">
          <div className="section-heading">
            <div>
              <p className="eyebrow"><CmsText page="about" slot="text-bd71e51315a1" fallback="Личная история заслуживает точности" /></p>
              <h2><CmsText page="about" slot="text-99bddcc97792" fallback="За брендом —" />{" "}<em><CmsText page="about" slot="text-f9cbb476608e" fallback="семья." /></em>
              </h2>
            </div>
            <p className="section-aside"><CmsText page="about" slot="text-46504530433b" fallback="Эти блоки заполнит владелец." /><br /><CmsText page="about" slot="text-6f8af90f1fb3" fallback="Неподтверждённые сведения не публикуются." /></p>
          </div>
          <div className="info-grid two-columns owner-content-grid">
            {ownerContent.map((item, index) => (
              <InfoCard
                key={item.id}
                number={`0${index + 1}`}
                title={<CmsText page="about" slot={`owner-${item.id}-title`} fallback={item.title}/>}
                headingLevel={3}
              >
                <OwnerPlaceholder slot={`owner-${item.id}-request`} fallback={item.request}/>
                <p><CmsText page="about" slot={`owner-${item.id}-request`} fallback={item.request}/></p>
              </InfoCard>
            ))}
          </div>
        </div>
      </section>
      <section className="section wrap brand-next">
        <div>
          <p className="eyebrow"><CmsText page="about" slot="text-51e48edb43a0" fallback="От знакомства к вашей истории" /></p>
          <h2><CmsText page="about" slot="text-bf8ffd79df9d" fallback="Начните с того," /><br />
            <em><CmsText page="about" slot="text-4b7eba2e6ee3" fallback="что вам близко." /></em>
          </h2>
        </div>
        <div className="brand-actions">
          <ButtonLink href="/tours"><CmsText page="about" slot="text-0aab442f8224" fallback="Примеры путешествий" /></ButtonLink>
          <ButtonLink href="/contacts" variant="gold"><CmsText page="about" slot="text-7a2668d70e85" fallback="Контакты компании" /></ButtonLink>
        </div>
      </section>
    </div>
  );
}
