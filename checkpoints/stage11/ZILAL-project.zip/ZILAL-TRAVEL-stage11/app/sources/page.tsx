import { publicContent } from "@/lib/server/cms-public";
import Link from "next/link";
import { isDocumentedPhoto, photos } from "@/lib/media";
export const metadata = {
  title: "Источники изображений — ZILAL TRAVEL",
  description:
    "Авторство временных иллюстраций и сведения об источниках, авторах и лицензиях фотографий ZILAL TRAVEL.",
};
export default async function Sources() {
  const {media} = await publicContent();
  const hasPhotos = Object.values(photos).some(isDocumentedPhoto);
  return (
    <div className="document">
      <Link href="/">← На главную</Link>
      <h1>Источники изображений</h1>
      {Object.keys(media).length>0&&<section><h2>Изображения из опубликованных материалов</h2><ul className="source-list">{Object.values(media).map(m=><li key={m.id}><h3>{m.title}</h3><p>Автор: {m.author}. Источник: {m.source}.</p><p>Условия: {m.rights}</p></li>)}</ul></section>}
      <p>
        {hasPhotos
          ? "Ниже приведены сведения об авторах и источниках подключённых изображений."
          : "Сейчас используются восемь оригинальных векторных иллюстраций, созданных для этого проекта. Это визуальные образы, а не фотографии конкретных мест или людей."}
      </p>
      <p>
        Временные пейзажи показывают разные настроения Кыргызстана: горы, озёра,
        пастбища, каньоны и культурный ландшафт. Сторонние снимки с
        непроверенными правами не подключены.
      </p>
      <ul className="source-list">
        {Object.entries(photos).map(([key, asset]) => (
          <li key={key}>
            <h2>{asset.label}</h2>
            {isDocumentedPhoto(asset) ? (
              <>
                <p>
                  Автор: {asset.author}. Лицензия:{" "}
                  <a href={asset.licenseUrl} rel="noreferrer">
                    {asset.license}
                  </a>
                  .
                </p>
                <p>
                  <a href={asset.sourceUrl} rel="noreferrer">
                    Оригинальный источник
                  </a>{" "}
                  · сведения проверены{" "}
                  <time dateTime={asset.verifiedOn}>{asset.verifiedOn}</time>.
                </p>
              </>
            ) : (
              <p>
                Оригинальная иллюстрация ZILAL TRAVEL. Авторский векторный
                материал проекта.
              </p>
            )}
          </li>
        ))}
      </ul>
      <p>
        Для замены иллюстраций реальными фотографиями подготовлен перечень
        кадров и технических требований в PHOTO_PLAN.md. Перед добавлением
        каждого снимка нужны имя автора, оригинальный источник, условия
        использования и проверка требований к атрибуции. Заполненные поля сами
        по себе не подтверждают права.
      </p>
    </div>
  );
}
