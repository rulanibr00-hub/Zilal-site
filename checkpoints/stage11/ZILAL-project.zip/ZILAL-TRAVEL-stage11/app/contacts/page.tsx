import { CompanyContacts, CompanyContactChannels } from "@/components/cms/ContentProvider";
import { CmsText } from "@/components/cms/ContentProvider";
import type { Metadata } from "next";
import Link from "next/link";
import PageIntro from "@/components/PageIntro";
import InfoCard from "@/components/ui/InfoCard";
import ContactSection from "@/components/sections/ContactSection";
import { ButtonLink } from "@/components/ui/Button";
import { companyContacts } from "@/lib/data/brand";
const title = "Контакты ZILAL TRAVEL — вопросы о путешествиях в Кыргызстан";
const description =
  "Телефон, WhatsApp, email и адрес ZILAL TRAVEL: сведения для заполнения владельцем и форма обращения с явным указанием режима приёма.";
export const metadata: Metadata = {
  title,
  description,
  openGraph: { title, description, locale: "ru_RU", type: "website" },
};
export default function ContactsPage() {
  return (
    <div className="brand-editorial">
      <PageIntro
        eyebrow={<CmsText page="contacts" slot="text-9981505853b4" fallback="Контакты" />}
        title={<CmsText page="contacts" slot="text-7844180a2d30" fallback="Ваше путешествие" />}
        accent={<CmsText page="contacts" slot="text-70a6a863132d" fallback="начинается с разговора." />}
        description={<CmsText page="contacts" slot="text-6d8ff5d1d140" fallback="Здесь будут подтверждённые способы связи с семейной компанией ZILAL TRAVEL. Контакты ожидают заполнения владельцем; текущий режим приёма обращений указан в форме ниже." />}
        cmsPage="contacts"
        image="lake"
      />
      <section className="section wrap">
        <div className="section-heading">
          <div>
            <p className="eyebrow"><CmsText page="contacts" slot="text-90c51486e607" fallback="Четыре способа начать диалог" /></p>
            <h2><CmsText page="contacts" slot="text-5bea94a7839b" fallback="Ближе к вашей" />{" "}<em><CmsText page="contacts" slot="text-cd03922ac990" fallback="идее." /></em>
            </h2>
          </div>
          <p className="section-aside"><CmsText page="contacts" slot="text-9168fcfad338" fallback="Контактные данные ещё не опубликованы." /><br /><CmsText page="contacts" slot="text-5b78d8e8ffeb" fallback="Все четыре блока — места для заполнения." /></p>
        </div>
        <CompanyContacts/>
        <CompanyContactChannels/>
        <p className="contact-privacy-note"><CmsText page="contacts" slot="text-5d2f533ea0a5" fallback="Текущий режим приёма указан непосредственно в форме." />{" "}
          <Link href="/privacy"><CmsText page="contacts" slot="text-fe66048fc5b4" fallback="Как обрабатываются данные — политика конфиденциальности →" /></Link>
        </p>
      </section>
      <ContactSection purpose="inquiry" />
      <section className="section wrap brand-next">
        <div>
          <p className="eyebrow"><CmsText page="contacts" slot="text-9a99bf159f7d" fallback="Если пока есть только ощущение" /></p>
          <h2><CmsText page="contacts" slot="text-39afd637d855" fallback="Дайте идее" />{" "}<em><CmsText page="contacts" slot="text-1c5fc38dc406" fallback="форму." /></em>
          </h2>
          <p><CmsText page="contacts" slot="text-fe54a8ad3616" fallback="Конструктор поможет собрать предпочтения без отправки заявки." /></p>
        </div>
        <ButtonLink href="/create-trip"><CmsText page="contacts" slot="text-33ed5e4558ad" fallback="Создать путешествие" /></ButtonLink>
      </section>
    </div>
  );
}
