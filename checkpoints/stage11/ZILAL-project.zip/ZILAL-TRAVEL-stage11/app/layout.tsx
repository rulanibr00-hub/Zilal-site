import { publicContent } from "@/lib/server/cms-public";
import { ContentProvider } from "@/components/cms/ContentProvider";
import type { Metadata } from "next";
import "./globals.css";
import "./polish.css";
import SiteFrame from "@/components/SiteFrame";
export const metadata: Metadata = {
  title: "ZILAL TRAVEL — почувствуй Кыргызстан",
  description:
    "Знакомство с Кыргызстаном: горы Тянь-Шаня, Иссык-Куль, культура кочевников и идеи индивидуальных путешествий.",
  robots: { index: false, follow: false },
  openGraph: {
    title: "ZILAL TRAVEL — почувствуй Кыргызстан",
    description: "Горы. Свобода. Люди. Путешествие, которое остаётся с тобой.",
    locale: "ru_RU",
    type: "website",
  },
};
export const dynamic = "force-dynamic";
export default async function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const snapshot = await publicContent();
  return (
    <html lang="ru">
      <body>
        <ContentProvider value={snapshot}><SiteFrame>{children}</SiteFrame></ContentProvider>
      </body>
    </html>
  );
}
