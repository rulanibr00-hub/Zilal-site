import { CmsText } from "@/components/cms/ContentProvider";
import Link from "next/link";
import Hero from "@/components/home/Hero";
import Photo from "@/components/Photo";
import { ButtonLink } from "@/components/ui/Button";
import {
  TourConceptGrid,
  DestinationGrid,
} from "@/components/sections/TravelGrids";
import ContactSection from "@/components/sections/ContactSection";
import Principles from "@/components/sections/Principles";
export default function Home() {
  return (
    <>
      <Hero />
      <section className="intro wrap" id="about">
        <div>
          <p className="eyebrow"><CmsText page="home" slot="text-90941ab05fff" fallback="Салам, путешественник" /></p>
          <h2><CmsText page="home" slot="text-997da9fc568c" fallback="Не просто увидеть." /><br />
            <em><CmsText page="home" slot="text-fadeb310a654" fallback="Почувствовать." /></em>
          </h2>
        </div>
        <div className="intro-copy" data-reveal>
          <p><CmsText page="home" slot="text-02298b10ebdf" fallback="ZILAL TRAVEL — проект о путешествиях по Кыргызстану. О дороге вдоль озера, чае в юрте и моментах, когда хочется просто остановиться." /></p>
          <p className="muted"><CmsText page="home" slot="text-39a881db3e50" fallback="Мы создаём пространство для знакомства со страной. Ниже — идеи будущих маршрутов, а не готовые предложения к продаже." /></p>
          <Link className="text-link" href="/kyrgyzstan"><CmsText page="home" slot="text-34762cee984c" fallback="Познакомиться с Кыргызстаном →" /></Link>
        </div>
      </section>
      <Principles />
      <section id="tours" className="section wrap">
        <div className="section-heading">
          <div>
            <p className="eyebrow"><CmsText page="home" slot="text-79d49ac55a9d" fallback="Два настроения одной страны" /></p>
            <h2><CmsText page="home" slot="text-901d1e51eee3" fallback="Какой Кыргызстан" />{" "}<em><CmsText page="home" slot="text-67043eb3c26b" fallback="ваш?" /></em>
            </h2>
          </div>
          <div>
            <p className="section-aside"><CmsText page="home" slot="text-50b7f139820a" fallback="Демонстрационные концепции туров." /><br /><CmsText page="home" slot="text-32040ae92fef" fallback="Программа и условия пока не определены." /></p>
            <Link className="text-link" href="/tours"><CmsText page="home" slot="text-751e00418a5a" fallback="Все концепции →" /></Link>
          </div>
        </div>
        <TourConceptGrid />
      </section>
      <section id="destinations" className="section destinations">
        <div className="wrap">
          <div className="section-heading">
            <div>
              <p className="eyebrow"><CmsText page="home" slot="text-bea8e6838f65" fallback="Места с характером" /></p>
              <h2><CmsText page="home" slot="text-1137c8250165" fallback="Точки" />{" "}<em><CmsText page="home" slot="text-6ee1d1e4258c" fallback="притяжения." /></em>
              </h2>
            </div>
            <Link href="/destinations" className="text-link"><CmsText page="home" slot="text-71886f6beb17" fallback="Все направления →" /></Link>
          </div>
          <DestinationGrid />
        </div>
      </section>
      <section id="tailor-made" className="tailor wrap">
        <div className="contour" aria-hidden="true">
          ◎
        </div>
        <div>
          <p className="eyebrow"><CmsText page="home" slot="text-c115d970d7a2" fallback="Ваше путешествие. Ваши правила." /></p>
          <h2><CmsText page="home" slot="text-533156a79f0e" fallback="Маршрут начинается" /><br />
            <em><CmsText page="home" slot="text-bf44e3eeca76" fallback="с вашей мечты." /></em>
          </h2>
          <p><CmsText page="home" slot="text-33b1adb7988a" fallback="Больше гор или больше тишины? Семейная поездка или треккинг?" /><br /><CmsText page="home" slot="text-e007aa3a6f49" fallback="Расскажите, что важно именно вам." /></p>
          <ButtonLink href="/create-trip"><CmsText page="home" slot="text-826c83b52050" fallback="Создать свой маршрут" /></ButtonLink>
        </div>
        <span className="tailor-symbol" aria-hidden="true">
          ✧
        </span>
      </section>
      <section id="culture" className="culture">
        <div className="culture-image">
          <Photo name="culture" slot="editorial" />
          <span className="image-caption"><CmsText page="home" slot="text-9b583481ebd1" fallback="Культура гостеприимства" /></span>
        </div>
        <div className="culture-copy">
          <p className="eyebrow"><CmsText page="home" slot="text-509c50dc4f14" fallback="Душа Кыргызстана" /></p>
          <h2><CmsText page="home" slot="text-0e70148380fe" fallback="Горы впечатляют." /><br />
            <em><CmsText page="home" slot="text-cc505dff426e" fallback="Люди остаются" /><br /><CmsText page="home" slot="text-c086f31fea05" fallback="в сердце." /></em>
          </h2>
          <p><CmsText page="home" slot="text-7b80a4950ca4" fallback="Юрта — не просто дом. Это мир, где гость занимает почётное место, чай объединяет за одним столом, а истории передаются из поколения в поколение." /></p>
          <p><CmsText page="home" slot="text-150fe8ae32e5" fallback="Познакомьтесь с традициями кочевников, вкусами местной кухни и неспешным ритмом жизни на джайлоо." /></p>
          <Link href="/contacts" className="text-link"><CmsText page="home" slot="text-131871d80c86" fallback="Добавить культуру в путешествие →" /></Link>
        </div>
      </section>
      <ContactSection />
    </>
  );
}
