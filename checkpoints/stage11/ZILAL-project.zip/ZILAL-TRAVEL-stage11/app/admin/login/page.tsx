import Link from "next/link";
import { redirect } from "next/navigation";
import { currentAdmin } from "@/lib/server/auth";
import { originConfig } from "@/lib/admin/security";
import LoginForm from "@/components/admin/LoginForm";
export const metadata = { title: "Вход администратора" };
export default async function LoginPage() {
  let configured = Boolean(process.env.DATABASE_URL);
  try {
    originConfig();
  } catch {
    configured = false;
  }
  let active = false;
  try {
    active = Boolean(await currentAdmin());
  } catch {
    /* Show the same safe login screen during a storage outage. */
  }
  if (active) redirect("/admin");
  return (
    <main className="admin-login-page">
      <section className="admin-login-story">
        <Link href="/" className="admin-brand">
          ZILAL<span>TRAVEL · LUXURY + ADVENTURE</span>
        </Link>
        <div>
          <p className="admin-eyebrow">Забота о каждом путешествии</p>
          <h1>
            Большие истории.
            <br />
            <em>Внимание к деталям.</em>
          </h1>
          <p>
            Рабочее пространство ZILAL TRAVEL.
            <br />
            Обращения, содержание и настройки в одном месте.
          </p>
        </div>
        <span className="admin-login-caption">КЫРГЫЗСТАН · ЛИЧНЫЙ ПОДХОД</span>
      </section>
      <section className="admin-login-panel">
        <div className="admin-login-card">
          <p className="admin-eyebrow">Закрытый раздел</p>
          <h2>С возвращением.</h2>
          <p>Войдите, чтобы продолжить работу.</p>
          {!configured && (
            <p className="admin-alert" role="status">
              Среда не настроена. Укажите DATABASE_URL и ADMIN_ORIGIN, примените
              миграции и создайте администратора через терминал. Секреты
              вводятся только локально.
            </p>
          )}
          <LoginForm configured={configured} />
          <Link href="/" className="admin-backlink">
            ← На публичный сайт
          </Link>
        </div>
      </section>
    </main>
  );
}
