import { inquiryConfiguration } from "@/lib/inquiries/policy";
import { requireAdminPage } from "@/lib/server/auth";
import AdminShell from "@/components/admin/AdminShell";
export default async function ProtectedLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const admin = await requireAdminPage();
  return (
    <AdminShell
      login={admin.login}
      csrf={admin.csrf}
      intakeMode={inquiryConfiguration().public.mode}
    >
      {children}
    </AdminShell>
  );
}
