import Link from "next/link";
export default function NotFound() {
  return (
    <section className="admin-card admin-empty">
      <h1>Заявка не найдена.</h1>
      <p>Проверьте адрес или вернитесь к списку обращений.</p>
      <Link href="/admin/inquiries" prefetch={false} className="admin-button">
        К заявкам
      </Link>
    </section>
  );
}
