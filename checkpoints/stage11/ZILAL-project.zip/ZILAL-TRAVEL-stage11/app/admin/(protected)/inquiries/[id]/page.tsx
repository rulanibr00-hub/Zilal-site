import Link from "next/link";
import { requireAdminPage } from "@/lib/server/auth";
import { inquiryDetails } from "@/lib/server/inquiries";
import { pageData } from "@/lib/server/page-data";
import { inquiryNumber, sourceLabels, adminDate } from "@/lib/admin/contracts";
import { publicTour } from "@/lib/server/cms-public";
import { destinations } from "@/lib/data/destinations";
import {
  tripActivities,
  accommodationOptions,
  formatTripDate,
} from "@/lib/trip-builder";
import { travelStyles } from "@/lib/tour-catalog";
import InquiryEditor from "@/components/admin/InquiryEditor";
export const metadata = { title: "Подробности заявки" };
const fieldLabels: Record<string, string> = {
  message: "Сообщение",
  style: "Стиль",
  destinationIds: "Направления",
  activities: "Активности",
  duration: "Продолжительность, дней",
  flexibleDates: "Гибкие даты",
  startDate: "Начало поездки",
  adults: "Взрослые",
  children: "Дети",
  accommodation: "Проживание",
  wishes: "Пожелания",
  contactMethod: "Способ связи",
};
function detailValue(key: string, value: unknown): string {
  if (key === "destinationIds" && Array.isArray(value))
    return value
      .map((id) => destinations.find((d) => d.id === id)?.name.ru ?? id)
      .join(" · ");
  if (key === "activities" && Array.isArray(value))
    return value
      .map((id) => tripActivities.find((a) => a.id === id)?.title ?? id)
      .join(" · ");
  if (key === "style" && typeof value === "string" && value in travelStyles)
    return travelStyles[value as keyof typeof travelStyles].title;
  if (key === "accommodation")
    return (
      accommodationOptions.find((a) => a.id === value)?.title ?? "Не указано"
    );
  if (key === "contactMethod")
    return value === "phone" ? "Телефон" : "WhatsApp";
  if (key === "startDate" && typeof value === "string")
    return value ? formatTripDate(value) : "Не определено";
  if (typeof value === "boolean") return value ? "Да" : "Нет";
  return String(value ?? "") || "Не указано";
}
export default async function InquiryPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const auth = await requireAdminPage();
  const row = await pageData(inquiryDetails((await params).id));
  const tour = row.tourSlug ? await publicTour(row.tourSlug) : undefined;
  return (
    <>
      <Link href="/admin/inquiries" prefetch={false} className="admin-backlink">
        ← Все заявки
      </Link>
      <div className="admin-page-heading">
        <div>
          <p className="admin-eyebrow">{sourceLabels[row.source]}</p>
          <h1>{inquiryNumber(row.number)}</h1>
          <p>Создана {adminDate(row.createdAt)}</p>
        </div>
        {row.isTest && <span className="admin-chip">Тестовая запись</span>}
      </div>
      <div className="admin-detail-grid">
        <div>
          <section className="admin-card">
            <h2>Контакты гостя</h2>
            <dl className="admin-definition">
              <div>
                <dt>Имя</dt>
                <dd>{row.name}</dd>
              </div>
              <div>
                <dt>Email</dt>
                <dd>{row.email}</dd>
              </div>
              <div>
                <dt>Телефон / WhatsApp</dt>
                <dd>{row.phone ?? "Не указан"}</dd>
              </div>
              {tour && (
                <div>
                  <dt>Основа путешествия</dt>
                  <dd>{tour.title.ru} · пример маршрута</dd>
                </div>
              )}
            </dl>
          </section>
          {row.policyDigest && (
            <section className="admin-card">
              <h2>Условия приёма</h2>
              <dl className="admin-definition">
                <div>
                  <dt>Версия согласованного документа (SHA-256)</dt>
                  <dd>{row.policyDigest}</dd>
                </div>
                <div>
                  <dt>Отметка согласия</dt>
                  <dd>
                    {row.consentGiven
                      ? "Предоставлена"
                      : "Отдельная отметка не предоставлялась"}
                    {row.consentRecordedAt
                      ? ` · ${adminDate(row.consentRecordedAt)}`
                      : ""}
                  </dd>
                </div>
              </dl>
              <p className="admin-help">
                Утверждённая версия политики сохранена в архиве БД. Технический
                идентификатор посетителя через API не возвращается.
              </p>
            </section>
          )}
          <section className="admin-card">
            <h2>Детали путешествия</h2>
            <dl className="admin-definition">
              {Object.entries(row.details).map(([key, value]) => (
                <div key={key}>
                  <dt>{fieldLabels[key] ?? "Деталь"}</dt>
                  <dd>{detailValue(key, value)}</dd>
                </div>
              ))}
            </dl>
          </section>
        </div>
        <InquiryEditor
          id={row.id}
          initialStatus={row.status}
          initialNote={row.internalNote}
          updatedAt={row.updatedAt.toISOString()}
          csrf={auth.csrf}
        />
      </div>
    </>
  );
}
