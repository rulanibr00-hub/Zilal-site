import { inquiryConfiguration } from "@/lib/inquiries/policy";
import { requireAdminPage } from "@/lib/server/auth";
import { listInquiries } from "@/lib/server/inquiries";
import { pageData } from "@/lib/server/page-data";
import InquiryList from "@/components/admin/InquiryList";
export const metadata = { title: "Заявки" };
export default async function InquiriesPage() {
  const auth = await requireAdminPage();
  const initial = await pageData(listInquiries());
  return (
    <>
      <div className="admin-page-heading">
        <div>
          <p className="admin-eyebrow">Личный подход</p>
          <h1>Заявки путешественников.</h1>
          <p>Обращения, статусы и детали — только для администратора.</p>
        </div>
        <span className="admin-chip">
          {inquiryConfiguration().public.mode === "live"
            ? "Приём включён"
            : inquiryConfiguration().public.mode === "test"
              ? "Локальный тест"
              : "Приём отключён"}
        </span>
      </div>
      <InquiryList
        csrf={auth.csrf}
        initial={JSON.parse(JSON.stringify(initial))}
      />
    </>
  );
}
