import { inquiryConfiguration } from "@/lib/inquiries/policy";
import { telegramStore } from "@/lib/server/telegram";
import Link from "next/link";
import { requireAdminPage } from "@/lib/server/auth";
import { dashboard } from "@/lib/server/inquiries";
import { pageData } from "@/lib/server/page-data";
import { adminDate, inquiryNumber, statusLabels } from "@/lib/admin/contracts";
export const metadata = { title: "Обзор" };
export default async function DashboardPage() {
  await requireAdminPage();
  const intake = inquiryConfiguration().public.mode;
  const { counts, recent } = await pageData(dashboard());
  const telegram = await pageData(telegramStore().state());
  return (
    <>
      <div className="admin-page-heading">
        <div>
          <p className="admin-eyebrow">Обзор</p>
          <h1>Внимание начинается здесь.</h1>
          <p>Обращения гостей и состояние вашего рабочего пространства.</p>
        </div>
        <Link prefetch={false} href="/admin/inquiries" className="admin-button">
          Все заявки <span aria-hidden="true">→</span>
        </Link>
      </div>
      <div className="admin-stats">
        {[
          { label: "Всего заявок", value: counts.total, mark: "01" },
          { label: "Новые", value: counts.new, mark: "02" },
          { label: "В работе", value: counts.inProgress, mark: "03" },
        ].map((item) => (
          <section className="admin-stat" key={item.label}>
            <span>{item.mark}</span>
            <h2>{item.label}</h2>
            <strong>{item.value}</strong>
          </section>
        ))}
      </div>
      {counts.test > 0 && (
        <p className="admin-notice">
          Тестовых записей: {counts.test}. Они учитываются в показателях и
          отмечены в списках.
        </p>
      )}
      <div className="admin-dashboard-grid">
        <section className="admin-card">
          <div className="admin-card-heading">
            <h2>Последние обращения</h2>
            <span className="admin-chip">Из базы данных</span>
          </div>
          {recent.length ? (
            <ul className="admin-recent">
              {recent.map((row) => (
                <li key={row.id}>
                  <Link prefetch={false} href={`/admin/inquiries/${row.id}`}>
                    <span className="admin-recent-number">
                      {inquiryNumber(row.number)}
                      {row.isTest && <small>Тестовая</small>}
                    </span>
                    <span>
                      <strong>{row.name}</strong>
                      <small>{adminDate(row.createdAt)}</small>
                    </span>
                    <span className={`admin-status status-${row.status}`}>
                      {statusLabels[row.status]}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <div className="admin-empty">
              <span aria-hidden="true">◇</span>
              <h3>Пока тихо.</h3>
              <p>
                Заявок ещё нет. Здесь появятся обращения после подключения
                приёма.
              </p>
            </div>
          )}
        </section>
        <section className="admin-card">
          <div className="admin-card-heading">
            <h2>Состояние системы</h2>
          </div>
          <ul className="admin-system">
            <li>
              <span>База данных</span>
              <strong className="admin-system-ok">Доступна</strong>
            </li>
            <li>
              <span>Авторизация</span>
              <strong className="admin-system-ok">Сессия активна</strong>
            </li>
            <li>
              <span>Публичные заявки</span>
              <strong>
                {intake === "live"
                  ? "Включены"
                  : intake === "test"
                    ? "Локальный тест"
                    : "Отключены"}
              </strong>
            </li>
            <li>
              <span>Email-уведомления</span>
              <strong>Не настроены</strong>
            </li>
            <li>
              <span>Telegram</span>
              <strong>
                {telegram.bots.length
                  ? `${telegram.bots.filter((b) => b.enabled).length} включено · ${telegram.networkEnabled ? "сеть разрешена" : "сеть отключена"}`
                  : "Не настроен"}
              </strong>
            </li>
          </ul>
          <p className="admin-help">
            Приём обращений управляется отдельным серверным разрешением и
            согласованной политикой.
          </p>
        </section>
      </div>
    </>
  );
}
