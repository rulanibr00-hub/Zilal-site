export default function Loading() {
  return (
    <div className="admin-loading" role="status">
      Загружаем рабочее пространство…
    </div>
  );
}
