import ContentEditor from "@/components/admin/ContentEditor";
import { requireAdminPage } from "@/lib/server/auth";
import { readSettings } from "@/lib/server/settings";
import { pageData } from "@/lib/server/page-data";
import SettingsForms from "@/components/admin/SettingsForms";
export const metadata = { title: "Настройки" };
export default async function SettingsPage() {
  const auth = await requireAdminPage();
  const initial = await pageData(readSettings());
  return (
    <>
      <ContentEditor kind="company" csrf={auth.csrf}/>
      <details><summary>Прежние внутренние настройки (не публикуются)</summary><SettingsForms initial={initial} csrf={auth.csrf} /></details>
    </>
  );
}
