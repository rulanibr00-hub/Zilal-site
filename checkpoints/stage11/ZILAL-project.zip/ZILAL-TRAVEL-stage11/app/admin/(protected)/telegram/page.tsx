import { inquiryConfiguration } from "@/lib/inquiries/policy";
import { requireAdminPage } from "@/lib/server/auth";
import { telegramStore } from "@/lib/server/telegram";
import { pageData } from "@/lib/server/page-data";
import TelegramPanel from "@/components/admin/TelegramPanel";
export const metadata = { title: "Telegram" };
export default async function TelegramPage() {
  const auth = await requireAdminPage();
  const state = await pageData(telegramStore().state());
  return (
    <TelegramPanel
      intakeMode={inquiryConfiguration().public.mode}
      csrf={auth.csrf}
      initial={JSON.parse(JSON.stringify(state))}
    />
  );
}
