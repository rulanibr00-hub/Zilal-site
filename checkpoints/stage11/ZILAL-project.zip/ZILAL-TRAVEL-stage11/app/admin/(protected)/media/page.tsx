import { requireAdminPage } from '@/lib/server/auth';import MediaLibrary from '@/components/admin/MediaLibrary';
export const metadata={title:'Медиатека'};
export default async function Page(){const auth=await requireAdminPage();return <MediaLibrary csrf={auth.csrf}/>;}
