import { requireAdminPage } from '@/lib/server/auth';
import ContentEditor from '@/components/admin/ContentEditor';
export const metadata={title:'Редактор содержимого'};
export default async function Page(){const auth=await requireAdminPage();return <ContentEditor kind="tour" csrf={auth.csrf}/>;}
