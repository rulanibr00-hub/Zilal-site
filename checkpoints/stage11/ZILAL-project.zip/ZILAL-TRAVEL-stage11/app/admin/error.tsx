"use client";
import Link from "next/link";
export default function AdminError({ reset }: { reset: () => void }) {
  return (
    <main className="admin-error-page">
      <p className="admin-eyebrow">Временная пауза</p>
      <h1>Раздел пока недоступен.</h1>
      <p>
        Проверьте подключение базы данных и миграции. Секреты и технические
        подробности не отображаются.
      </p>
      <button className="admin-button" onClick={reset}>
        Повторить
      </button>
      <Link href="/admin/login" prefetch={false} className="admin-backlink">
        Перейти ко входу
      </Link>
    </main>
  );
}
