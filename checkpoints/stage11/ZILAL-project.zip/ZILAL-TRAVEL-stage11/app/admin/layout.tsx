import type { Metadata } from "next";
import "./admin.css";
export const metadata: Metadata = {
  title: {
    default: "Управление — ZILAL TRAVEL",
    template: "%s — ZILAL TRAVEL",
  },
  description: "Закрытая административная панель ZILAL TRAVEL.",
  robots: { index: false, follow: false, noarchive: true },
};
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <div className="admin-app">{children}</div>;
}
