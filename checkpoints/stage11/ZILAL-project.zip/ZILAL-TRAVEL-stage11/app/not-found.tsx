import { ButtonLink } from "@/components/ui/Button";
export default function NotFound() {
  return (
    <section className="document">
      <p className="eyebrow">Страница не найдена</p>
      <h1>У этой дороги пока нет продолжения.</h1>
      <p>
        По этому адресу пока нет страницы. Выберите маршрут в каталоге или
        опишите собственную идею путешествия.
      </p>
      <ButtonLink href="/tours">Вернуться в каталог</ButtonLink>
    </section>
  );
}
