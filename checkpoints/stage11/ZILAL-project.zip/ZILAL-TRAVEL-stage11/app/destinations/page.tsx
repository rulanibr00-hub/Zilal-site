import type { Metadata } from "next";
import PageIntro from "@/components/PageIntro";
import { DestinationGrid } from "@/components/sections/TravelGrids";
import { ButtonLink } from "@/components/ui/Button";
import Photo from "@/components/Photo";
import { isDocumentedPhoto, photos } from "@/lib/media";
import { destinations } from "@/lib/data/destinations";
export const metadata: Metadata = {
  title: "Направления Кыргызстана — ZILAL TRAVEL",
  description:
    "Иссык-Куль, Сон-Куль, Сказка, Каракол и Ала-Куль: знакомство с природой и идеи для будущего маршрута.",
};
export default function DestinationsPage() {
  return (
    <>
      <PageIntro
        eyebrow="Направления"
        title="Места, которые"
        accent="зовут в дорогу."
        description="Пять разных характеров Кыргызстана. Выберите то, что откликается, — от берегов озера до высокогорных троп."
        image="lake"
      />
      <section className="section wrap">
        <div className="section-heading">
          <div>
            <p className="eyebrow">Первые ориентиры</p>
            <h2>
              Точки <em>притяжения.</em>
            </h2>
          </div>
          <p className="section-aside">
            Справочник мест.
            <br />
            Не каталог готовых туров.
          </p>
        </div>
        <DestinationGrid />
      </section>
      <section
        className="destination-stories wrap"
        aria-label="Описание направлений"
      >
        {destinations.map((d, i) => (
          <article className="destination-story" id={d.id} key={d.id}>
            <div className="story-visual">
              <Photo name={d.image} slot="editorial" />
              <span className="image-caption">
                {isDocumentedPhoto(photos[d.image])
                  ? photos[d.image].label
                  : "Оригинальная иллюстрация"}{" "}
                · 0{i + 1}
              </span>
            </div>
            <div className="story-copy">
              <p className="eyebrow">{d.category.ru}</p>
              <h2>{d.name.ru}</h2>
              <p>{d.description.ru}</p>
              <p className="planning-note">{d.planningNote.ru}</p>
              <ButtonLink href="/create-trip">
                Включить в идею маршрута
              </ButtonLink>
            </div>
          </article>
        ))}
      </section>
    </>
  );
}
