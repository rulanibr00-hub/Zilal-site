import { CmsText } from "@/components/cms/ContentProvider";
import type { Metadata } from "next";
import Link from "next/link";
import PageIntro from "@/components/PageIntro";
import EditorialFeature from "@/components/editorial/EditorialFeature";
import InfoCard from "@/components/ui/InfoCard";
import { ButtonLink } from "@/components/ui/Button";
import {
  countryChapters,
  practicalAdvice,
  seasons,
} from "@/lib/data/kyrgyzstan";
const title = "О Кыргызстане: природа, культура и сезоны — ZILAL TRAVEL";
const description =
  "Познакомьтесь с природой Кыргызстана, культурой и традициями, особенностями сезонов и практическими ориентирами для планирования путешествия.";
export const metadata: Metadata = {
  title,
  description,
  openGraph: { title, description, locale: "ru_RU", type: "website" },
};
export default function KyrgyzstanPage() {
  return (
    <div className="brand-editorial">
      <PageIntro
        eyebrow={<CmsText page="kyrgyzstan" slot="text-f988474e47c6" fallback="О Кыргызстане" />}
        title={<CmsText page="kyrgyzstan" slot="text-e802737f5e50" fallback="Больше, чем пейзаж." />}
        accent={<CmsText page="kyrgyzstan" slot="text-34114a848e7b" fallback="Место для настоящего." />}
        description={<CmsText page="kyrgyzstan" slot="text-ea671e501780" fallback="Озёра между горными хребтами, жизнь на джайлоо, ремёсла и встречи за одним столом. Кыргызстан открывается через детали — и у каждой свой ритм." />}
        cmsPage="kyrgyzstan"
        image="lake"
      />
      <nav className="country-chapters wrap" aria-label="Разделы о Кыргызстане">
        {countryChapters.map((chapter, index) => (
          <a href={`#${chapter.id}`} key={chapter.id}>
            <span aria-hidden="true">0{index + 1}</span>
            <CmsText page="kyrgyzstan" slot={`chapter-${chapter.id}`} fallback={chapter.title}/>
          </a>
        ))}
      </nav>
      <EditorialFeature
        id="nature"
        eyebrow={<CmsText page="kyrgyzstan" slot="text-564d68825c3e" fallback="01 · Природа" />}
        title={<CmsText page="kyrgyzstan" slot="text-2d8149cea971" fallback="Озёрная тишина." />}
        accent={<CmsText page="kyrgyzstan" slot="text-aba9202e698d" fallback="Горный масштаб." />}
        image="alakul"
        caption={<CmsText page="kyrgyzstan" slot="text-43d17e9347c7" fallback="Оригинальная иллюстрация · горы и озёра" />}
      >
        <p><CmsText page="kyrgyzstan" slot="text-34ae61dfc052" fallback="Горы задают характер Кыргызстана. Между хребтами лежат озёра и долины, а дороги соединяют прибрежные поселения, ущелья и высокогорные пастбища." /></p>
        <p><CmsText page="kyrgyzstan" slot="text-89cb5fc72385" fallback="Иссык-Куль приглашает замедлиться у воды, Сон-Куль — почувствовать простор джайлоо, а тропы к Ала-Кулю требуют другого темпа и подготовки." /></p>
        <div className="editorial-inline-links">
          <Link href="/destinations#issyk-kul"><CmsText page="kyrgyzstan" slot="text-a0d7980c1dd9" fallback="Иссык-Куль →" /></Link>
          <Link href="/destinations#son-kul"><CmsText page="kyrgyzstan" slot="text-5d96affdf942" fallback="Сон-Куль →" /></Link>
          <Link href="/destinations#ala-kul"><CmsText page="kyrgyzstan" slot="text-3843264721c7" fallback="Ала-Куль →" /></Link>
        </div>
        <ButtonLink href="/destinations"><CmsText page="kyrgyzstan" slot="text-af60c2496337" fallback="Все направления" /></ButtonLink>
      </EditorialFeature>
      <EditorialFeature
        id="culture"
        eyebrow={<CmsText page="kyrgyzstan" slot="text-917d63b20a9d" fallback="02 · Культура" />}
        title={<CmsText page="kyrgyzstan" slot="text-cbdcb5efeed2" fallback="Услышать истории." />}
        accent={<CmsText page="kyrgyzstan" slot="text-335a56279280" fallback="Заметить повседневность." />}
        image="culture"
        caption={<CmsText page="kyrgyzstan" slot="text-aad7279ab0f4" fallback="Оригинальная иллюстрация · культурный ландшафт" />}
        reverse
      >
        <p><CmsText page="kyrgyzstan" slot="text-93eaeae39ce1" fallback="Культурное наследие живёт в повседневных деталях. Оно встречается в музыке комуза, войлочных узорах, домашней кухне и привычке собираться за одним столом." /></p>
        <p><CmsText page="kyrgyzstan" slot="text-2ed0d791bd89" fallback="В городах и сёлах, в разных семьях и сообществах уклад может отличаться. Знакомство становится глубже, когда есть время слушать и задавать вопросы." /></p>
        <Link href="/destinations#karakol" className="text-link"><CmsText page="kyrgyzstan" slot="text-864614f8677c" fallback="Каракол: город и культура →" /></Link>
      </EditorialFeature>
      <section id="traditions" className="section wrap">
        <div className="section-heading">
          <div>
            <p className="eyebrow"><CmsText page="kyrgyzstan" slot="text-d9ff9871ef12" fallback="03 · Национальные традиции" /></p>
            <h2><CmsText page="kyrgyzstan" slot="text-c01342b5cfe5" fallback="То, что передают" />{" "}<em><CmsText page="kyrgyzstan" slot="text-d267be70a94a" fallback="дальше." /></em>
            </h2>
          </div>
          <p className="section-aside"><CmsText page="kyrgyzstan" slot="text-8266207e5ff3" fallback="Уважение к укладу хозяев —" /><br /><CmsText page="kyrgyzstan" slot="text-8a691643ce9a" fallback="хорошее начало знакомства." /></p>
        </div>
        <div className="info-grid">
          <InfoCard number="01" title={<CmsText page="kyrgyzstan" slot="text-008dc8994e88" fallback="Юрта и гостеприимство" />} headingLevel={3}>
            <p><CmsText page="kyrgyzstan" slot="text-1aa82b340421" fallback="Юрта связана с кочевым наследием и жизнью на пастбищах. Встреча за чаем может стать поводом для разговора, но правила дома и возможность визита всегда определяют хозяева." /></p>
          </InfoCard>
          <InfoCard number="02" title={<CmsText page="kyrgyzstan" slot="text-5a6419d7ab1c" fallback="Ремёсла и память" />} headingLevel={3}>
            <p><CmsText page="kyrgyzstan" slot="text-ec05369930da" fallback="Войлок, узоры шырдака и ручная работа помогают увидеть связь вещей с местом и семейной памятью. Съёмку мастеров и посещение мастерской стоит согласовывать заранее." /></p>
          </InfoCard>
          <InfoCard number="03" title={<CmsText page="kyrgyzstan" slot="text-22c0b1f4d551" fallback="Вкус и общий стол" />} headingLevel={3}>
            <p><CmsText page="kyrgyzstan" slot="text-30f43fc3d94a" fallback="Национальная кухня — ещё один способ знакомства со страной. Состав блюд и пищевые предпочтения лучше обсуждать отдельно, не предполагая одинаковое меню в каждом доме." /></p>
          </InfoCard>
        </div>
      </section>
      <section id="seasons" className="section country-seasons">
        <div className="wrap">
          <div className="section-heading">
            <div>
              <p className="eyebrow"><CmsText page="kyrgyzstan" slot="text-eee0d13930df" fallback="04 · Сезоны" /></p>
              <h2><CmsText page="kyrgyzstan" slot="text-fb057b81af62" fallback="Одна страна." /><br />
                <em><CmsText page="kyrgyzstan" slot="text-8e6a4b30a43a" fallback="Четыре настроения." /></em>
              </h2>
            </div>
            <p className="section-aside"><CmsText page="kyrgyzstan" slot="text-59975671cb62" fallback="Ориентиры для выбора времени," /><br /><CmsText page="kyrgyzstan" slot="text-d8a74058222f" fallback="а не прогноз или обещание доступности." /></p>
          </div>
          <div className="season-grid">
            {seasons.map((season, index) => (
              <article className="season-card" key={season.title} data-reveal>
                <span className="benefit-number">0{index + 1} —</span>
                <h3>{season.title}</h3>
                <p className="season-mood"><CmsText page="kyrgyzstan" slot={`season-${index}-mood`} fallback={season.mood}/></p>
                <p><CmsText page="kyrgyzstan" slot={`season-${index}-description`} fallback={season.description}/></p>
              </article>
            ))}
          </div>
          <p className="season-note"><CmsText page="kyrgyzstan" slot="text-81cd5646b3e3" fallback="Условия в долине и на высоте различаются. Перед поездкой нужно уточнять погоду, состояние дорог и подходящий уровень нагрузки для конкретного маршрута." /></p>
        </div>
      </section>
      <section id="practical" className="section wrap country-practical">
        <div>
          <p className="eyebrow"><CmsText page="kyrgyzstan" slot="text-839cef6cb5ab" fallback="05 · Практические советы" /></p>
          <h2><CmsText page="kyrgyzstan" slot="text-fa1fbab49216" fallback="Чуть больше подготовки." /><br />
            <em><CmsText page="kyrgyzstan" slot="text-8862d2b7c6c8" fallback="Больше места открытиям." /></em>
          </h2>
          <p><CmsText page="kyrgyzstan" slot="text-ffc19ed36c84" fallback="Это общие ориентиры для планирования. Актуальные требования к документам и условия конкретной поездки проверяются отдельно." /></p>
        </div>
        <div className="travel-advice">
          {practicalAdvice.map((advice,index) => (
            <details key={advice.title}>
              <summary><CmsText page="kyrgyzstan" slot={`advice-${index}-title`} fallback={advice.title}/></summary>
              <p><CmsText page="kyrgyzstan" slot={`advice-${index}-text`} fallback={advice.text}/></p>
            </details>
          ))}
        </div>
      </section>
      <section className="section wrap brand-next">
        <div>
          <p className="eyebrow"><CmsText page="kyrgyzstan" slot="text-5e1e9071a60f" fallback="Почувствовать страну по-своему" /></p>
          <h2><CmsText page="kyrgyzstan" slot="text-3e8e3a6f5bb6" fallback="Найдите свой" />{" "}<em><CmsText page="kyrgyzstan" slot="text-b91cd1794cd9" fallback="маршрут." /></em>
          </h2>
        </div>
        <div className="brand-actions">
          <ButtonLink href="/tours"><CmsText page="kyrgyzstan" slot="text-b29d9c973345" fallback="Примеры туров" /></ButtonLink>
          <ButtonLink variant="gold" href="/create-trip"><CmsText page="kyrgyzstan" slot="text-2d4d558d1611" fallback="Создать путешествие" /></ButtonLink>
        </div>
      </section>
    </div>
  );
}
