import { api, assertOrigin, readJson, json } from "@/lib/server/http";
import { loginAdmin, cookieOptions } from "@/lib/server/auth";
import { originConfig } from "@/lib/admin/security";
export const runtime = "nodejs";
export async function POST(request: Request) {
  return api(async () => {
    assertOrigin(request);
    const result = await loginAdmin(await readJson(request));
    const response = json({ authenticated: true, csrf: result.csrf });
    response.cookies.set(originConfig().cookieName, result.token, {
      ...cookieOptions(),
      expires: result.expiresAt,
    });
    return response;
  });
}
