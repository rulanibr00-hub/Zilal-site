import { api,json,readJson } from '@/lib/server/http';
import { requireAdminApi } from '@/lib/server/auth';
import { mediaList,uploadMedia,deleteMedia } from '@/lib/server/cms-media';
export async function GET(){return api(async()=>{await requireAdminApi();return json({media:await mediaList()});});}
export async function POST(r:Request){return api(async()=>{const a=await requireAdminApi(r);return json(await uploadMedia(r,a.adminId),201);});}
export async function DELETE(r:Request){return api(async()=>{const a=await requireAdminApi(r);return json(await deleteMedia(await readJson(r),a.adminId));});}
