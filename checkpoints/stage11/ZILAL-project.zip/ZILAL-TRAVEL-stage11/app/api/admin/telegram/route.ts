import { api, json, readJson, HttpError } from "@/lib/server/http";
import { requireAdminApi } from "@/lib/server/auth";
import { telegramStore, telegramAction } from "@/lib/server/telegram";
export async function GET(request: Request) {
  return api(async () => {
    await requireAdminApi();
    const page = Number(new URL(request.url).searchParams.get("page") ?? 1);
    if (!Number.isInteger(page) || page < 1 || page > 10000)
      throw new HttpError(400, "Некорректная страница журнала.");
    return json(await telegramStore().state(page));
  });
}
export async function POST(request: Request) {
  return api(async () => {
    const auth = await requireAdminApi(request);
    return json(await telegramAction(await readJson(request), auth.adminId));
  });
}
