import { api, json, readJson } from "@/lib/server/http";
import { requireAdminApi } from "@/lib/server/auth";
import { listInquiries, createTestInquiry } from "@/lib/server/inquiries";
export async function GET() {
  return api(async () => {
    await requireAdminApi();
    return json(await listInquiries());
  });
}
export async function POST(request: Request) {
  return api(async () => {
    const auth = await requireAdminApi(request);
    const result = await createTestInquiry(
      await readJson(request),
      request.headers.get("idempotency-key"),
      auth.adminId,
    );
    return json(
      {
        ...result,
        isTest: true,
        message:
          "Тестовая заявка записана в локальную БД. Уведомления не отправлялись.",
      },
      result.duplicate ? 200 : 201,
    );
  });
}
