import { api, json, readJson } from "@/lib/server/http";
import { requireAdminApi } from "@/lib/server/auth";
import { listInquiries } from "@/lib/server/inquiries";
export async function POST(request: Request) {
  return api(async () => {
    await requireAdminApi(request);
    return json(await listInquiries(await readJson(request)));
  });
}
