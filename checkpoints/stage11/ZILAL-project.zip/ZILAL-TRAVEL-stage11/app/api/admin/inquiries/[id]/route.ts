import { api, json, readJson } from "@/lib/server/http";
import { requireAdminApi } from "@/lib/server/auth";
import { inquiryDetails, updateInquiry } from "@/lib/server/inquiries";
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    await requireAdminApi();
    return json(await inquiryDetails((await params).id));
  });
}
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    const auth = await requireAdminApi(request);
    return json(
      await updateInquiry(
        (await params).id,
        await readJson(request),
        auth.adminId,
      ),
    );
  });
}
