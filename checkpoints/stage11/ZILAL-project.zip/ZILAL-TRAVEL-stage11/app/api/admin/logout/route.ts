import { api, json } from "@/lib/server/http";
import { requireAdminApi, logoutAdmin, cookieOptions } from "@/lib/server/auth";
import { originConfig } from "@/lib/admin/security";
export async function POST(request: Request) {
  return api(async () => {
    const auth = await requireAdminApi(request);
    await logoutAdmin(auth);
    const response = json({ loggedOut: true });
    response.cookies.set(originConfig().cookieName, "", {
      ...cookieOptions(),
      maxAge: 0,
      expires: new Date(0),
    });
    return response;
  });
}
