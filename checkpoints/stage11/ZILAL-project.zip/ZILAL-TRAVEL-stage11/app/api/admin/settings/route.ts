import { api, json, readJson } from "@/lib/server/http";
import { requireAdminApi } from "@/lib/server/auth";
import { readSettings, saveSetting } from "@/lib/server/settings";
export async function GET() {
  return api(async () => {
    await requireAdminApi();
    return json(await readSettings());
  });
}
export async function PATCH(request: Request) {
  return api(async () => {
    const auth = await requireAdminApi(request);
    return json(await saveSetting(await readJson(request), auth.adminId));
  });
}
