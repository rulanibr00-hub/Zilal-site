import { api, json } from "@/lib/server/http";
import { requireAdminApi } from "@/lib/server/auth";
export async function GET() {
  return api(async () => {
    const auth = await requireAdminApi();
    return json({
      authenticated: true,
      csrf: auth.csrf,
      expiresAt: auth.expiresAt,
    });
  });
}
