import { api,json,readJson } from '@/lib/server/http';
import { requireAdminApi } from '@/lib/server/auth';
import { contentState,contentCommand } from '@/lib/server/cms';
export async function GET(r:Request){return api(async()=>{await requireAdminApi();return json(await contentState(new URL(r.url).searchParams.get('key')??undefined));});}
export async function POST(r:Request){return api(async()=>{const a=await requireAdminApi(r);return json(await contentCommand(await readJson(r),a.adminId));});}
