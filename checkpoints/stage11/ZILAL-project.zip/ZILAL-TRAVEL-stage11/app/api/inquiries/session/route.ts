import { api, json, readJson, HttpError } from "@/lib/server/http";
import {
  createPublicSession,
  publicCookie,
} from "@/lib/server/public-inquiries";
export async function POST(request: Request) {
  return api(async () => {
    const session = await createPublicSession(request);
    const body = await readJson(request);
    if (
      !body ||
      typeof body !== "object" ||
      Array.isArray(body) ||
      Object.keys(body).length
    )
      throw new HttpError(400, "Некорректный запрос формы.");
    const response = json({
      csrf: session.csrf,
      policyRevision: session.policyRevision,
    });
    response.cookies.set(publicCookie(), session.nonce, session.cookieOptions);
    return response;
  });
}
