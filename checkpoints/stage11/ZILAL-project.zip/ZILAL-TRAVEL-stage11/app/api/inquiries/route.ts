import { api, json, readJson } from "@/lib/server/http";
import { acceptPublicInquiry } from "@/lib/server/public-inquiries";
export async function POST(request: Request) {
  return api(async () => {
    const result = await acceptPublicInquiry(request, () => readJson(request));
    return json(result, result.duplicate ? 200 : 201);
  });
}
