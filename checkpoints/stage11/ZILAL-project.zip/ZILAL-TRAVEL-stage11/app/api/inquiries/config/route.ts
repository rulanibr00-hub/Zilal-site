import { json } from "@/lib/server/http";
import { inquiryConfiguration } from "@/lib/inquiries/policy";
export const dynamic = "force-dynamic";
export async function GET() {
  return json(inquiryConfiguration().public);
}
