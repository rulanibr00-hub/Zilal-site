import { z } from 'zod';import { sql } from 'drizzle-orm';
import { api,json,privateHeaders } from '@/lib/server/http';import { currentAdmin } from '@/lib/server/auth';import { database } from '@/lib/server/db';
export const dynamic='force-dynamic';
export async function GET(r:Request,{params}:{params:Promise<{id:string}>}){return api(async()=>{const {id}=await params;if(!z.uuid().safeParse(id).success)return json({error:'Не найдено'},404);
 const admin=await currentAdmin();const {db}=database();
 if(!admin){const visible=await db.execute(sql`SELECT 1 FROM cms_media_refs r JOIN cms_documents d ON d.key=r.document_key AND d.published_version=r.version WHERE r.media_id=${id} LIMIT 1`);if(!visible.rows.length)return json({error:'Не найдено'},404);}
 const thumbnail=new URL(r.url).searchParams.get('thumb')==='1';const result=await db.execute(sql`SELECT ${thumbnail?sql`thumbnail`:sql`bytes`} AS data FROM cms_media WHERE id=${id}`);if(!result.rows.length)return json({error:'Не найдено'},404);
 return new Response(new Uint8Array(result.rows[0].data as Buffer),{headers:{...privateHeaders,'Content-Type':'image/webp','X-Content-Type-Options':'nosniff','Content-Disposition':'inline; filename="image.webp"','Content-Security-Policy':"default-src 'none'; sandbox"}});
 });}
