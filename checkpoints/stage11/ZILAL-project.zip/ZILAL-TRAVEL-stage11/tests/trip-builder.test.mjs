import test from "node:test";
import assert from "node:assert/strict";
import {
  createTripDraft,
  estimatedEndDate,
  firstInvalidStep,
  formatTripDate,
  getBishkekToday,
  isCalendarDate,
  validateTripStep,
} from "../lib/trip-builder.ts";
import { exampleTours } from "../lib/data/tours.ts";
import { destinations } from "../lib/data/destinations.ts";
const context = {
  today: "2026-11-07",
  destinationIds: destinations.map((d) => d.id),
};
const valid = () => ({
  ...createTripDraft(),
  style: "combined",
  destinationIds: ["issyk-kul", "karakol"],
  activities: ["trekking", "gastronomy"],
  duration: "8",
  flexibleDates: false,
  startDate: "2027-05-15",
  adults: "2",
  children: "1",
  accommodation: "mixed",
  wishes: "Спокойный темп",
  name: "Путешественник",
  email: "traveler@example.com",
  phone: "+996 555 123 456",
});

test("new draft starts without assumed interests or accommodation and keeps contact fields empty", () => {
  const draft = createTripDraft();
  assert.equal(draft.style, "");
  assert.deepEqual(draft.destinationIds, []);
  assert.deepEqual(draft.activities, []);
  assert.equal(draft.duration, "");
  assert.equal(draft.accommodation, "");
  assert.equal(draft.name, "");
  assert.equal(draft.phone, "");
  assert.equal(draft.email, "");
  assert.equal(draft.flexibleDates, true);
});
test("catalog seed transfers exact preferences without mutating the source tour", () => {
  for (const seed of exampleTours) {
    const draft = createTripDraft(seed);
    assert.equal(draft.style, seed.style);
    assert.equal(draft.duration, String(seed.durationDays));
    assert.deepEqual(draft.destinationIds, seed.destinationIds);
    assert.notEqual(draft.destinationIds, seed.destinationIds);
    assert.equal(draft.accommodation, "");
    assert.equal(draft.name, "");
    if (seed.activities.includes("culture"))
      assert.ok(draft.activities.includes("culture"));
    if (seed.activities.includes("trekking"))
      assert.ok(draft.activities.includes("trekking"));
    assert.ok(
      !draft.activities.includes("jeep"),
      "Panoramic drives do not imply jeep tours",
    );
    draft.destinationIds.pop();
    assert.ok(seed.destinationIds.length > 0);
  }
});
test("each required choice prevents skipping its step", () => {
  const draft = createTripDraft();
  assert.ok(validateTripStep(draft, 0, context).style);
  assert.ok(validateTripStep(draft, 1, context).destinationIds);
  assert.ok(validateTripStep(draft, 2, context).activities);
  assert.ok(validateTripStep(draft, 4, context).accommodation);
  assert.ok(
    validateTripStep({ ...valid(), destinationIds: ["unknown"] }, 1, context)
      .destinationIds,
  );
  assert.ok(
    validateTripStep({ ...valid(), activities: ["unknown"] }, 2, context)
      .activities,
  );
});
test("valid complete draft passes all six steps; rechecking finds the first invalid earlier step", () => {
  const draft = valid();
  for (let i = 0; i < 6; i++)
    assert.deepEqual(validateTripStep(draft, i, context), {});
  assert.equal(firstInvalidStep(draft, context), undefined);
  assert.equal(
    firstInvalidStep({ ...draft, destinationIds: [] }, context).step,
    1,
  );
  assert.equal(firstInvalidStep({ ...draft, style: "" }, context).step, 0);
  assert.equal(
    firstInvalidStep({ ...draft, email: "" }, context, 4),
    undefined,
  );
});
test("logistics rejects fractional counts, missing values and out-of-range groups", () => {
  for (const duration of ["", "0", "61", "2.5", "1e1", "-2"])
    assert.ok(
      validateTripStep({ ...valid(), duration }, 3, context).duration,
      duration,
    );
  for (const adults of ["", "0", "21", "1.5"])
    assert.ok(
      validateTripStep({ ...valid(), adults }, 3, context).adults,
      adults,
    );
  for (const children of ["", "-1", "21", "0.5"])
    assert.ok(
      validateTripStep({ ...valid(), children }, 3, context).children,
      children,
    );
  assert.deepEqual(
    validateTripStep(
      { ...valid(), duration: "60", adults: "20", children: "0" },
      3,
      context,
    ),
    {},
  );
});
test("flexible dates allow no date; selected dates must be real and not in the past", () => {
  assert.deepEqual(
    validateTripStep(
      { ...valid(), flexibleDates: true, startDate: "" },
      3,
      context,
    ),
    {},
  );
  for (const startDate of [
    "",
    "2026-02-30",
    "2026-11-06",
    "2027-13-01",
    "07.11.2027",
  ])
    assert.ok(
      validateTripStep({ ...valid(), startDate }, 3, context).startDate,
      startDate,
    );
  assert.deepEqual(
    validateTripStep({ ...valid(), startDate: context.today }, 3, context),
    {},
  );
});
test("contacts reject whitespace, malformed email and incomplete telephone numbers", () => {
  const errors = validateTripStep(
    { ...valid(), name: "   ", email: "wrong@", phone: "123" },
    5,
    context,
  );
  assert.ok(errors.name);
  assert.ok(errors.email);
  assert.ok(errors.phone);
  for (const phone of [
    "+123",
    "+00000000000",
    "+1234567890123456",
    "call me",
    "+996 555 ext 12",
  ])
    assert.ok(validateTripStep({ ...valid(), phone }, 5, context).phone, phone);
  assert.deepEqual(
    validateTripStep(
      {
        ...valid(),
        name: " Тест ",
        email: " traveler@example.com ",
        phone: " +44 (20) 1234-5678 ",
      },
      5,
      context,
    ),
    {},
  );
});
test("wishes can be empty but oversized input is rejected", () => {
  assert.deepEqual(
    validateTripStep({ ...valid(), wishes: "" }, 4, context),
    {},
  );
  assert.ok(
    validateTripStep({ ...valid(), wishes: "x".repeat(2001) }, 4, context)
      .wishes,
  );
});
test("estimated end date counts travel days inclusively and handles leap years", () => {
  assert.equal(estimatedEndDate("2028-02-28", "3"), "2028-03-01");
  assert.equal(estimatedEndDate("2027-12-31", "2"), "2028-01-01");
  assert.equal(estimatedEndDate("2027-05-15", "1"), "2027-05-15");
  assert.equal(estimatedEndDate("invalid", "8"), undefined);
  assert.equal(estimatedEndDate("2027-05-15", "0"), undefined);
  assert.equal(isCalendarDate("2027-02-29"), false);
  assert.equal(isCalendarDate("2028-02-29"), true);
  assert.match(formatTripDate("2027-05-15"), /15 мая 2027/);
});
test("today follows Asia/Bishkek at the UTC day boundary", () => {
  assert.equal(getBishkekToday(new Date("2026-11-07T20:30:00Z")), "2026-11-08");
  assert.equal(getBishkekToday(new Date("2026-11-07T10:30:00Z")), "2026-11-07");
});
