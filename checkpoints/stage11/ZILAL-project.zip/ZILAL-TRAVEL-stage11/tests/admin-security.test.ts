import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import {
  randomToken,
  hashToken,
  csrfFor,
  equalToken,
  hashPassword,
  verifyPassword,
  validateNewPassword,
  originConfig,
} from "../lib/admin/security";
test("opaque session token, database digest and CSRF are distinct and unpredictable", () => {
  const token = randomToken();
  assert.equal(token.length, 64);
  assert.notEqual(token, randomToken());
  assert.equal(hashToken(token).length, 64);
  assert.notEqual(hashToken(token), token);
  assert.notEqual(csrfFor(token), token);
  assert.notEqual(csrfFor(token), hashToken(token));
  assert.ok(equalToken(csrfFor(token), csrfFor(token)));
  assert.equal(equalToken("x", csrfFor(token)), false);
});
test("Argon2id verifies only the correct randomly generated password", async () => {
  const secret = randomBytes(32).toString("base64url");
  const hash = await hashPassword(secret);
  assert.match(hash, /^\$argon2id\$v=19\$m=65536,t=3,p=1\$/);
  assert.equal(await verifyPassword(hash, secret), true);
  assert.equal(await verifyPassword(hash, randomToken()), false);
  assert.equal(await verifyPassword("invalid", secret), false);
  assert.ok(validateNewPassword(secret));
  assert.equal(validateNewPassword("short"), false);
  assert.equal(validateNewPassword(" ".repeat(20)), false);
});
test("HTTPS uses a host cookie; HTTP is allowed only for loopback origins", () => {
  const old = process.env.ADMIN_ORIGIN;
  try {
    process.env.ADMIN_ORIGIN = "https://admin.example.org";
    assert.deepEqual(originConfig(), {
      origin: "https://admin.example.org",
      local: false,
      secure: true,
      cookieName: "__Host-zilal-admin",
    });
    process.env.ADMIN_ORIGIN = "http://localhost:3000";
    assert.equal(originConfig().secure, false);
    for (const invalid of [
      "http://remote.example.org",
      "https://user:secret@example.org",
      "https://example.org/path",
      "https://example.org?q=1",
    ]) {
      process.env.ADMIN_ORIGIN = invalid;
      assert.throws(originConfig);
    }
  } finally {
    if (old === undefined) delete process.env.ADMIN_ORIGIN;
    else process.env.ADMIN_ORIGIN = old;
  }
});
