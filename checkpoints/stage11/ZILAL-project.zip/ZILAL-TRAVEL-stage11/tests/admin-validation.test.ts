import test from "node:test";
import assert from "node:assert/strict";
import {
  inquirySchema,
  settingSchema,
  searchSchema,
  updateInquirySchema,
  loginSchema,
} from "../lib/admin/contracts";
const base = { name: "Тестовая запись", email: "local-test@example.invalid" };
test("three intake sources have strict bounded shapes", () => {
  assert.equal(
    inquirySchema.safeParse({
      ...base,
      source: "home",
      details: { message: "" },
    }).success,
    true,
  );
  assert.equal(
    inquirySchema.safeParse({
      ...base,
      source: "contacts",
      details: { message: " " },
    }).success,
    false,
  );
  assert.equal(
    inquirySchema.safeParse({
      ...base,
      name: " ",
      source: "home",
      details: { message: "" },
    }).success,
    false,
  );
  assert.equal(
    inquirySchema.safeParse({
      ...base,
      source: "home",
      details: { message: "x".repeat(2001) },
    }).success,
    false,
  );
  assert.equal(
    inquirySchema.safeParse({
      ...base,
      source: "home",
      details: { message: "" },
      status: "completed",
    }).success,
    false,
  );
  assert.equal(
    inquirySchema.safeParse({
      ...base,
      source: "contacts",
      details: { message: "\u0000" },
    }).success,
    false,
  );
});
test("builder rejects missing fields, unknown places and fractional counts", () => {
  const data = {
    ...base,
    source: "builder",
    phone: "+996555000000",
    details: {
      style: "combined",
      destinationIds: ["issyk-kul"],
      activities: ["culture"],
      duration: 7,
      flexibleDates: true,
      startDate: "",
      adults: 2,
      children: 0,
      accommodation: "advice",
      wishes: "",
      contactMethod: "whatsapp",
    },
  };
  assert.equal(inquirySchema.safeParse(data).success, true);
  for (const change of [
    { destinationIds: ["unknown"] },
    { activities: [] },
    { duration: 1.5 },
    { adults: 0 },
    { children: 21 },
    { wishes: "x".repeat(2001) },
  ])
    assert.equal(
      inquirySchema.safeParse({
        ...data,
        details: { ...data.details, ...change },
      }).success,
      false,
    );
});
test("settings cannot contain secrets or enable unconfigured integrations", () => {
  assert.equal(
    settingSchema.safeParse({ key: "telegram_token", value: "secret" }).success,
    false,
  );
  assert.equal(
    settingSchema.safeParse({
      key: "notifications",
      value: { emailEnabled: false, telegramEnabled: true, events: [] },
    }).success,
    false,
  );
  assert.equal(
    settingSchema.safeParse({
      key: "contacts",
      value: {
        phone: "",
        whatsapp: "",
        email: "",
        address: "",
        hours: "",
        token: "secret",
      },
    }).success,
    false,
  );
  assert.equal(
    settingSchema.safeParse({
      key: "notifications",
      value: {
        emailEnabled: false,
        telegramEnabled: false,
        events: ["inquiry.created"],
      },
    }).success,
    true,
  );
});
test("search, status edits and login are bounded and reject extra fields", () => {
  assert.equal(
    searchSchema.safeParse({ query: "x".repeat(101) }).success,
    false,
  );
  assert.equal(searchSchema.safeParse({ page: 0 }).success, false);
  assert.equal(
    updateInquirySchema.safeParse({
      status: "invented",
      internalNote: "",
      expectedUpdatedAt: new Date().toISOString(),
    }).success,
    false,
  );
  assert.equal(
    loginSchema.safeParse({ login: "", password: "" }).success,
    false,
  );
  assert.equal(
    loginSchema.safeParse({ login: "somebody", password: "value", admin: true })
      .success,
    false,
  );
});

test("existing form and trip draft adapters produce the unified server payload without mutating drafts", async () => {
  const { inquiryFormPayload, tripDraftPayload } =
    await import("../lib/admin/inquiry-payload");
  const { createTripDraft } = await import("../lib/trip-builder");
  assert.equal(
    inquirySchema.safeParse(
      inquiryFormPayload("contacts", { ...base, message: "Локальный тест" }),
    ).success,
    true,
  );
  const draft = {
    ...createTripDraft(),
    style: "combined" as const,
    destinationIds: ["issyk-kul" as const],
    activities: ["culture" as const],
    duration: "7",
    accommodation: "advice" as const,
    ...base,
    phone: "+996555000000",
  };
  const snapshot = structuredClone(draft);
  const payload = tripDraftPayload(draft, "issyk-kul-slow");
  assert.equal(inquirySchema.safeParse(payload).success, true);
  assert.equal(payload.details.duration, 7);
  assert.deepEqual(draft, snapshot);
});
