import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import {
  encryptToken,
  decryptToken,
  externalKeyPath,
} from "../lib/telegram/crypto";
import { TelegramClient } from "../lib/telegram/client";
import {
  chatSchema,
  TelegramError,
  actionSchema,
} from "../lib/telegram/contracts";
import { inquiryMessage } from "../lib/telegram/store";
const mockChat = () => String(100000 + randomBytes(4).readUInt32BE());
const mockToken = () =>
  `${100000 + randomBytes(3).readUIntBE(0, 3)}:${randomBytes(30).toString("base64url")}`;
test("authenticated encryption binds ciphertext to bot and supports previous key IDs", () => {
  const ring = {
    activeKeyId: "new",
    keys: {
      new: randomBytes(32).toString("base64"),
      old: randomBytes(32).toString("base64"),
    },
  };
  const token = mockToken(),
    id = randomUUID();
  const saved = encryptToken(token, id, ring);
  assert.ok(!JSON.stringify(saved).includes(token));
  assert.ok(decryptToken(saved, id, ring) === token);
  assert.throws(() => decryptToken(saved, randomUUID(), ring));
  assert.throws(() =>
    decryptToken(
      { ...saved, ciphertext: Buffer.from("damaged").toString("base64") },
      id,
      ring,
    ),
  );
  const old = encryptToken(token, id, { ...ring, activeKeyId: "old" });
  assert.ok(decryptToken(old, id, ring) === token);
  assert.throws(() => externalKeyPath(process.cwd() + "/key.json"));
});
test("Chat ID accepts signed numeric IDs, rejects phone syntax and invalid recipient payload", () => {
  for (const s of [
    "+996555000000",
    "@someone",
    "0",
    "1 2",
    "1.5",
    "9007199254740999",
  ])
    assert.equal(chatSchema.safeParse(s).success, false);
  const generated = String(100000 + randomBytes(4).readUInt32BE());
  assert.ok(chatSchema.safeParse(generated).success);
  assert.ok(chatSchema.safeParse("-" + generated).success);
  assert.equal(
    actionSchema.safeParse({
      action: "recipient.save",
      name: "Test",
      botId: randomUUID(),
      chatId: generated,
      enabled: true,
      token: "not-allowed",
    }).success,
    false,
  );
});
test("Telegram calls are POST, plaintext, timeout bounded and never expose raw remote errors", async () => {
  const token = mockToken();
  let calls = 0;
  const client = new TelegramClient(
    async (url, options) => {
      calls++;
      assert.ok(url.startsWith("https://api.telegram.org/bot"));
      assert.equal(options.method, "POST");
      assert.ok(options.signal);
      const body = JSON.parse(String(options.body));
      assert.equal(body.parse_mode, undefined);
      return Response.json({ ok: true, result: { message_id: 17 } });
    },
    () => true,
  );
  assert.equal(await client.send(token, mockChat(), "<untrusted>&text"), 17);
  assert.equal(calls, 1);
  const bad = new TelegramClient(
    async () =>
      Response.json(
        { ok: false, error_code: 401, description: token },
        { status: 401 },
      ),
    () => true,
  );
  await assert.rejects(
    () => bad.check(token),
    (e) =>
      e instanceof TelegramError &&
      e.code === "UNAUTHORIZED" &&
      !e.message.includes(token),
  );
});
test("429 carries retry-after, network and timeouts are sanitized; network is disabled by default", async () => {
  const token = mockToken();
  const client = new TelegramClient(
    async () =>
      Response.json(
        { ok: false, error_code: 429, parameters: { retry_after: 47 } },
        { status: 429 },
      ),
    () => true,
  );
  await assert.rejects(
    () => client.send(token, mockChat(), "test"),
    (e) => e instanceof TelegramError && e.retryable && e.retryAfter === 47,
  );
  const timeout = new TelegramClient(
    async () => {
      throw new DOMException(token, "TimeoutError");
    },
    () => true,
  );
  await assert.rejects(
    () => timeout.check(token),
    (e) =>
      e instanceof TelegramError &&
      e.code === "TIMEOUT" &&
      !e.message.includes(token),
  );
  const disabled = new TelegramClient(
    async () => {
      throw new Error("must not run");
    },
    () => false,
  );
  await assert.rejects(
    () => disabled.check(token),
    (e) => e instanceof TelegramError && e.code === "NETWORK_DISABLED",
  );
});
test("inquiry notifications allowlist only non-contact fields", () => {
  const row = {
    number: 6,
    source: "builder" as const,
    tourSlug: "issyk-kul-slow",
    createdAt: new Date(),
    status: "new" as const,
    isTest: true,
    name: "DO_NOT_SEND",
    email: "DO_NOT_SEND@example.invalid",
    phone: "DO_NOT_SEND",
    details: { wishes: "DO_NOT_SEND" },
  };
  const text = inquiryMessage(row, "inquiry.created");
  assert.ok(text.includes("ZL-000006"));
  assert.ok(!text.includes("DO_NOT_SEND"));
  assert.ok(!text.includes("http"));
});
