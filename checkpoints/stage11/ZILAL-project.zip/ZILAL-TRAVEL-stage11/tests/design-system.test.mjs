import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
const css = readFileSync(new URL("../app/polish.css", import.meta.url), "utf8");
const token = (name) => {
  const m = css.match(new RegExp("--" + name + ":\\s*(#[a-fA-F0-9]{6})"));
  assert.ok(m, name);
  return m[1];
};
function luminance(hex) {
  const c = hex
    .slice(1)
    .match(/../g)
    .map((n) => parseInt(n, 16) / 255)
    .map((n) => (n <= 0.04045 ? n / 12.92 : ((n + 0.055) / 1.055) ** 2.4));
  return c[0] * 0.2126 + c[1] * 0.7152 + c[2] * 0.0722;
}
function contrast(a, b) {
  const x = luminance(a),
    y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}
test("design tokens retain brand colors and readable body, muted and gold text", () => {
  assert.equal(token("green"), "#173d35");
  assert.equal(token("gold"), "#c9ad7d");
  assert.equal(token("cream"), "#f5f1e8");
  assert.equal(token("blue"), "#253d4b");
  for (const fg of ["green", "muted", "gold-ink"])
    assert.ok(contrast(token(fg), token("cream")) >= 4.5, fg);
  assert.ok(
    contrast(token("gold-heading"), token("cream")) >= 3,
    "Large editorial emphasis",
  );
});
test("buttons, focus and form boundaries meet their contrast targets", () => {
  assert.ok(
    contrast(token("green"), token("gold")) >= 4.5,
    "Gold button label",
  );
  assert.ok(
    contrast(token("cream"), token("green")) >= 4.5,
    "Green button label",
  );
  assert.ok(
    contrast(token("field-line"), token("cream")) >= 3,
    "Field boundary",
  );
  assert.ok(
    contrast(token("gold"), token("green")) >= 3,
    "Focus on dark surfaces",
  );
});
