import test from "node:test";
import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { photos, photoSizes, isDocumentedPhoto } from "../lib/media.ts";
import { destinations } from "../lib/data/destinations.ts";
import { catalogTours } from "../lib/data/tours.ts";
// Synthetic metadata fixture, not a licensed image or a production asset.
const fixture = {
  kind: "photo",
  label: "Тестовый кадр",
  alt: "Тестовый пейзаж",
  src: "/images/fixture.webp",
  width: 2400,
  height: 1600,
  author: "Тестовый автор",
  sourceUrl: "https://example.com/source",
  license: "Тестовая запись",
  licenseUrl: "https://example.com/license",
  verifiedOn: "2026-11-07",
};
test("each live media slot has descriptive text; every real photo needs documentation and an existing local file", () => {
  assert.equal(Object.keys(photos).length, 8);
  for (const [key, asset] of Object.entries(photos)) {
    assert.ok(asset.label.trim(), key);
    assert.ok(asset.alt.trim().length > 15, key);
    if (asset.kind === "photo") {
      assert.equal(isDocumentedPhoto(asset), true, key);
      assert.ok(
        existsSync(resolve("public", asset.src.slice(1))),
        `Missing file ${key}`,
      );
    }
  }
  for (const destination of destinations)
    assert.ok(photos[destination.image], destination.id);
  for (const tour of catalogTours) {
    assert.ok(photos[tour.image], tour.slug);
    for (const key of tour.gallery) assert.ok(photos[key], key);
  }
});
test("documentation rejects missing attribution, empty alt and unsafe source/image paths", () => {
  assert.equal(isDocumentedPhoto(fixture), true);
  for (const invalid of [
    { alt: "" },
    { author: "" },
    { license: "" },
    { verifiedOn: "2026-02-30" },
    { sourceUrl: "javascript:alert(1)" },
    { src: "/images/../private.jpg" },
    { width: 0 },
    { focalPoint: { x: 101, y: 50 } },
    { mobileFocalPoint: { x: 50, y: -1 } },
  ])
    assert.equal(
      isDocumentedPhoto({ ...fixture, ...invalid }),
      false,
      JSON.stringify(invalid),
    );
  const missing = { ...fixture };
  delete missing.alt;
  assert.equal(isDocumentedPhoto(missing), false);
  assert.equal(
    isDocumentedPhoto(photos.hero),
    false,
    "Illustrations are never represented as photos",
  );
});
test("image placements have distinct responsive requests for hero, cards, thumbnails and editorial frames", () => {
  assert.equal(photoSizes.hero, "100vw");
  assert.match(photoSizes.card, /760px/);
  assert.match(photoSizes.thumbnail, /180px/);
  assert.notEqual(photoSizes.thumbnail, photoSizes.gallery);
  assert.notEqual(photoSizes.card, photoSizes.editorial);
});
