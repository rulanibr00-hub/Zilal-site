import test from "node:test";
import assert from "node:assert/strict";
import { filterTours, defaultFilters, daysLabel } from "../lib/tour-catalog.ts";
import {
  exampleTours,
  catalogTours,
  getTourBySlug,
  tours,
} from "../lib/data/tours.ts";
import { destinations } from "../lib/data/destinations.ts";
const slugs = (list) => list.map((t) => t.slug);

test("example routes are complete, explicitly examples and reference actual destinations", () => {
  assert.equal(exampleTours.length, 5);
  assert.equal(tours.length, 0, "No invented real offers");
  assert.equal(new Set(exampleTours.map((t) => t.id)).size, 5);
  assert.equal(new Set(slugs(exampleTours)).size, 5);
  const ids = new Set(destinations.map((d) => d.id));
  for (const tour of exampleTours) {
    assert.equal(tour.status, "example");
    assert.equal(tour.itinerary.length, tour.durationDays);
    assert.deepEqual(
      tour.itinerary.map((d) => d.day),
      Array.from({ length: tour.durationDays }, (_, i) => i + 1),
    );
    assert.ok(tour.destinationIds.every((id) => ids.has(id)));
    assert.ok(tour.gallery.length >= 3);
    assert.ok(tour.services.proposed.length > 0);
    assert.ok(tour.difficultyNote.ru.length > 0);
    assert.equal(getTourBySlug(tour.slug)?.id, tour.id);
  }
  assert.equal(getTourBySlug("non-existent-tour"), undefined);
});

test("style is exact: combined format remains an independent choice", () => {
  assert.deepEqual(
    slugs(filterTours(catalogTours, { ...defaultFilters, style: "comfort" })),
    ["issyk-kul-slow", "karakol-culture-and-valleys"],
  );
  assert.deepEqual(
    slugs(filterTours(catalogTours, { ...defaultFilters, style: "adventure" })),
    ["son-kul-open-sky", "ala-kul-high-trails"],
  );
  assert.deepEqual(
    slugs(filterTours(catalogTours, { ...defaultFilters, style: "combined" })),
    ["kyrgyzstan-comfort-adventure"],
  );
});

test("duration ranges match the catalog labels", () => {
  assert.deepEqual(
    slugs(filterTours(catalogTours, { ...defaultFilters, duration: "short" })),
    ["issyk-kul-slow", "son-kul-open-sky"],
  );
  assert.deepEqual(
    slugs(filterTours(catalogTours, { ...defaultFilters, duration: "week" })),
    ["karakol-culture-and-valleys", "ala-kul-high-trails"],
  );
  assert.deepEqual(
    slugs(filterTours(catalogTours, { ...defaultFilters, duration: "long" })),
    ["kyrgyzstan-comfort-adventure"],
  );
  const fixtures = [5, 6, 8, 9, null].map((durationDays, i) => ({
    ...exampleTours[0],
    id: String(i),
    durationDays,
  }));
  assert.deepEqual(
    filterTours(fixtures, { ...defaultFilters, duration: "week" }).map(
      (t) => t.durationDays,
    ),
    [6, 8],
  );
  assert.deepEqual(
    filterTours(fixtures, { ...defaultFilters, duration: "long" }).map(
      (t) => t.durationDays,
    ),
    [9],
  );
  assert.equal(filterTours(fixtures, defaultFilters).length, 5);
});

test("style, duration and activity combine using AND; reset restores all", () => {
  assert.deepEqual(
    slugs(
      filterTours(catalogTours, {
        style: "adventure",
        duration: "week",
        activity: "trekking",
      }),
    ),
    ["ala-kul-high-trails"],
  );
  assert.equal(
    filterTours(catalogTours, {
      style: "comfort",
      duration: "long",
      activity: "trekking",
    }).length,
    0,
  );
  assert.equal(filterTours(catalogTours, defaultFilters).length, 5);
});

test("drafts never leak into public filtering", () => {
  const draft = { ...exampleTours[0], status: "draft" };
  const approved = { ...exampleTours[1], status: "published" };
  assert.deepEqual(slugs(filterTours([draft, approved], defaultFilters)), [
    approved.slug,
  ]);
});

test("Russian duration labels handle plurals and unknown duration", () => {
  assert.deepEqual([1, 2, 5, 11, 21, null].map(daysLabel), [
    "1 день",
    "2 дня",
    "5 дней",
    "11 дней",
    "21 день",
    "Сроки уточняются",
  ]);
});
