import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import {
  inspectInquiryPolicy,
  inquiryConfiguration,
} from "../lib/inquiries/policy";
import {
  approvalFileSchema,
  submissionSchema,
} from "../lib/inquiries/contracts";
const fixture = () => ({
  policy: {
    version: "local-test",
    operatorName: "Тестовый оператор",
    operatorAddress: "Локальная тестовая среда",
    contactEmail: "privacy@" + randomBytes(8).toString("hex") + ".com",
    purposes: ["Тестовая проверка приёма"],
    legalBasis: "Тестовое основание без реальных данных",
    retentionDays: 1,
    retentionExplanation: "Только на время автоматической проверки",
    recipients: [
      {
        name: "Изолированная тестовая БД",
        purpose: "Проверка сохранения обращений",
        location: "Локальный компьютер",
      },
    ],
    rights: "Тестовый порядок обработки обращений о данных",
    notice: "Тестовые параметры будут сохранены в отдельной локальной БД.",
    consentRequired: true,
    consentText: "Согласие только на локальную проверку тестовых данных.",
    updatedOn: new Date().toISOString().slice(0, 10),
  },
  approval: {
    confirmedBy: "Автоматический тест",
    confirmedAt: new Date().toISOString(),
    reference: "Локальная тестовая фикстура",
  },
});
test("intake fails closed without policy, approval or matching mode constraints", () => {
  const before = { ...process.env };
  const dir = mkdtempSync(join(tmpdir(), "zilal-policy-"));
  try {
    delete process.env.INQUIRY_POLICY_FILE;
    process.env.PUBLIC_INQUIRIES_ENABLED = "true";
    process.env.PUBLIC_INQUIRIES_TEST_MODE = "false";
    assert.equal(inquiryConfiguration().public.mode, "disabled");
    const file = join(dir, "policy.json");
    writeFileSync(file, JSON.stringify(fixture()));
    process.env.INQUIRY_POLICY_FILE = file;
    process.env.ADMIN_ORIGIN = "http://localhost:3000";
    process.env.DATABASE_URL = "postgresql://local@localhost/local_test";
    assert.equal(inquiryConfiguration().public.mode, "disabled");
    const checked = inspectInquiryPolicy();
    assert.ok(checked.valid);
    if (!checked.valid) return;
    process.env.PUBLIC_INQUIRIES_APPROVAL_SHA256 = checked.approvalHash;
    assert.equal(
      inquiryConfiguration().public.mode,
      "disabled",
      "live intake needs HTTPS",
    );
    process.env.PUBLIC_INQUIRIES_ENABLED = "false";
    process.env.PUBLIC_INQUIRIES_TEST_MODE = "true";
    process.env.ADMIN_TEST_INQUIRIES = "true";
    process.env.TELEGRAM_NETWORK_ENABLED = "false";
    assert.equal(inquiryConfiguration().public.mode, "test");
    process.env.TELEGRAM_NETWORK_ENABLED = "true";
    assert.equal(inquiryConfiguration().public.mode, "disabled");
    process.env.TELEGRAM_NETWORK_ENABLED = "false";
    process.env.DATABASE_URL = "postgresql://local@localhost/real_database";
    assert.equal(inquiryConfiguration().public.mode, "disabled");
    process.env.DATABASE_URL = "postgresql://local@localhost/local_test";
    const changed = fixture();
    changed.policy.retentionDays = 2;
    writeFileSync(file, JSON.stringify(changed));
    assert.equal(
      inquiryConfiguration().public.mode,
      "disabled",
      "policy edit invalidates approval",
    );
  } finally {
    process.env = before;
    rmSync(dir, { recursive: true, force: true });
  }
});
test("complete approved HTTPS policy can select live mode in isolated config validation only", () => {
  const before = { ...process.env };
  const dir = mkdtempSync(join(tmpdir(), "zilal-policy-live-"));
  try {
    const file = join(dir, "policy.json");
    writeFileSync(file, JSON.stringify(fixture()));
    process.env.INQUIRY_POLICY_FILE = file;
    process.env.ADMIN_ORIGIN = "https://site.example.org";
    process.env.DATABASE_URL =
      "postgresql://unused@localhost/config_validation_only";
    process.env.PUBLIC_INQUIRIES_ENABLED = "true";
    process.env.PUBLIC_INQUIRIES_TEST_MODE = "false";
    const p = inspectInquiryPolicy();
    assert.ok(p.valid);
    if (!p.valid) return;
    process.env.PUBLIC_INQUIRIES_APPROVAL_SHA256 = p.approvalHash;
    assert.equal(inquiryConfiguration().public.mode, "live");
    delete process.env.PUBLIC_INQUIRIES_APPROVAL_SHA256;
    assert.equal(inquiryConfiguration().public.mode, "disabled");
  } finally {
    process.env = before;
    rmSync(dir, { recursive: true, force: true });
  }
});
test("empty policy and unknown submission fields cannot activate or widen intake", () => {
  assert.equal(
    approvalFileSchema.safeParse({ policy: {}, approval: {} }).success,
    false,
  );
  assert.equal(
    submissionSchema.safeParse({
      inquiry: {},
      policyRevision: "x",
      consent: true,
      website: "",
    }).success,
    false,
  );
  assert.equal(
    submissionSchema.safeParse({
      inquiry: {},
      policyRevision: "a".repeat(64),
      consent: true,
      website: "",
      isTest: false,
    }).success,
    false,
  );
});
