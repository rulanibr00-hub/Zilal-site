import "./environment";
import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import { spawnSync } from "node:child_process";
import { createDatabase } from "../lib/db/connection";
import { originConfig } from "../lib/admin/security";
let stage = "guard";
async function run() {
  const dbUrl = new URL(process.env.DATABASE_URL ?? "");
  const config = originConfig();
  assert.ok(
    config.local &&
      ["localhost", "127.0.0.1", "[::1]"].includes(dbUrl.hostname) &&
      /^[\w-]+_test$/.test(dbUrl.pathname.slice(1)) &&
      process.env.TELEGRAM_NETWORK_ENABLED !== "true",
  );
  const { pool } = createDatabase();
  let owned = false,
    checks = 0;
  const check = (value: boolean) => {
    assert.ok(value);
    checks++;
  };
  let cookie = "",
    csrf = "";
  async function call(
    method: string,
    body?: unknown,
    headers: Record<string, string> = {},
  ) {
    return fetch(config.origin + "/api/admin/telegram", {
      method,
      headers: {
        Origin: config.origin,
        "Content-Type": "application/json",
        Cookie: cookie,
        "X-CSRF-Token": csrf,
        ...headers,
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
  }
  try {
    const empty = await pool.query(
      "SELECT (SELECT count(*) FROM admin_users)+(SELECT count(*) FROM inquiries)+(SELECT count(*) FROM site_settings)+(SELECT count(*) FROM admin_audit_logs)+(SELECT count(*) FROM admin_sessions)+(SELECT count(*) FROM rate_limits)+(SELECT count(*) FROM telegram_bots)+(SELECT count(*) FROM telegram_jobs) n",
    );
    check(Number(empty.rows[0].n) === 0);
    owned = true;
    check((await call("GET")).status === 401);
    check((await call("POST", {})).status === 401);
    const creds = {
      login: "http_" + randomBytes(8).toString("hex"),
      password: randomBytes(32).toString("base64url"),
    };
    const cli = spawnSync(
      process.execPath,
      ["--import", "tsx", "scripts/init-admin.ts", "--stdin"],
      { env: process.env, input: JSON.stringify(creds), encoding: "utf8" },
    );
    check(cli.status === 0);
    const login = await fetch(config.origin + "/api/admin/login", {
      method: "POST",
      headers: { Origin: config.origin, "Content-Type": "application/json" },
      body: JSON.stringify(creds),
    });
    check(login.status === 200);
    cookie = login.headers.get("set-cookie")!.split(";")[0];
    csrf = (await login.json()).csrf;
    stage = "guards";
    check((await call("POST", {}, { "X-CSRF-Token": "" })).status === 403);
    check(
      (await call("POST", {}, { Origin: "https://attacker.invalid" }))
        .status === 403,
    );
    check(
      (await call("POST", {}, { "Content-Type": "text/plain" })).status === 415,
    );
    stage = "create-read-no-secrets";
    const token = `${randomBytes(4).readUInt32BE() + 100000}:${randomBytes(30).toString("base64url")}`;
    check(
      (
        await call("POST", {
          action: "bot.create",
          name: "Локальный HTTP-тест",
          token,
        })
      ).status === 200,
    );
    const stateResponse = await call("GET");
    check(
      stateResponse.headers.get("cache-control")?.includes("no-store") === true,
    );
    const state = await stateResponse.json();
    const bot = state.bots[0];
    check(
      state.bots.length === 1 &&
        !JSON.stringify(state).includes(token) &&
        !("encryptedToken" in bot),
    );
    check(
      (
        await call("POST", {
          action: "bot.create",
          name: "Ошибка",
          token: "invalid",
        })
      ).status === 400,
    );
    check(
      (await call("POST", { action: "bot.check", id: bot.id })).status === 503,
    );
    check(
      (
        await call("POST", {
          action: "bot.update",
          id: bot.id,
          name: bot.name,
          enabled: true,
        })
      ).status === 400,
    );
    stage = "recipients";
    check(
      (
        await call("POST", {
          action: "recipient.save",
          botId: bot.id,
          name: "Ошибка",
          chatId: "+996 555",
          enabled: true,
        })
      ).status === 400,
    );
    const chatId = String(randomBytes(4).readUInt32BE() + 100000);
    check(
      (
        await call("POST", {
          action: "recipient.save",
          botId: bot.id,
          name: "Локальный получатель",
          chatId,
          enabled: false,
        })
      ).status === 200,
    );
    const populated = await (await call("GET")).json();
    const recipient = populated.recipients[0];
    check(
      (
        await call("POST", {
          action: "test.send",
          recipientId: recipient.id,
          requestId: randomUUID(),
        })
      ).status === 400,
    );
    check(
      (
        await call("POST", {
          action: "bot.delete",
          id: bot.id,
          confirmation: "wrong",
        })
      ).status === 400,
    );
    check(
      (
        await call("POST", {
          action: "bot.delete",
          id: bot.id,
          confirmation: bot.name,
        })
      ).status === 200,
    );
    const deleted = await (await call("GET")).json();
    check(deleted.bots.length === 0 && deleted.recipients.length === 0);
    check(
      (await fetch(config.origin + "/api/inquiries", { method: "POST" }))
        .status === 503,
    );
    console.log(
      `Telegram HTTP: ${checks} успешных проверок. Внешних запросов и сообщений нет.`,
    );
  } finally {
    if (owned) {
      await pool.query(
        "TRUNCATE telegram_jobs,telegram_routes,telegram_recipients,telegram_bots,telegram_worker,inquiries,admin_sessions,admin_audit_logs,site_settings,rate_limits,admin_users RESTART IDENTITY CASCADE",
      );
      await pool.query("UPDATE telegram_events SET enabled=false");
    }
    await pool.end();
  }
}
run().catch(() => {
  console.error(
    "Telegram HTTP-тест не пройден. Этап: " + stage + ". Секреты не выводятся.",
  );
  process.exitCode = 1;
});
