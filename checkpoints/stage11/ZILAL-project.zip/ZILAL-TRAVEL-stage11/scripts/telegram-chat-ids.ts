import "./environment";
import { createDatabase } from "../lib/db/connection";
import { telegramBots } from "../lib/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { decryptToken } from "../lib/telegram/crypto";
import { TelegramClient } from "../lib/telegram/client";
import { chatSchema, TelegramError } from "../lib/telegram/contracts";
async function run() {
  const id = process.argv[2];
  if (!z.uuid().safeParse(id).success) throw new Error();
  const client = new TelegramClient();
  client.ready();
  const { db, pool } = createDatabase();
  try {
    const [bot] = await db
      .select()
      .from(telegramBots)
      .where(eq(telegramBots.id, id));
    if (!bot) throw new Error();
    const updates = await client.call(
      decryptToken(bot.encryptedToken, bot.id),
      "getUpdates",
      { timeout: 0, limit: 100 },
    );
    if (!Array.isArray(updates)) throw new Error();
    const chats = new Map<string, string>();
    for (const update of updates) {
      const chat = update?.message?.chat ?? update?.my_chat_member?.chat;
      const parsed = chatSchema.safeParse(String(chat?.id));
      if (
        parsed.success &&
        ["private", "group", "supergroup"].includes(chat?.type)
      )
        chats.set(parsed.data, chat.type);
    }
    if (!chats.size)
      console.log(
        "Доступных Chat ID нет. Отправьте /start своему боту или команду в группе и повторите. Webhook и offset не менялись.",
      );
    for (const [chatId, type] of chats) console.log(`${type}: ${chatId}`);
  } finally {
    await pool.end();
  }
}
run().catch((e) => {
  console.error(
    e instanceof TelegramError
      ? e.message
      : "Chat ID не получены. Проверьте ID подключения, ключ и БД. Токен и тексты сообщений не выводятся.",
  );
  process.exitCode = 1;
});
