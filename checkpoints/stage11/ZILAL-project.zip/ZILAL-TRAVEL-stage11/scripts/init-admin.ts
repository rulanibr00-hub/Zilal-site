import "./environment";
import { stdin, stdout } from "node:process";
import { createInterface } from "node:readline/promises";
import { adminUsers, adminSessions, adminAuditLogs } from "../lib/db/schema";
import { createDatabase } from "../lib/db/connection";
import { hashPassword, validateNewPassword } from "../lib/admin/security";
import { loginSchema } from "../lib/admin/contracts";
function secret(prompt: string): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!stdin.isTTY) {
      reject(new Error("TTY_REQUIRED"));
      return;
    }
    stdout.write(prompt);
    stdin.setRawMode(true);
    stdin.resume();
    let value = "";
    const handler = (data: Buffer) => {
      for (const char of data.toString()) {
        if (char === "\u0003") {
          cleanup();
          reject(new Error("CANCELLED"));
          return;
        }
        if (char === "\r" || char === "\n") {
          cleanup();
          stdout.write("\n");
          resolve(value);
          return;
        }
        if (char === "\u007f" || char === "\b") value = value.slice(0, -1);
        else if (char >= " " && value.length < 129) value += char;
      }
    };
    function cleanup() {
      stdin.off("data", handler);
      stdin.setRawMode(false);
      stdin.pause();
    }
    stdin.on("data", handler);
  });
}
async function run() {
  const reset = process.argv.includes("--reset");
  let login: string, password: string;
  if (process.argv.includes("--stdin")) {
    let data = "";
    for await (const chunk of stdin) {
      data += chunk;
      if (Buffer.byteLength(data) > 8192) throw new Error("INPUT_TOO_LARGE");
    }
    ({ login, password } = JSON.parse(data));
  } else {
    if (!stdin.isTTY) throw new Error("TTY_REQUIRED");
    const rl = createInterface({ input: stdin, output: stdout });
    login = await rl.question(
      "Логин администратора (без значения по умолчанию): ",
    );
    rl.close();
    password = await secret("Пароль — не менее 16 символов (ввод скрыт): ");
    const confirmation = await secret("Повторите пароль: ");
    if (password !== confirmation) throw new Error("PASSWORD_MISMATCH");
  }
  const parsed = loginSchema.safeParse({ login, password });
  if (!parsed.success || !validateNewPassword(password))
    throw new Error("INVALID_CREDENTIALS");
  const passwordHash = await hashPassword(password);
  const { db, pool } = createDatabase();
  try {
    await db.transaction(async (tx) => {
      const users = await tx.select().from(adminUsers);
      if (reset) {
        if (users.length !== 1 || users[0].login !== parsed.data.login)
          throw new Error("ADMIN_NOT_FOUND");
        await tx.update(adminUsers).set({ passwordHash });
        await tx.delete(adminSessions);
        await tx
          .insert(adminAuditLogs)
          .values({ adminId: users[0].id, action: "admin_password_reset" });
      } else {
        if (users.length) throw new Error("ADMIN_EXISTS");
        const [user] = await tx
          .insert(adminUsers)
          .values({ login: parsed.data.login, passwordHash })
          .returning({ id: adminUsers.id });
        await tx
          .insert(adminAuditLogs)
          .values({ adminId: user.id, action: "admin_initialized" });
      }
    });
    console.log(
      reset
        ? "Пароль обновлён, все сессии отозваны."
        : "Единственный администратор создан. Войдите через /admin/login.",
    );
  } finally {
    await pool.end();
  }
}
run().catch((error) => {
  const code = error instanceof Error ? error.message : "";
  const messages: Record<string, string> = {
    ADMIN_EXISTS: "Администратор уже существует. Второй аккаунт не создаётся.",
    ADMIN_NOT_FOUND: "Для смены пароля укажите существующий логин.",
    INVALID_CREDENTIALS:
      "Нужен допустимый логин и пароль длиной 16–128 символов.",
    PASSWORD_MISMATCH: "Пароли не совпали.",
    TTY_REQUIRED:
      "Нужен интерактивный терминал. Для автоматизации предусмотрен --stdin с JSON через защищённый stdin.",
    CANCELLED: "Операция отменена.",
  };
  console.error(
    messages[code] ??
      "Инициализация не выполнена. Проверьте БД и миграции; секреты не выводятся.",
  );
  process.exitCode = 1;
});
