import "./environment";
import {
  inspectInquiryPolicy,
  inquiryConfiguration,
} from "../lib/inquiries/policy";
const result = inspectInquiryPolicy();
if (!result.valid) {
  console.error(
    "Политика не готова: " + result.reason + ". Значения полей не выводятся.",
  );
  process.exitCode = 1;
} else {
  console.log(
    "Документ структурно заполнен. Правдивость и правовое основание подтверждает владелец, не программа.",
  );
  console.log("PUBLIC_INQUIRIES_APPROVAL_SHA256=" + result.approvalHash);
  console.log("Версия политики: " + result.policyDigest);
  console.log("Текущий режим: " + inquiryConfiguration().public.mode);
}
