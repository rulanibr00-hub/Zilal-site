import "./environment";
import { spawnSync } from "node:child_process";
import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { createDatabase } from "../lib/db/connection";
import {
  adminUsers,
  telegramBots as bots,
  telegramRecipients as recipients,
  telegramJobs as jobs,
  rateLimits,
} from "../lib/db/schema";
import { TelegramStore } from "../lib/telegram/store";
import { TelegramClient } from "../lib/telegram/client";
import { processTelegramBatch } from "../lib/telegram/worker";
import { keyRing, decryptToken } from "../lib/telegram/crypto";
import { hashPassword } from "../lib/admin/security";
import {
  createTestInquiry,
  updateInquiry,
  inquiryDetails,
} from "../lib/server/inquiries";
import { database } from "../lib/server/db";
let stage = "guard";
async function run() {
  const url = new URL(process.env.DATABASE_URL ?? "");
  assert.ok(
    ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname) &&
      /^[\w-]+_test$/.test(url.pathname.slice(1)) &&
      process.env.ADMIN_TEST_INQUIRIES === "true" &&
      process.env.TELEGRAM_NETWORK_ENABLED !== "true",
  );
  keyRing();
  const { db, pool } = createDatabase();
  let owned = false,
    n = 0;
  const check = (v: unknown) => {
    assert.ok(v);
    n++;
  };
  const token = () =>
    `${100000 + randomBytes(4).readUInt32BE()}:${randomBytes(30).toString("base64url")}`;
  const chat = () => String(100000 + randomBytes(4).readUInt32BE());
  const secrets = [token(), token()];
  const badTokens = new Set<string>();
  const plans = new Map<string, string>();
  const sent: string[] = [];
  const client = new TelegramClient(
    async (url, options) => {
      const t = url.split("/bot")[1].split("/")[0];
      if (url.endsWith("/getMe")) {
        if (badTokens.has(t))
          return Response.json(
            { ok: false, error_code: 401, description: t },
            { status: 401 },
          );
        return Response.json({
          ok: true,
          result: {
            is_bot: true,
            id: t.split(":")[0],
            username: "mock_" + t.split(":")[0],
          },
        });
      }
      const body = JSON.parse(String(options.body));
      const plan = plans.get(body.chat_id);
      sent.push(body.text);
      if (plan === "429")
        return Response.json(
          {
            ok: false,
            error_code: 429,
            parameters: { retry_after: 47 },
            description: t,
          },
          { status: 429 },
        );
      if (plan === "400" || plan === "403")
        return Response.json(
          { ok: false, error_code: Number(plan), description: t },
          { status: Number(plan) },
        );
      if (plan === "network") throw new Error(t);
      return Response.json({ ok: true, result: { message_id: sent.length } });
    },
    () => true,
  );
  const store = new TelegramStore(db, client);
  const makeDue = async () => {
    await db.update(jobs).set({ runAt: new Date(0) });
    await db.update(bots).set({ nextSendAt: new Date(0) });
    await db.update(recipients).set({ nextSendAt: new Date(0) });
  };
  try {
    const empty = await pool.query(
      "SELECT (SELECT count(*) FROM admin_users)+(SELECT count(*) FROM inquiries)+(SELECT count(*) FROM site_settings)+(SELECT count(*) FROM admin_sessions)+(SELECT count(*) FROM admin_audit_logs)+(SELECT count(*) FROM rate_limits)+(SELECT count(*) FROM telegram_bots)+(SELECT count(*) FROM telegram_jobs) AS n",
    );
    check(Number(empty.rows[0].n) === 0);
    owned = true;
    const [admin] = await db
      .insert(adminUsers)
      .values({
        login: "test_" + randomBytes(8).toString("hex"),
        passwordHash: await hashPassword(randomBytes(32).toString("base64url")),
      })
      .returning({ id: adminUsers.id });
    const act = (v: unknown) => store.action(v, admin.id);
    stage = "bots";
    for (let i = 0; i < 2; i++)
      await act({
        action: "bot.create",
        name: `Мок-подключение ${i + 1}`,
        token: secrets[i],
      });
    let botRows = await db.select().from(bots).orderBy(bots.createdAt);
    check(botRows.length === 2);
    check(!JSON.stringify(await store.state()).includes("encryptedToken"));
    for (let i = 0; i < 2; i++) {
      check(!JSON.stringify(botRows[i].encryptedToken).includes(secrets[i]));
      check(
        decryptToken(botRows[i].encryptedToken, botRows[i].id) === secrets[i],
      );
    }
    badTokens.add(secrets[0]);
    await assert.rejects(() => act({ action: "bot.check", id: botRows[0].id }));
    check((await store.state()).bots[0].checkStatus === "error");
    const replacement = token();
    secrets.push(replacement);
    await act({
      action: "bot.update",
      id: botRows[0].id,
      name: botRows[0].name,
      enabled: false,
      token: replacement,
    });
    await act({ action: "bot.check", id: botRows[0].id });
    await act({ action: "bot.check", id: botRows[1].id });
    for (const bot of botRows)
      await act({
        action: "bot.update",
        id: bot.id,
        name: bot.name,
        enabled: true,
      });
    stage = "recipients";
    const chats = [chat(), "-" + chat(), chat()];
    for (let i = 0; i < 3; i++)
      await act({
        action: "recipient.save",
        botId: botRows[i === 2 ? 1 : 0].id,
        name: `Мок-получатель ${i + 1}`,
        chatId: chats[i],
        enabled: true,
      });
    const rs = await db.select().from(recipients).orderBy(recipients.name);
    check(rs.length === 3);
    await assert.rejects(() =>
      act({
        action: "recipient.save",
        botId: botRows[0].id,
        name: "Ошибка",
        chatId: "+123",
        enabled: true,
      }),
    );
    await assert.rejects(() =>
      act({
        action: "recipient.save",
        botId: botRows[0].id,
        name: "Повтор",
        chatId: chats[0],
        enabled: true,
      }),
    );
    await act({
      action: "routes.save",
      routes: [
        {
          event: "inquiry.created",
          enabled: true,
          recipientIds: [rs[0].id, rs[1].id],
        },
        {
          event: "inquiry.status_changed",
          enabled: true,
          recipientIds: [rs[0].id],
        },
        { event: "delivery.failed", enabled: true, recipientIds: [rs[2].id] },
      ],
    });
    stage = "outbox";
    const input = {
      source: "home",
      name: "Контакт не передавать",
      email: "private@example.invalid",
      details: { message: "Не передавать пожелания" },
    };
    const key = randomUUID();
    const created = await createTestInquiry(input, key, admin.id);
    await createTestInquiry(input, key, admin.id);
    check(
      Number(
        (await pool.query("SELECT count(*) FROM telegram_jobs")).rows[0].count,
      ) === 2,
    );
    const detail = await inquiryDetails(created.id);
    const updated = await updateInquiry(
      created.id,
      {
        status: "in_progress",
        internalNote: "Скрытая заметка",
        expectedUpdatedAt: detail.updatedAt.toISOString(),
      },
      admin.id,
    );
    await updateInquiry(
      created.id,
      {
        status: "in_progress",
        internalNote: "Изменение только заметки",
        expectedUpdatedAt: updated.updatedAt.toISOString(),
      },
      admin.id,
    );
    check(
      Number(
        (await pool.query("SELECT count(*) FROM telegram_jobs")).rows[0].count,
      ) === 3,
    );
    await db
      .update(rateLimits)
      .set({ count: 20 })
      .where(sql`${rateLimits.key} like 'test-intake:%'`);
    await assert.rejects(() =>
      createTestInquiry(input, randomUUID(), admin.id),
    );
    check(
      Number(
        (await pool.query("SELECT count(*) FROM inquiries")).rows[0].count,
      ) === 1,
    );
    check(
      Number(
        (await pool.query("SELECT count(*) FROM telegram_jobs")).rows[0].count,
      ) === 3,
    );
    for (let i = 0; i < 4; i++) {
      await makeDue();
      await processTelegramBatch(db, client);
    }
    check(
      Number(
        (
          await pool.query(
            "SELECT count(*) FROM telegram_jobs WHERE status='delivered'",
          )
        ).rows[0].count,
      ) === 3,
    );
    check(
      sent.every(
        (s) =>
          !s.includes(input.email) &&
          !s.includes(input.name) &&
          !s.includes(input.details.message) &&
          !s.includes("Скрытая заметка"),
      ),
    );
    const enqueueTest = async (id: string) => {
      const key = randomUUID();
      await act({ action: "test.send", recipientId: id, requestId: key });
      return (
        await db
          .select()
          .from(jobs)
          .where(eq(jobs.dedupeKey, "test:" + key))
      )[0];
    };
    stage = "retry429";
    const retry = await enqueueTest(rs[0].id);
    check(
      (
        await act({
          action: "test.send",
          recipientId: rs[0].id,
          requestId: retry.dedupeKey.slice(5),
        })
      ).message.includes("уже существует"),
    );
    await assert.rejects(() =>
      act({
        action: "test.send",
        recipientId: rs[1].id,
        requestId: retry.dedupeKey.slice(5),
      }),
    );
    check(true);
    plans.set(chats[0], "429");
    await makeDue();
    await processTelegramBatch(db, client);
    let [row] = await db.select().from(jobs).where(eq(jobs.id, retry.id));
    check(
      row.status === "retry" &&
        row.attempts === 1 &&
        row.runAt.getTime() >= Date.now() + 45000,
    );
    const attempts = sent.length;
    await processTelegramBatch(db, client);
    check(sent.length === attempts);
    plans.delete(chats[0]);
    await makeDue();
    await processTelegramBatch(db, client);
    [row] = await db.select().from(jobs).where(eq(jobs.id, retry.id));
    check(row.status === "delivered" && row.attempts === 2);
    stage = "failure-alert-no-loop";
    const badChat = await enqueueTest(rs[1].id);
    plans.set(chats[1], "400");
    plans.set(chats[2], "403");
    for (let i = 0; i < 3; i++) {
      await makeDue();
      await processTelegramBatch(db, client);
    }
    const [failed] = await db
      .select()
      .from(jobs)
      .where(eq(jobs.id, badChat.id));
    check(failed.status === "failed" && failed.errorCode === "BAD_REQUEST");
    check(
      Number(
        (
          await pool.query(
            "SELECT count(*) FROM telegram_jobs WHERE event='delivery.failed'",
          )
        ).rows[0].count,
      ) === 1,
    );
    stage = "bounded-retries";
    plans.set(chats[0], "network");
    const exhausted = await enqueueTest(rs[0].id);
    for (let i = 0; i < 5; i++) {
      await makeDue();
      await processTelegramBatch(db, client);
    }
    const [done] = await db
      .select()
      .from(jobs)
      .where(eq(jobs.id, exhausted.id));
    check(done.status === "failed" && done.attempts === 3);
    check(
      Number(
        (
          await pool.query(
            "SELECT count(*) FROM telegram_jobs WHERE event='delivery.failed'",
          )
        ).rows[0].count,
      ) === 2,
    );
    stage = "lease-recovery";
    plans.delete(chats[0]);
    const crashed = await enqueueTest(rs[0].id);
    await db
      .update(jobs)
      .set({
        status: "processing",
        attempts: 1,
        leaseId: randomUUID(),
        leaseUntil: new Date(0),
      })
      .where(eq(jobs.id, crashed.id));
    await makeDue();
    const second = createDatabase();
    try {
      await processTelegramBatch(second.db, client);
    } finally {
      await second.pool.end();
    }
    const [recovered] = await db
      .select()
      .from(jobs)
      .where(eq(jobs.id, crashed.id));
    check(recovered.status === "delivered" && recovered.attempts === 2);
    stage = "concurrent-workers";
    await enqueueTest(rs[0].id);
    await makeDue();
    let release!: (value: Response) => void;
    let started!: () => void;
    const entered = new Promise<void>((r) => {
      started = r;
    });
    const blocking = new TelegramClient(
      async () => {
        started();
        return new Promise<Response>((r) => {
          release = r;
        });
      },
      () => true,
    );
    const inFlight = processTelegramBatch(db, blocking, 1);
    await entered;
    const parallel = createDatabase();
    try {
      check(
        (await processTelegramBatch(parallel.db, client, 1)).processed === 0,
      );
    } finally {
      await parallel.pool.end();
    }
    release(Response.json({ ok: true, result: { message_id: 100 } }));
    check((await inFlight).processed === 1);
    stage = "disable-edit-delete";
    const cancelled = await enqueueTest(rs[0].id);
    await act({
      action: "bot.update",
      id: botRows[0].id,
      name: botRows[0].name,
      enabled: false,
    });
    const before = sent.length;
    await makeDue();
    await processTelegramBatch(db, client);
    check(sent.length === before);
    check(
      (await db.select().from(jobs).where(eq(jobs.id, cancelled.id)))[0]
        .status === "cancelled",
    );
    await act({
      action: "recipient.save",
      id: rs[0].id,
      botId: botRows[1].id,
      name: rs[0].name,
      chatId: chats[0],
      enabled: true,
    });
    check(
      !(await store.state()).routes.some((r) => r.recipientId === rs[0].id),
    );
    await assert.rejects(() =>
      act({
        action: "bot.delete",
        id: botRows[0].id,
        confirmation: "не совпадает",
      }),
    );
    await act({
      action: "bot.delete",
      id: botRows[0].id,
      confirmation: botRows[0].name,
    });
    check((await store.state()).bots.length === 1);
    check((await store.state()).log.length > 0);
    stage = "reencryption-command";
    const [encryptedBefore] = await db.select().from(bots);
    const rotation = spawnSync(
      process.execPath,
      ["--import", "tsx", "scripts/telegram-rotate.ts"],
      { env: process.env, encoding: "utf8" },
    );
    check(rotation.status === 0);
    const [encryptedAfter] = await db.select().from(bots);
    check(
      encryptedAfter.encryptedToken.ciphertext !==
        encryptedBefore.encryptedToken.ciphertext,
    );
    check(
      decryptToken(encryptedAfter.encryptedToken, encryptedAfter.id) ===
        decryptToken(encryptedBefore.encryptedToken, encryptedBefore.id),
    );
    const safe = JSON.stringify(await store.state());
    check(secrets.every((s) => !safe.includes(s)));
    const audit = await pool.query(
      "SELECT metadata::text FROM admin_audit_logs",
    );
    check(
      audit.rows.every((r) => secrets.every((s) => !r.metadata.includes(s))),
    );
    check(sent.every((s) => !s.includes(input.email)));
    console.log(
      `Telegram PostgreSQL + mock: ${n} успешных проверок, сетевых запросов нет.`,
    );
  } finally {
    if (owned) {
      await pool.query(
        "TRUNCATE telegram_jobs,telegram_routes,telegram_recipients,telegram_bots,telegram_worker,inquiries,admin_sessions,admin_audit_logs,site_settings,rate_limits,admin_users RESTART IDENTITY CASCADE",
      );
      await pool.query("UPDATE telegram_events SET enabled=false");
    }
    await pool.end();
    await database().pool.end();
  }
}
run().catch(() => {
  console.error(
    "Telegram-тест не пройден. Контрольная точка: " +
      stage +
      ". Секреты не выводятся.",
  );
  process.exitCode = 1;
});
