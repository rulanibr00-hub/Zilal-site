import "./environment";
import { readdir, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { createDatabase } from "../lib/db/connection";
async function run() {
  const { pool } = createDatabase();
  const client = await pool.connect();
  try {
    await client.query("SELECT pg_advisory_lock(81390427)");
    await client.query(
      "CREATE TABLE IF NOT EXISTS schema_migrations(name text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())",
    );
    for (const name of (await readdir("db/migrations"))
      .filter((n) => /^\d+_.+\.sql$/.test(n))
      .sort()) {
      const content = await readFile(`db/migrations/${name}`, "utf8");
      const checksum = createHash("sha256").update(content).digest("hex");
      const previous = await client.query(
        "SELECT checksum FROM schema_migrations WHERE name=$1",
        [name],
      );
      if (previous.rowCount) {
        if (previous.rows[0].checksum !== checksum)
          throw new Error("MIGRATION_CHECKSUM_CHANGED");
        console.log(`Уже применена: ${name}`);
        continue;
      }
      await client.query("BEGIN");
      try {
        await client.query(content);
        await client.query(
          "INSERT INTO schema_migrations(name,checksum) VALUES ($1,$2)",
          [name, checksum],
        );
        await client.query("COMMIT");
        console.log(`Применена: ${name}`);
      } catch {
        await client.query("ROLLBACK");
        throw new Error("MIGRATION_FAILED");
      }
    }
  } finally {
    await client.query("SELECT pg_advisory_unlock(81390427)").catch(() => {});
    client.release();
    await pool.end();
  }
}
run().catch(() => {
  console.error(
    "Миграции не выполнены. Проверьте соединение, права и версию схемы; секреты в журнал не выводятся.",
  );
  process.exitCode = 1;
});
