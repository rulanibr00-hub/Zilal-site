import "./environment";
import { createDatabase } from "../lib/db/connection";
import { processTelegramBatch } from "../lib/telegram/worker";
import { TelegramError } from "../lib/telegram/contracts";
async function run() {
  const { db, pool } = createDatabase();
  try {
    const result = await processTelegramBatch(db);
    console.log(`Telegram: обработано заданий ${result.processed}.`);
  } finally {
    await pool.end();
  }
}
run().catch((e) => {
  console.error(
    e instanceof TelegramError
      ? e.message
      : "Очередь не обработана. Проверьте БД и конфигурацию; секреты не выводятся.",
  );
  process.exitCode = 1;
});
