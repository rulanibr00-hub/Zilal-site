import "./environment";
import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import { spawnSync } from "node:child_process";
import { createDatabase } from "../lib/db/connection";
import { inquiryConfiguration } from "../lib/inquiries/policy";
import { originConfig } from "../lib/admin/security";
import { TelegramStore } from "../lib/telegram/store";
import { TelegramClient } from "../lib/telegram/client";
import { processTelegramBatch } from "../lib/telegram/worker";
let stage = "guard";
async function run() {
  const cfg = inquiryConfiguration().public;
  const origin = originConfig();
  const url = new URL(process.env.DATABASE_URL ?? "");
  assert.ok(
    cfg.mode === "test" &&
      origin.local &&
      /^[\w-]+_test$/.test(url.pathname.slice(1)) &&
      process.env.TELEGRAM_NETWORK_ENABLED !== "true",
  );
  const { db, pool } = createDatabase();
  let owned = false,
    n = 0;
  const check = (v: boolean) => {
    assert.ok(v);
    n++;
  };
  let publicCookie = "",
    csrf = "",
    adminCookie = "";
  async function request(
    path: string,
    method = "GET",
    body?: unknown,
    headers: Record<string, string> = {},
  ) {
    return fetch(origin.origin + path, {
      method,
      redirect: "manual",
      headers: {
        Origin: origin.origin,
        "Content-Type": "application/json",
        Cookie: publicCookie,
        ...(csrf ? { "X-CSRF-Token": csrf } : {}),
        ...headers,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  }
  async function session() {
    const r = await request("/api/inquiries/session", "POST", {});
    check(r.status === 200);
    const cookie = r.headers.get("set-cookie")!;
    check(cookie.includes("HttpOnly") && cookie.includes("SameSite=strict"));
    publicCookie = cookie.split(";")[0];
    csrf = (await r.json()).csrf;
  }
  const envelope = (inquiry: unknown) => ({
    inquiry,
    policyRevision: cfg.policyRevision,
    consent: true,
    website: "",
  });
  const post = (
    inquiry: unknown,
    key: string = randomUUID(),
    extra: Record<string, unknown> = {},
  ) =>
    request(
      "/api/inquiries",
      "POST",
      { ...envelope(inquiry), ...extra },
      { "Idempotency-Key": key },
    );
  const countRows = async (table: string) =>
    Number((await pool.query("SELECT count(*) FROM " + table)).rows[0].count);
  try {
    check(
      Number(
        (
          await pool.query(
            "SELECT (SELECT count(*) FROM admin_users)+(SELECT count(*) FROM inquiries)+(SELECT count(*) FROM admin_audit_logs)+(SELECT count(*) FROM telegram_bots)+(SELECT count(*) FROM telegram_jobs)+(SELECT count(*) FROM site_settings) n",
          )
        ).rows[0].n,
      ) === 0,
    );
    owned = true;
    const credentials = {
      login: "intake_" + randomBytes(8).toString("hex"),
      password: randomBytes(32).toString("base64url"),
    };
    const init = spawnSync(
      process.execPath,
      ["--import", "tsx", "scripts/init-admin.ts", "--stdin"],
      {
        env: process.env,
        input: JSON.stringify(credentials),
        encoding: "utf8",
      },
    );
    check(init.status === 0);
    const user = (await pool.query("SELECT id FROM admin_users")).rows[0];
    const mockToken = `${100000 + randomBytes(4).readUInt32BE()}:${randomBytes(30).toString("base64url")}`;
    const client = new TelegramClient(
      async (url) =>
        url.endsWith("/getMe")
          ? Response.json({
              ok: true,
              result: {
                is_bot: true,
                id: mockToken.split(":")[0],
                username: "mock_" + mockToken.split(":")[0],
              },
            })
          : Promise.reject(new Error("mock unavailable")),
      () => true,
    );
    const telegram = new TelegramStore(db, client);
    await telegram.action(
      { action: "bot.create", name: "Мок приёма обращений", token: mockToken },
      user.id,
    );
    const bot = (await telegram.state()).bots[0];
    await telegram.action({ action: "bot.check", id: bot.id }, user.id);
    await telegram.action(
      { action: "bot.update", id: bot.id, name: bot.name, enabled: true },
      user.id,
    );
    await telegram.action(
      {
        action: "recipient.save",
        botId: bot.id,
        name: "Локальный мок",
        chatId: String(randomBytes(4).readUInt32BE() + 100000),
        enabled: true,
      },
      user.id,
    );
    const recipient = (await telegram.state()).recipients[0];
    await telegram.action(
      {
        action: "routes.save",
        routes: [
          {
            event: "inquiry.created",
            enabled: true,
            recipientIds: [recipient.id],
          },
          { event: "inquiry.status_changed", enabled: false, recipientIds: [] },
          { event: "delivery.failed", enabled: false, recipientIds: [] },
        ],
      },
      user.id,
    );
    stage = "csrf-consent-validation";
    check(
      (await (await request("/api/inquiries/config")).json()).mode === "test",
    );
    check((await request("/api/inquiries", "GET")).status === 405);
    check(
      (
        await request(
          "/api/inquiries/session",
          "POST",
          {},
          { Origin: "https://attacker.invalid" },
        )
      ).status === 403,
    );
    await session();
    const home = {
      source: "home",
      name: "Локальный тест главной",
      email: "home@example.invalid",
      details: { message: "Проверка без настоящих данных" },
    };
    check((await post(home, randomUUID(), { consent: false })).status === 400);
    check(
      (await post(home, randomUUID(), { policyRevision: "0".repeat(64) }))
        .status === 409,
    );
    check(
      (
        await request("/api/inquiries", "POST", envelope(home), {
          "Idempotency-Key": randomUUID(),
          "X-CSRF-Token": "",
        })
      ).status === 403,
    );
    check((await post({ ...home, email: "invalid" })).status === 400);
    check((await post({ ...home, tourSlug: "does-not-exist" })).status === 400);
    check((await post(home, randomUUID(), { website: "spam" })).status === 400);
    check(
      (await post({ ...home, details: { message: "x".repeat(40000) } }))
        .status === 413,
    );
    check((await countRows("inquiries")) === 0);
    stage = "three-sources";
    const inputs = [
      home,
      {
        source: "contacts",
        name: "Локальный тест контактов",
        email: "contacts@example.invalid",
        details: { message: "Тестовый вопрос" },
      },
      {
        source: "builder",
        name: "Локальный тест конструктора",
        email: "builder@example.invalid",
        phone: "+996555000000",
        tourSlug: "issyk-kul-slow",
        details: {
          style: "combined",
          destinationIds: ["issyk-kul", "skazka"],
          activities: ["culture", "trekking"],
          duration: 7,
          flexibleDates: true,
          startDate: "",
          adults: 2,
          children: 1,
          accommodation: "mixed",
          wishes: "Тестовые пожелания",
          contactMethod: "whatsapp",
        },
      },
    ];
    const keys: string[] = [];
    const numbers: string[] = [];
    for (const input of inputs) {
      const key = randomUUID();
      keys.push(key);
      const r = await post(input, key);
      check(r.status === 201);
      const reply = await r.json();
      check(
        reply.accepted === true &&
          reply.isTest === true &&
          /^ZL-\d+$/.test(reply.number) &&
          reply.id === undefined &&
          reply.email === undefined,
      );
      numbers.push(reply.number);
    }
    check(new Set(numbers).size === 3);
    check((await countRows("inquiries")) === 3);
    check((await countRows("telegram_jobs")) === 3);
    const builder = (
      await pool.query("SELECT * FROM inquiries WHERE source='builder'")
    ).rows[0];
    check(
      builder.status === "new" &&
        builder.is_test === true &&
        builder.tour_slug === "issyk-kul-slow",
    );
    check(
      builder.details.duration === 7 &&
        builder.details.children === 1 &&
        builder.details.destinationIds.length === 2,
    );
    check(
      builder.policy_digest === cfg.policyRevision &&
        builder.consent_given === true &&
        builder.consent_recorded_at !== null,
    );
    check((await countRows("inquiry_policies")) === 1);
    stage = "idempotency";
    const repeat = await post(home, keys[0]);
    check(repeat.status === 200);
    check((await repeat.json()).number === numbers[0]);
    check(
      (await countRows("inquiries")) === 3 &&
        (await countRows("telegram_jobs")) === 3,
    );
    check(
      (await post({ ...home, name: "Исправленное имя" }, keys[0])).status ===
        409,
    );
    const savedCookie = publicCookie,
      savedCsrf = csrf;
    publicCookie = "";
    csrf = "";
    await session();
    check((await post(home, keys[0])).status === 409);
    publicCookie = savedCookie;
    csrf = savedCsrf;
    const concurrent = {
      ...home,
      name: "'; SELECT 1; --",
      email: "concurrent@example.invalid",
    };
    const concurrentKey = randomUUID();
    const pair = await Promise.all([
      post(concurrent, concurrentKey),
      post(concurrent, concurrentKey),
    ]);
    check(
      pair
        .map((r) => r.status)
        .sort()
        .join(",") === "200,201",
    );
    check(
      (await countRows("inquiries")) === 4 &&
        (await countRows("telegram_jobs")) === 4,
    );
    stage = "database-failure";
    await pool.query("ALTER TABLE inquiries RENAME TO unavailable_inquiries");
    try {
      const r = await post({ ...home, email: "db-failure@example.invalid" });
      check(r.status === 503);
      const text = await r.text();
      check(
        !text.includes("unavailable_inquiries") && !text.includes(home.email),
      );
    } finally {
      await pool.query("ALTER TABLE unavailable_inquiries RENAME TO inquiries");
    }
    check((await countRows("inquiries")) === 4);
    stage = "outbox-rollback";
    await pool.query(
      "ALTER TABLE telegram_jobs RENAME TO unavailable_telegram_jobs",
    );
    try {
      check(
        (await post({ ...home, email: "queue-failure@example.invalid" }))
          .status === 503,
      );
    } finally {
      await pool.query(
        "ALTER TABLE unavailable_telegram_jobs RENAME TO telegram_jobs",
      );
    }
    check(
      (await countRows("inquiries")) === 4 &&
        (await countRows("telegram_jobs")) === 4,
    );
    stage = "telegram-down";
    await processTelegramBatch(db, client);
    check((await countRows("inquiries")) === 4);
    check(
      Number(
        (
          await pool.query(
            "SELECT count(*) FROM telegram_jobs WHERE status='retry' AND error_code='NETWORK'",
          )
        ).rows[0].count,
      ) >= 1,
    );
    const messages = (
      await pool.query("SELECT message FROM telegram_jobs")
    ).rows.map((r) => r.message);
    check(
      messages.every(
        (s) =>
          !s.includes("example.invalid") &&
          !s.includes("Тестовые пожелания") &&
          !s.includes("+996"),
      ),
    );
    stage = "admin-and-rate";
    check((await request("/api/admin/inquiries")).status === 401);
    const login = await request("/api/admin/login", "POST", credentials);
    check(login.status === 200);
    adminCookie = login.headers.get("set-cookie")!.split(";")[0];
    const list = await request("/api/admin/inquiries", "GET", undefined, {
      Cookie: adminCookie,
    });
    check(list.status === 200 && (await list.json()).total === 4);
    await pool.query(
      "UPDATE rate_limits SET count=5 WHERE key LIKE 'public:accepted:session:%'",
    );
    check(
      (await post({ ...home, email: "rate-limit@example.invalid" })).status ===
        429,
    );
    check((await countRows("inquiries")) === 4);
    const audit = (
      await pool.query("SELECT metadata::text FROM admin_audit_logs")
    ).rows;
    check(
      audit.every(
        (r) =>
          !r.metadata.includes("example.invalid") &&
          !r.metadata.includes(mockToken),
      ),
    );
    console.log(
      `Публичные заявки: ${n} успешных HTTP/БД-проверок. Только test-режим и мок Telegram.`,
    );
  } finally {
    if (owned) {
      await pool.query(
        "TRUNCATE telegram_jobs,telegram_routes,telegram_recipients,telegram_bots,telegram_worker,inquiries,inquiry_policies,admin_sessions,admin_audit_logs,site_settings,rate_limits,admin_users RESTART IDENTITY CASCADE",
      );
      await pool.query("UPDATE telegram_events SET enabled=false");
    }
    await pool.end();
  }
}
run().catch(() => {
  console.error(
    "Проверка публичных заявок не пройдена. Этап: " +
      stage +
      ". Персональные данные не выводятся.",
  );
  process.exitCode = 1;
});
