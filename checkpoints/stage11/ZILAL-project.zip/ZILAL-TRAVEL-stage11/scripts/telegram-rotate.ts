import "./environment";
import { createDatabase } from "../lib/db/connection";
import { telegramBots } from "../lib/db/schema";
import { decryptToken, encryptToken, keyRing } from "../lib/telegram/crypto";
import { telegramLock } from "../lib/telegram/store";
import { eq } from "drizzle-orm";
async function run() {
  const ring = keyRing();
  const { db, pool } = createDatabase();
  try {
    await db.transaction(async (tx) => {
      await telegramLock(tx);
      const rows = await tx.select().from(telegramBots);
      for (const row of rows)
        await tx
          .update(telegramBots)
          .set({
            encryptedToken: encryptToken(
              decryptToken(row.encryptedToken, row.id, ring),
              row.id,
              ring,
            ),
          })
          .where(eq(telegramBots.id, row.id));
    });
    console.log("Токены перешифрованы активным ключом. Секреты не выводятся.");
  } finally {
    await pool.end();
  }
}
run().catch(() => {
  console.error(
    "Перешифрование не выполнено. Проверьте наличие всех старых ключей и БД.",
  );
  process.exitCode = 1;
});
