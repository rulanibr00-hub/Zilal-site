import { randomBytes } from "node:crypto";
import { writeFileSync, readFileSync, renameSync, lstatSync } from "node:fs";
import { externalKeyPath } from "../lib/telegram/crypto";
try {
  const file = externalKeyPath(process.argv[2] ?? "");
  let ring: { activeKeyId: string; keys: Record<string, string> };
  const rotate = process.argv.includes("--add-key");
  if (rotate) {
    if (lstatSync(file).isSymbolicLink()) throw new Error();
    ring = JSON.parse(readFileSync(file, "utf8"));
    if (!ring.keys) throw new Error();
  } else ring = { activeKeyId: "", keys: {} };
  const id = randomBytes(8).toString("hex");
  ring.keys[id] = randomBytes(32).toString("base64");
  ring.activeKeyId = id;
  if (rotate) {
    const temp = `${file}.${randomBytes(6).toString("hex")}.tmp`;
    writeFileSync(temp, JSON.stringify(ring), { mode: 0o600, flag: "wx" });
    renameSync(temp, file);
  } else writeFileSync(file, JSON.stringify(ring), { mode: 0o600, flag: "wx" });
  console.log(
    "Ключ создан в отдельном файле с закрытыми правами. Значение не выводится.",
  );
} catch {
  console.error(
    "Ключ не создан. Укажите абсолютный путь вне проекта; для существующего файла нужен --add-key. Проверьте права.",
  );
  process.exitCode = 1;
}
