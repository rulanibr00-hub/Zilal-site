import "./environment";
import { readdirSync } from "node:fs";
import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import { createDatabase } from "../lib/db/connection";
import { originConfig } from "../lib/admin/security";
// Run only against a disposable, already migrated *_test database. No fixed credentials.
let lastCheck = 0;
async function run() {
  const config = originConfig();
  const url = new URL(process.env.DATABASE_URL ?? "");
  assert.ok(
    config.local &&
      process.env.TELEGRAM_NETWORK_ENABLED !== "true" &&
      ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname) &&
      /^[\w-]+_test$/.test(url.pathname.slice(1)) &&
      process.env.ADMIN_TEST_INQUIRIES === "true",
    "Нужна изолированная локальная *_test БД и ADMIN_TEST_INQUIRIES=true",
  );
  const { pool } = createDatabase();
  const base = config.origin;
  let owned = false;
  let assertions = 0;
  const check = (actual: unknown, expected: unknown) => {
    lastCheck = assertions + 1;
    assert.deepEqual(actual, expected);
    assertions++;
  };
  async function cli(args: string[], input?: string) {
    return new Promise<{ code: number | null; output: string }>((resolve) => {
      const child = spawn(process.execPath, ["--import", "tsx", ...args], {
        env: process.env,
        stdio: ["pipe", "pipe", "pipe"],
      });
      let output = "";
      child.stdout.on("data", (d) => (output += d));
      child.stderr.on("data", (d) => (output += d));
      child.on("close", (code) => resolve({ code, output }));
      child.stdin.end(input);
    });
  }
  const login = `check_${randomBytes(8).toString("hex")}`;
  const password = randomBytes(32).toString("base64url");
  let cookie = "";
  let csrf = "";
  async function request(
    path: string,
    method = "GET",
    body?: unknown,
    extra: Record<string, string> = {},
  ) {
    return fetch(base + path, {
      method,
      redirect: "manual",
      headers: {
        Origin: base,
        "Content-Type": "application/json",
        ...(cookie ? { Cookie: cookie } : {}),
        ...(csrf ? { "X-CSRF-Token": csrf } : {}),
        ...extra,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  }
  try {
    const totals = await pool.query(
      "SELECT (SELECT count(*) FROM admin_users)+(SELECT count(*) FROM inquiries)+(SELECT count(*) FROM site_settings)+(SELECT count(*) FROM admin_sessions)+(SELECT count(*) FROM admin_audit_logs)+(SELECT count(*) FROM rate_limits)+(SELECT count(*) FROM telegram_bots)+(SELECT count(*) FROM telegram_jobs)+(SELECT count(*) FROM telegram_routes)+(SELECT count(*) FROM telegram_events WHERE enabled=true) AS n",
    );
    check(Number(totals.rows[0].n), 0);
    owned = true;
    for (let i = 0; i < 2; i++) {
      const migration = await cli(["scripts/migrate.ts"]);
      check(migration.code, 0);
    }
    check(
      Number(
        (await pool.query("SELECT count(*) FROM schema_migrations")).rows[0]
          .count,
      ),
      readdirSync("db/migrations").filter((n) => /\.sql$/.test(n)).length,
    );
    const created = await cli(
      ["scripts/init-admin.ts", "--stdin"],
      JSON.stringify({ login, password }),
    );
    check(created.code, 0);
    const again = await cli(
      ["scripts/init-admin.ts", "--stdin"],
      JSON.stringify({ login, password }),
    );
    check(again.code, 1);
    check(
      Number(
        (await pool.query("SELECT count(*) FROM admin_users")).rows[0].count,
      ),
      1,
    );
    for (const path of [
      "/admin",
      "/admin/inquiries",
      "/admin/settings",
      "/admin/telegram",
    ]) {
      const r = await request(path);
      check(r.status, 307);
      check(new URL(r.headers.get("location")!, base).pathname, "/admin/login");
    }
    for (const [path, method] of [
      ["/api/admin/inquiries", "GET"],
      ["/api/admin/settings", "GET"],
      ["/api/admin/session", "GET"],
      ["/api/admin/telegram", "GET"],
      ["/api/admin/telegram", "POST"],
      ["/api/admin/inquiries/" + randomUUID(), "PATCH"],
      ["/api/admin/inquiries/search", "POST"],
    ])
      check(
        (await request(path, method, method === "GET" ? undefined : {})).status,
        401,
      );
    check((await request("/api/inquiries", "GET")).status, 405);
    check((await request("/api/inquiries", "POST", {})).status, 503);
    check(
      (
        await request("/api/admin/login", "POST", {
          login,
          password: randomUUID(),
        })
      ).status,
      401,
    );
    check(
      (
        await request(
          "/api/admin/login",
          "POST",
          { login, password },
          { Origin: "https://attacker.invalid" },
        )
      ).status,
      403,
    );
    const signed = await request("/api/admin/login", "POST", {
      login,
      password,
    });
    check(signed.status, 200);
    const setCookie = signed.headers.get("set-cookie")!;
    assert.ok(
      setCookie.includes("HttpOnly") && setCookie.includes("SameSite=strict"),
    );
    assert.equal(setCookie.includes("Secure"), false);
    assertions++;
    cookie = setCookie.split(";")[0];
    csrf = (await signed.json()).csrf;
    const sessionToken = cookie.split("=")[1];
    const sessions = await pool.query("SELECT token_hash FROM admin_sessions");
    assert.notEqual(sessions.rows[0].token_hash, sessionToken);
    assertions++;
    check((await request("/api/admin/session")).status, 200);
    check(
      (
        await request(
          "/api/admin/settings",
          "PATCH",
          {},
          { "X-CSRF-Token": "" },
        )
      ).status,
      403,
    );
    check(
      (
        await request("/api/admin/settings", "PATCH", {
          key: "notifications",
          value: { emailEnabled: false, telegramEnabled: true, events: [] },
        })
      ).status,
      400,
    );
    check(
      (
        await request("/api/admin/settings", "PATCH", {
          key: "company",
          value: {
            displayName: "ZILAL TRAVEL",
            legalName: "",
            description: "Локальный черновик",
          },
        })
      ).status,
      200,
    );
    check(
      (await (await request("/api/admin/settings")).json()).company.description,
      "Локальный черновик",
    );
    check(
      (
        await request(
          "/api/admin/settings",
          "PATCH",
          {},
          { Origin: "https://attacker.invalid" },
        )
      ).status,
      403,
    );
    check(
      (
        await request(
          "/api/admin/settings",
          "PATCH",
          {},
          { "Content-Type": "text/plain" },
        )
      ).status,
      415,
    );
    const keys: string[] = [];
    let first: { id: string; displayNumber: string } | undefined;
    for (const source of ["home", "contacts", "builder"]) {
      const key = randomUUID();
      keys.push(key);
      const body =
        source === "builder"
          ? {
              source,
              name: "Тест конструктора",
              email: "test@example.invalid",
              phone: "+996555000000",
              tourSlug: "issyk-kul-slow",
              details: {
                style: "comfort",
                destinationIds: ["issyk-kul"],
                activities: ["culture"],
                duration: 4,
                flexibleDates: true,
                startDate: "",
                adults: 2,
                children: 0,
                accommodation: "advice",
                wishes: "",
                contactMethod: "whatsapp",
              },
            }
          : {
              source,
              name: `Локальный тест ${source}`,
              email: "test@example.invalid",
              details: { message: "Локальная тестовая запись" },
            };
      const result = await request("/api/admin/inquiries", "POST", body, {
        "Idempotency-Key": key,
      });
      check(result.status, 201);
      const data = await result.json();
      if (!first) first = data;
      const repeat = await request("/api/admin/inquiries", "POST", body, {
        "Idempotency-Key": key,
      });
      check(repeat.status, 200);
      check((await repeat.json()).id, data.id);
      check(
        (
          await request(
            "/api/admin/inquiries",
            "POST",
            { ...body, name: "Другое имя" },
            { "Idempotency-Key": key },
          )
        ).status,
        409,
      );
    }
    check(
      (
        await request(
          "/api/admin/inquiries",
          "POST",
          {
            source: "home",
            name: "Тест",
            email: "test@example.invalid",
            tourSlug: "unknown",
            details: { message: "" },
          },
          { "Idempotency-Key": randomUUID() },
        )
      ).status,
      400,
    );
    check(
      (
        await request(
          "/api/admin/inquiries",
          "POST",
          {
            source: "contacts",
            name: "Тест",
            email: "test@example.invalid",
            details: { message: "x".repeat(40000) },
          },
          { "Idempotency-Key": randomUUID() },
        )
      ).status,
      413,
    );
    await pool.query(
      "UPDATE rate_limits SET count=20 WHERE key LIKE 'test-intake:%'",
    );
    check(
      (
        await request(
          "/api/admin/inquiries",
          "POST",
          {
            source: "home",
            name: "Локальная проверка лимита",
            email: "test@example.invalid",
            details: { message: "" },
          },
          { "Idempotency-Key": randomUUID() },
        )
      ).status,
      429,
    );
    const list = await (await request("/api/admin/inquiries")).json();
    check(list.total, 3);
    const details = await (
      await request("/api/admin/inquiries/" + first!.id)
    ).json();
    assert.equal(details.payloadHash, undefined);
    assertions++;
    const update = {
      status: "in_progress",
      internalNote: "Тестовая внутренняя заметка",
      expectedUpdatedAt: details.updatedAt,
    };
    check(
      (await request("/api/admin/inquiries/" + first!.id, "PATCH", update))
        .status,
      200,
    );
    check(
      (await request("/api/admin/inquiries/" + first!.id, "PATCH", update))
        .status,
      409,
    );
    const filtered = await (
      await request("/api/admin/inquiries/search", "POST", {
        query: first!.displayNumber,
        status: "in_progress",
        page: 1,
      })
    ).json();
    check(filtered.total, 1);
    check(filtered.rows[0].id, first!.id);
    check(
      (
        await (
          await request("/api/admin/inquiries/search", "POST", {
            query: "' OR 1=1 --",
            status: "all",
            page: 1,
          })
        ).json()
      ).total,
      0,
    );
    const audit = await pool.query(
      "SELECT action,metadata::text FROM admin_audit_logs",
    );
    assert.ok(
      audit.rows.every(
        (row) =>
          !row.metadata.includes("example.invalid") &&
          !row.metadata.includes("заметка") &&
          !row.metadata.includes(password),
      ),
    );
    assertions++;
    const oldCookie = cookie;
    check((await request("/api/admin/logout", "POST", {})).status, 200);
    check((await request("/api/admin/inquiries")).status, 401);
    cookie = "";
    csrf = "";
    for (let i = 0; i < 6; i++) {
      const r = await request("/api/admin/login", "POST", {
        login: "nonexistent_" + login,
        password: randomUUID(),
      });
      check(r.status, i < 5 ? 401 : 429);
    }
    // Tampering with or expiring a server-side session must deny access.
    const newLogin = await request("/api/admin/login", "POST", {
      login,
      password,
    });
    check(newLogin.status, 200);
    cookie = newLogin.headers.get("set-cookie")!.split(";")[0];
    csrf = (await newLogin.json()).csrf;
    const simultaneous = await Promise.all([
      request("/api/admin/login", "POST", { login, password }),
      request("/api/admin/login", "POST", { login, password }),
    ]);
    check(
      simultaneous.map((r) => r.status),
      [200, 200],
    );
    check(
      Number(
        (await pool.query("SELECT count(*) FROM admin_sessions")).rows[0].count,
      ),
      1,
    );
    const candidateCookies = simultaneous.map(
      (r) => r.headers.get("set-cookie")!.split(";")[0],
    );
    const statuses: number[] = [];
    let validCookie = "";
    for (const candidate of candidateCookies) {
      cookie = candidate;
      const result = await request("/api/admin/session");
      statuses.push(result.status);
      if (result.status === 200) validCookie = candidate;
    }
    check(statuses.sort(), [200, 401]);
    cookie = validCookie;
    await pool.query(
      "UPDATE admin_sessions SET expires_at=now()-interval '1 minute'",
    );
    check((await request("/api/admin/session")).status, 401);
    cookie = oldCookie;
    check((await request("/api/admin/session")).status, 401);
    console.log(
      `Проверки админки: ${assertions} успешных утверждений. Все данные тестовые; публичный приём отключён.`,
    );
  } finally {
    if (owned) {
      await pool.query(
        "TRUNCATE inquiries,admin_sessions,admin_audit_logs,site_settings,rate_limits,admin_users RESTART IDENTITY CASCADE",
      );
    }
    await pool.end();
  }
}
run().catch(() => {
  console.error(`Контрольная точка: ${lastCheck}`);
  console.error(
    "Проверка админки не прошла. Проверьте изолированную тестовую БД, сервер и настройки. Секреты не выводятся.",
  );
  process.exitCode = 1;
});
