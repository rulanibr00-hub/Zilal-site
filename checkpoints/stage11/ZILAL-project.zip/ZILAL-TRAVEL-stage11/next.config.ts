import type { NextConfig } from "next";
const security = [
  { key: "X-Robots-Tag", value: "noindex, nofollow" },
  { key: "Cache-Control", value: "no-store, max-age=0" },
  { key: "Referrer-Policy", value: "no-referrer" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  {
    key: "Content-Security-Policy",
    value: "frame-ancestors 'none'; object-src 'none'; base-uri 'self'",
  },
];
const config: NextConfig = {
  poweredByHeader: false,
  async headers() {
    return [
      { source: "/admin/:path*", headers: security },
      { source: "/api/admin/:path*", headers: security },
      { source: "/api/inquiries", headers: security },
      { source: "/api/inquiries/:path*", headers: security },
    ];
  },
};
export default config;
