CREATE TABLE telegram_bots (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, encrypted_token jsonb NOT NULL, enabled boolean NOT NULL DEFAULT false,
 check_status text NOT NULL DEFAULT 'unchecked' CHECK(check_status IN ('unchecked','verified','error')),username text,telegram_id text,last_error text,checked_at timestamptz(3),revision integer NOT NULL DEFAULT 1,
 next_send_at timestamptz(3) NOT NULL DEFAULT now(),created_at timestamptz(3) NOT NULL DEFAULT now(),updated_at timestamptz(3) NOT NULL DEFAULT now()
);
CREATE TABLE telegram_recipients(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),bot_id uuid NOT NULL REFERENCES telegram_bots(id) ON DELETE CASCADE,name text NOT NULL,chat_id text NOT NULL,enabled boolean NOT NULL DEFAULT false,revision integer NOT NULL DEFAULT 1,next_send_at timestamptz(3) NOT NULL DEFAULT now());
CREATE UNIQUE INDEX telegram_bot_chat ON telegram_recipients(bot_id,chat_id);
CREATE TABLE telegram_events(event text PRIMARY KEY CHECK(event IN ('inquiry.created','inquiry.status_changed','delivery.failed')),enabled boolean NOT NULL DEFAULT false);
INSERT INTO telegram_events(event) VALUES ('inquiry.created'),('inquiry.status_changed'),('delivery.failed');
CREATE TABLE telegram_routes(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),event text NOT NULL REFERENCES telegram_events(event) ON DELETE CASCADE,recipient_id uuid NOT NULL REFERENCES telegram_recipients(id) ON DELETE CASCADE);
CREATE UNIQUE INDEX telegram_event_recipient ON telegram_routes(event,recipient_id);
CREATE TABLE telegram_jobs(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),dedupe_key text NOT NULL UNIQUE,event text NOT NULL,
 bot_id uuid REFERENCES telegram_bots(id) ON DELETE SET NULL,recipient_id uuid REFERENCES telegram_recipients(id) ON DELETE SET NULL,
 bot_name text NOT NULL,recipient_name text NOT NULL,bot_revision integer NOT NULL,recipient_revision integer NOT NULL,
 message text NOT NULL,status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','retry','delivered','failed','cancelled')),
 attempts integer NOT NULL DEFAULT 0 CHECK(attempts BETWEEN 0 AND 3),run_at timestamptz(3) NOT NULL DEFAULT now(),lease_id uuid,lease_until timestamptz(3),error_code text,telegram_message_id text,
 created_at timestamptz(3) NOT NULL DEFAULT now(),updated_at timestamptz(3) NOT NULL DEFAULT now()
);
CREATE INDEX telegram_due ON telegram_jobs(status,run_at);
CREATE TABLE telegram_worker(id integer PRIMARY KEY DEFAULT 1 CHECK(id=1),last_run_at timestamptz(3) NOT NULL);
