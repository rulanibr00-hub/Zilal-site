CREATE TABLE inquiry_policies(digest text PRIMARY KEY,document jsonb NOT NULL,created_at timestamptz(3) NOT NULL DEFAULT now());
ALTER TABLE inquiries ADD COLUMN submission_hash text;
ALTER TABLE inquiries ADD COLUMN policy_digest text REFERENCES inquiry_policies(digest);
ALTER TABLE inquiries ADD COLUMN consent_given boolean;
ALTER TABLE inquiries ADD COLUMN consent_recorded_at timestamptz(3);
