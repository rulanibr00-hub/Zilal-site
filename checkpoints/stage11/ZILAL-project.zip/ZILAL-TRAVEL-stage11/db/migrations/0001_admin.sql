CREATE TABLE admin_users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), singleton integer NOT NULL DEFAULT 1 CHECK (singleton=1),
 login text NOT NULL UNIQUE, password_hash text NOT NULL, created_at timestamptz(3) NOT NULL DEFAULT now(), last_login_at timestamptz(3)
);
CREATE UNIQUE INDEX one_admin ON admin_users(singleton);
CREATE TABLE admin_sessions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), admin_id uuid NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
 token_hash text NOT NULL UNIQUE, expires_at timestamptz(3) NOT NULL, created_at timestamptz(3) NOT NULL DEFAULT now(), revoked_at timestamptz(3)
);
CREATE INDEX session_expiry ON admin_sessions(expires_at);
CREATE TABLE inquiries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), number integer GENERATED ALWAYS AS IDENTITY UNIQUE NOT NULL,
 source text NOT NULL CHECK(source IN ('home','contacts','builder')), name text NOT NULL, email text NOT NULL, phone text,
 tour_slug text, details jsonb NOT NULL, status text NOT NULL DEFAULT 'new' CHECK(status IN ('new','in_progress','waiting','completed','cancelled')),
 internal_note text NOT NULL DEFAULT '', is_test boolean NOT NULL DEFAULT true,
 idempotency_key uuid NOT NULL UNIQUE, payload_hash text NOT NULL,
 created_at timestamptz(3) NOT NULL DEFAULT now(), updated_at timestamptz(3) NOT NULL DEFAULT now()
);
CREATE INDEX inquiry_status_created ON inquiries(status,created_at DESC);
CREATE TABLE admin_audit_logs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), action text NOT NULL, admin_id uuid REFERENCES admin_users(id) ON DELETE SET NULL,
 entity_id text, metadata jsonb NOT NULL DEFAULT '{}', created_at timestamptz(3) NOT NULL DEFAULT now()
);
CREATE TABLE site_settings (key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz(3) NOT NULL DEFAULT now());
CREATE TABLE rate_limits (key text PRIMARY KEY, count integer NOT NULL, expires_at timestamptz(3) NOT NULL);
