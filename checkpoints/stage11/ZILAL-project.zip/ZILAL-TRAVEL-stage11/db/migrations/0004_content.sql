CREATE TABLE cms_documents (
 key text PRIMARY KEY,
 kind text NOT NULL CHECK (kind IN ('tour','page','company')),
 draft_version integer NOT NULL DEFAULT 0,
 published_version integer,
 updated_at timestamptz(3) NOT NULL DEFAULT now()
);
CREATE TABLE cms_versions (
 document_key text NOT NULL REFERENCES cms_documents(key),
 version integer NOT NULL,
 payload jsonb NOT NULL,
 admin_id uuid REFERENCES admin_users(id) ON DELETE SET NULL,
 created_at timestamptz(3) NOT NULL DEFAULT now(),
 PRIMARY KEY (document_key,version)
);
CREATE TABLE cms_media (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 title text NOT NULL, alt text NOT NULL, author text NOT NULL,
 source text NOT NULL, rights text NOT NULL,
 commercial_use boolean NOT NULL CHECK (commercial_use),
 bytes bytea NOT NULL, thumbnail bytea NOT NULL,
 width integer NOT NULL, height integer NOT NULL,
 size integer NOT NULL,
 created_at timestamptz(3) NOT NULL DEFAULT now()
);
CREATE TABLE cms_media_refs (
 document_key text NOT NULL,
 version integer NOT NULL,
 media_id uuid NOT NULL REFERENCES cms_media(id) ON DELETE RESTRICT,
 PRIMARY KEY(document_key,version,media_id),
 FOREIGN KEY(document_key,version) REFERENCES cms_versions(document_key,version)
);
