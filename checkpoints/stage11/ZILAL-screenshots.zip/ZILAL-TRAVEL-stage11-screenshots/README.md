# Скриншоты ZILAL TRAVEL — контрольная копия после этапа №11

56 свежих PNG: desktop 1440×1000 и mobile 390×844. Снимки полных страниц могут быть выше указанной высоты экрана. Отдельные шаги конструктора сняты по области формы. Это текущий Next.js-проект, не старый HTML-экспорт.

Сайт запускался только для локальной съёмки, не публиковался. Настоящий приём и Telegram-сеть выключены. В админке использована отдельная пустая БД, без заявок, токенов, контактов и загрузок клиентов. Поля входа пустые; сведения временного аккаунта скрыты. На шестом шаге конструктора контакты не заполнялись. Карточка конкретной заявки не создавалась, чтобы не добавлять персональные данные: снят реальный пустой список.

Исходники и инструкции запуска находятся в отдельном ZIP ZILAL-TRAVEL-stage11-source.zip. Скриншоты не являются исполняемым сайтом.

## Снимки

| Файл | Маршрут / состояние |
|---|---|
| `desktop/01-home.png` | `/` |
| `desktop/02-tours.png` | `/tours` |
| `desktop/03-destinations.png` | `/destinations` |
| `desktop/04-create-trip-step1.png` | `/create-trip` |
| `desktop/05-kyrgyzstan.png` | `/kyrgyzstan` |
| `desktop/06-about.png` | `/about` |
| `desktop/07-contacts.png` | `/contacts` |
| `desktop/08-privacy.png` | `/privacy` |
| `desktop/09-sources.png` | `/sources` |
| `desktop/tour-1-issyk-kul-slow.png` | `/tours/issyk-kul-slow` |
| `desktop/tour-2-son-kul-open-sky.png` | `/tours/son-kul-open-sky` |
| `desktop/tour-3-karakol-culture-and-valleys.png` | `/tours/karakol-culture-and-valleys` |
| `desktop/tour-4-ala-kul-high-trails.png` | `/tours/ala-kul-high-trails` |
| `desktop/tour-5-kyrgyzstan-comfort-adventure.png` | `/tours/kyrgyzstan-comfort-adventure` |
| `desktop/builder-step2.png` | `/create-trip (шаг 2)` |
| `desktop/builder-step3.png` | `/create-trip (шаг 3)` |
| `desktop/builder-step4.png` | `/create-trip (шаг 4)` |
| `desktop/builder-step5.png` | `/create-trip (шаг 5)` |
| `desktop/builder-step6.png` | `/create-trip (шаг 6)` |
| `desktop/admin-01-login.png` | `/admin/login` |
| `desktop/admin-02-dashboard.png` | `/admin` |
| `desktop/admin-03-inquiries.png` | `/admin/inquiries` |
| `desktop/admin-04-tours.png` | `/admin/tours` |
| `desktop/admin-05-media.png` | `/admin/media` |
| `desktop/admin-06-pages.png` | `/admin/pages` |
| `desktop/admin-07-settings.png` | `/admin/settings` |
| `desktop/admin-08-telegram.png` | `/admin/telegram` |
| `desktop/admin-09-preview.png` | `/admin/preview?key=tour:issyk-kul-slow` |
| `mobile/01-home.png` | `/` |
| `mobile/02-tours.png` | `/tours` |
| `mobile/03-destinations.png` | `/destinations` |
| `mobile/04-create-trip-step1.png` | `/create-trip` |
| `mobile/05-kyrgyzstan.png` | `/kyrgyzstan` |
| `mobile/06-about.png` | `/about` |
| `mobile/07-contacts.png` | `/contacts` |
| `mobile/08-privacy.png` | `/privacy` |
| `mobile/09-sources.png` | `/sources` |
| `mobile/tour-1-issyk-kul-slow.png` | `/tours/issyk-kul-slow` |
| `mobile/tour-2-son-kul-open-sky.png` | `/tours/son-kul-open-sky` |
| `mobile/tour-3-karakol-culture-and-valleys.png` | `/tours/karakol-culture-and-valleys` |
| `mobile/tour-4-ala-kul-high-trails.png` | `/tours/ala-kul-high-trails` |
| `mobile/tour-5-kyrgyzstan-comfort-adventure.png` | `/tours/kyrgyzstan-comfort-adventure` |
| `mobile/builder-step2.png` | `/create-trip (шаг 2)` |
| `mobile/builder-step3.png` | `/create-trip (шаг 3)` |
| `mobile/builder-step4.png` | `/create-trip (шаг 4)` |
| `mobile/builder-step5.png` | `/create-trip (шаг 5)` |
| `mobile/builder-step6.png` | `/create-trip (шаг 6)` |
| `mobile/admin-01-login.png` | `/admin/login` |
| `mobile/admin-02-dashboard.png` | `/admin` |
| `mobile/admin-03-inquiries.png` | `/admin/inquiries` |
| `mobile/admin-04-tours.png` | `/admin/tours` |
| `mobile/admin-05-media.png` | `/admin/media` |
| `mobile/admin-06-pages.png` | `/admin/pages` |
| `mobile/admin-07-settings.png` | `/admin/settings` |
| `mobile/admin-08-telegram.png` | `/admin/telegram` |
| `mobile/admin-09-preview.png` | `/admin/preview?key=tour:issyk-kul-slow` |

Ошибок JavaScript и горизонтального переполнения при съёмке не обнаружено. Результаты — capture-report.json; контрольные суммы файлов — MANIFEST_SHA256.txt.
